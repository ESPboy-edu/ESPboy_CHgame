# Design notes

How *New Blocks on the Kid — colour edition* works, and why it looks
the way it does. For what the game is and how to build it, see the
[README](../README.md).

The rules are the 2020 Arduboy original's, untouched. Everything else
is different.

![title, play, row clear, confetti, full well, shatter, game over](preview.png)

*Frames rendered from a host simulator that ports the plasma, palette,
particle and board maths at the same integer widths as the firmware.
They predate a few later changes (the title now says `PRESS ANY
BUTTON`).*

## Memory budget

Built with **Tools ▸ Optimize ▸ Faster (-O2)**, which this sketch wants:
the default `-Os` costs 10–20% on the drawing primitives, and the sketch
spends its whole frame in them.

| | |
|---|---:|
| Flash | 47,700 B of 50,944 (93%) |
| SRAM | 17,696 B of 20,480 (86%) |
| Measured worst-case stack | ~800 B against 2,784 free |

The largest single item in flash is the title music: 7,625 bytes of
score in `Music.h`. The game over sting (`MusicOver.h`) is 56 B. The
`-Os` build is 41,704 B of flash and 16,756 B of SRAM, if the margin
ever matters more than the frame rate.

The only libraries are CHGfx and the vendored copy of CHGameSound in
`src/`. FixedPoints and Adafruit_GFX are both gone.

The IDE prints *"Low memory available"* at 81%. That warning assumes
heap and `String` use; this sketch has neither, its deepest call chain
is five frames of well under 200 bytes each, and the largest single
stack frame in the binary is the 112-byte composite callback. The
headroom is about 3.5×.

## How it renders

Every frame is a **single `gfx_stream()` composite**. `gfx_flush()` is
never called and `gfx_setPalette()` is never called.

CHGfx normally makes you choose: a 4 bpp, 16-colour framebuffer for
sprites and geometry, or `gfx_stream()` for procedural effects that want
all 65,536 colours. This game uses both at once, the way the Demoscene
copper part does:

1. Every game element is drawn into the 4 bpp framebuffer with the
   ordinary library calls, using **palette index 0 to mean "nothing
   here"**.
2. The stream callback walks the frame and, per pixel, either emits the
   palette colour for a non-zero nibble, or computes a plasma pixel at
   full RGB565 depth.

The framebuffer never reaches the panel. It is a stencil. `Plasma.h`
holds the background and the composite pass, and is the centre of
gravity of the whole port.

### The palette is never the same twice

All sixteen slots are rebuilt every frame from a hue that walks the
colour wheel once every ~12 seconds. Nothing is stored as a colour;
everything is stored as a *role* — `C_BLK0+n`, `C_LIT0+n`, `C_FRAME`. So
blocks, sparks, the frame and the text all drift through the spectrum
together, for free.

The sixteen slots are spent like this, and there are none spare:

```
0        stencil hole - the plasma shows through
1        opaque black - gutters, outlines, banners
2..6     five block hues, fully saturated
7..11    the same five lightened - glints and sparks
12..15   white, frame, text, ghost
```

**Ten of the sixteen go to five hue/tint pairs**, and that is what fixed
the glints. A shared near-white glint reads as a smudge of someone
else's colour dropped on the corner of the block; a lighter tone of the
block's own hue reads as light falling on a coloured solid. Paying five
slots for the twins is what cost the sixth block hue, and it was worth
it. The twin is the same hue at `s=80` rather than a brighter value —
the fill is already at `v=255`, so the only direction left is toward
white.

Sparks use the same pairs. Every spark carries a block hue index and
cools **white → that hue lightened → that hue → dim**, so a landing
sparks in the colour of the piece that landed and a row clear throws
five colours out of the well at once. There is no separate fire ramp;
the three slots it used to occupy became twins.

This all also means the block sprites are `const` in flash: a sprite
stores palette *indices*, and the index of hue 3 is always 5 no matter
what colour hue 3 currently is.

### The background answers the game, and wears its colours

The plasma is four sine terms — two linear scrolls and two concentric
ripples about moving centres — averaged into one index and run through a
colour ramp.

**It tints itself towards whichever piece is falling.** The ramp covers
150 units of the wheel rather than a full 512, centred on a hue that
eases towards the active piece at two units a frame. That span is the
dial between "the background is a rainbow" (in which case shifting its
base hue changes nothing you can see) and "the background is the colour
of the piece you are holding". At 150 there is still plenty of variation
inside the frame but an unmistakable overall cast. The frame and the
score are keyed *opposite* the plasma hue for the same reason — keyed
opposite `baseHue`, a neon frame drifts into agreement with the
background every time the falling piece lands near that angle.

**It drifts, rather than races.** The scroll and ripple phases advance
in 8.8 fixed point at about 45% of the whole-number rates they started
with — one horizontal cycle now takes ~7 s rather than ~3 s, and the
ripple centres wander their Lissajous paths in ~11 s rather than ~5.5 s.
Measured frame-to-frame change across the background is 63% of what it
was; the remainder is the palette drift, which is left alone because
that is the part that is supposed to be noticed. Five `RATE_*` constants
at the top of `Plasma.h` are the whole dial.

**And it keeps the fractions.** Slowing the rates down was only half
the job: every consumer of a phase was still truncating it to a whole
unit, so at 0.44 units a frame the field moved on some frames and stood
still on others, in the pattern 0,1,0,1,0,0,1 — an irregular ~35 Hz
stutter that read as shimmer. Now the ring phases are folded into the
per-row distance constants *before* the shift that makes a sine index
(sub-step ring travel, and two fewer adds per pixel), the scroll terms go
through an interpolated sine at their full 8.8 angle, and the ripple
centres live in 1/8 px. The phases also advance by measured time rather
than by frame, so a frame that runs long on a row clear moves the field
proportionally further instead of leaving it a step behind. Nothing per
pixel changed except the two adds that went away.

**Events push a smooth zoom through it.** A spatial scale factor is
applied when the per-frame tables are built, so all four terms zoom
together and stay one coherent field — one multiply per table entry,
three per row, and nothing at all per pixel. A piece settling takes a
small breath (depth 30 over 16 frames); a cleared row gets a deeper,
longer one at twice the depth and three times the length (60 over 44).
140 was the first try and it was a lurch — the background stopped being
a background at exactly the moment the player wants to watch the row
leave.

A zoom is *all* a cleared row does to the field now. For a long time it
was also a surge — the second ripple centre dragged towards the row and
its rings sped up, all off the same envelope — and the history below is
mostly the story of making that surge not pop. It never popped in the
end, and it still read on the panel as the background being disturbed
rather than answering: rings sliding sideways while the whole field also
zoomed is two motions where the eye wants one. The centre pull, the
speed ramp and the second easing they needed are gone; the ripple
centres only ever follow their Lissajous paths.

### Making that zoom actually smooth

This took four passes, and each failure was a different way for one
frame to contain a step. Worth writing down, because none of them were
visible in the code and all of them were obvious on the panel.

1. **It snapped.** The ring centre teleported to the impact, the
   wavelength jumped a whole shift, the ramp hue jumped 48 units. One
   frame is not long enough for the eye to read a change as motion — it
   only sees that the picture is suddenly different. Replaced with a
   half-sine envelope.
2. **The exit popped.** The centre was pinned while a counter ran and
   handed back to its Lissajous path the frame it hit zero. That path
   wanders up to 92 px off centre, so the target could jump 150 px in
   one frame and the easing then dragged the whole ring pattern across
   the screen at 25 px a frame — arriving exactly as the zoom settled.
3. **The entrance popped.** Fixing the exit with a linear 255→0 decay
   left the trigger frame going 0→255 in one step: 22 px of centre and
   4.5× of ring speed between two frames. A half sine has zero slope at
   *both* ends, so now the zoom, the ring speed and the centre pull are
   all derived from the same `env`.
4. **Re-triggering popped.** A second row clearing 26 frames into the
   first restarted the envelope at zero while the scale was still deep
   at 199 — a 57-unit step. Two hard drops in a row reach this. The arc
   now starts at the phase whose value already equals the current scale,
   found by walking the rising quarter of the sine table backwards.

Plus one that only a long soak found: the surge had its own frame
counter, and once arcs were allowed to start mid-phase the two lifetimes
drifted apart. The arc would finish with a dozen frames still on the
counter; the next pulse restarted the envelope, the stale counter
re-energised the surge off the *new* arc, and when it finally expired
mid-arc the strength collapsed — a 228-unit step in ring speed about a
second after a row cleared, with nothing on screen to explain it. The
surge is now a flag cleared when its arc ends, which cannot drift
because `env` is already zero at that moment.

Measured over 20,000 frames of hard-dropping play, the largest
single-frame change anywhere is **4 units of a 60-unit zoom excursion**.
(Passes 2, 3 and the soak fix above concern the surge, which has since
been removed outright — see the note above.)

### The well is revealed, not pre-dimmed

The dimmed rectangle behind the well is set for the whole playfield
every frame by the main loop, which is right during play and wrong in
the intro: with the line still coming down, a dark 40×120 slab was
already sitting behind it, and the rectangle then opened out over a well
that was visibly there before its container was. Now the line dims
nothing and the opening rectangle dims exactly its own interior, so the
shadow spreads with the frame that casts it.

### Type

Small text — the `BEST`/`SCORE` labels, the `Nice!` popups, the `+20` —
is the built-in 5×7 at 1:1. Its 6 px advance is what makes seven
characters fit a 42 px column exactly, and the whole side-column layout
is built on that number.

Display text used to be that *same* 5×7 font at scale 2: every pixel
drawn as a 2×2 block. That is not a bigger font, it is the same font
with bigger pixels. It now uses real faces from the library at 1:1:

| Where | Face | Width |
|---|---|---:|
| Score, ≤3 digits | `CHGfx_SansBold16` | 11 px/digit, 33 px |
| Score, 4–5 digits | `CHGfx_SansBold12` | 8 px/digit, 40 px |
| `NEW` / `BLOCKS` | `CHGfx_SansBold16` | 42 px / 72 px |
| `ON THE KID` | `CHGfx_SansBold12` | 77 px |
| `PRESS ANY BUTTON` | built-in 5×7 at 1:1, white | 96 px |
| Game over word, `PAUSED` | `CHGfx_SansBold16` | 49–109 px (`DESTROYED` is widest) |

3,310 bytes of flash for the two faces, and **nothing in RAM** — the
bitmaps, glyph tables and `GFXfont` structs all link into `.text`.

**The title and the game over word are a rainbow wave.** Each letter is
one hue step (24/256 of the wheel) further round than the one before,
so the word is a static rainbow, and the whole ramp drifts with
`baseHue` at exactly the rate the blocks do. Five block hues 51 apart
were too coarse a step and there are no spare palette slots — but when
those words are on screen there are no blocks, so while `textGradient`
is set the ten block/tint slots become a ten-step hue ramp and letter
*i* is drawn in slot *i* (`BLOCKS` carries on from the slot after `W`).
Each letter also bobs on a sine, 3 px each way, 28/256 of a cycle
behind its neighbour, one cycle in about 64 frames. The title now waits
for a button press rather than starting on its own after 250 frames.
`PRESS ANY BUTTON` under it is deliberately *not* in a display face: it
is an instruction, not a third line of the title, and set in
`CHGfx_SansBold12` directly below `ON THE KID` it competed with the
title it was there to serve. It blinks on a clock of its own, started
the moment it appears: on the free running hue accumulator the first ON
was whatever was left of that cycle at frame 41 — two frames — so the
first thing the player ever saw was a 25 ms flash, a third of a second
of nothing, and only then the rhythm.

**Pause is the game over banner.** `START` during play opens the same
32 px banner and sets `PAUSED` in the same face and the same rainbow
wave, because a pause and a game over are the same gesture — the game
stops and one word says why. The board is not drawn underneath it, and
that is forced rather than chosen: `textGradient` repaints the ten
block slots into the hue ramp the wave needs, so a stack left standing
there would come out in ramp colours. It is the same reason the stack
is demolished before the game over banner opens. A pause screen you
cannot study the stack through is the right answer anyway.

**The mute indicator borrows a palette slot.** `SELECT` toggles the
audio device from any screen, and the title screen shows the state as
`MUTE` in its bottom right corner — the corner nearest the button —
white for sound, red for silence. There is no spare slot for a fixed
red; all sixteen are roles and every one is spoken for. But `C_GHOST`'s
three jobs (grid dots, smear trails, dying sparks) are all things that
cannot be on screen while the title is up, so `pal[C_GHOST]` is
overwritten with red for exactly the frames that need it. `pal[]` is
not read until the composite at the end of `loop()`, so writing it
mid-draw is what the draw comes out as.

Everywhere else the toggle announces itself as a `MUTED` / `UNMUTED`
popup rising out of the right column, in the same place and the same
strobe as the `+20`. It is a particle rather than something a screen
draws, which is what lets it appear over the title, over the pause
banner and over the game over word without any of those states knowing
the others exist.

The scores are `uint16_t`, so five digits is the most there can ever be
and neither face can overflow the 42 px column. `CHGfx_Digits24` would
be the obvious choice for a score — 523 B for a 24 px face — but its
digits are 17 px, so three of them need 51 px and the column is 42. It
would need the HUD moved somewhere wider.

**Two origins.** CHGfx follows Adafruit_GFX: for the built-in font `y`
is the top of the glyph box, for a custom font `y` is the *baseline*.
`Text.h` exposes both rather than hiding one — `textOut()` takes a top
(and adds `gfx_fontBaseline()` itself, so it is right for either font),
`textOutBase()` takes a baseline. The score needs the second one: it
swaps between the 16 px and 12 px faces as it grows a digit, and two
faces sharing a baseline sit still where two sharing a top would jump.

### Sound

The core's `tone()` never made a sound on this board: the board
package's default **Peripherals ▸ Game** setting builds with
`TIM_MODULE_ONLY`, and in that configuration `tone()` ignores its
arguments. Audio now goes through
[CHGameSound](../src/CHGameSound/) on its **Lead** output — the plain
hardware tone the library's `BasicTone` and `Playtune` examples use, a
TIM1 PWM on PB10 retuned from a 1 kHz TIM2 interrupt. It costs the frame
nothing; CHGfx keeps SPI1 and DMA channel 3 to itself.

**Music.** Scott Joplin's *The Entertainer* (1902, public domain), the
"Arduino Club Mix — more swing" arrangement in
`music/entertainer-swing.mid`, as a single-channel Playtune score. It
belongs to the title screen: it starts 300 ms after reset — when the LCD
has come out of its own reset and the title is on screen — loops while
the title waits (134 s a pass), and stops the moment a button starts the
game. Play itself has only the effects. Regenerate it with the library's
converter, copied into `tools/` (standard-library Python), from the
sketch folder:

```bash
python tools/midi2score.py music/entertainer-swing.mid Music.h --name music --voice 0=t0:high --loop
```

**Game over sting.** An 8-note single-channel score
(`music/gameover.mid`), 56 bytes, 2.1 s. It starts the
moment the "WRECKED"-or-whatever banner word appears and, with no `--loop`
command baked in, plays through once and stops itself — the same engine
that ducks the title music under an effect just as happily lets this one
keep counting under the game that resumes beneath it. Regenerate it the
same way, without `--loop`:

```bash
python tools/midi2score.py music/gameover.mid MusicOver.h --name musicOver --voice 0=t0:high
```

**Effects.** One square wave on one piezo, so an effect takes the tone
for exactly as long as it lasts (on the title, the music comes back on
its next note). All but one are generated by `tools/gen_sfx.py`, a port
of the generator in CHGameSound's `SfxGenerator` example (the
cloud.arduboy.com Effects tab), and each array in `Sfx.h` carries the
`// SFX:` line that reopens it in the web app. Pitches sit in the
piezo's 190–3000 Hz window; durations are short on purpose. The
exception is the original's own settle tone, computed from the row.

| Event | Sound | Rank |
|---|---|---|
| Piece steps down a row **while Down is held** | one 10 ms tick per row (`SFX_FALL_TICK 0` removes it) | click |
| Move left/right | two-note click, 27 ms | blip |
| Move up, for a point | the same click an octave down, through the transposing path the shatter already uses | blip |
| Piece settles on the stack | the original's tone: 587 Hz + 30 Hz per row of height, 45 ms — higher the taller the stack | piece |
| Piece hits the floor | a heavier thud, 122 ms | piece |
| Hard drop | a "laser" whoosh down the well, 96 ms, then the landing tone for the row it stops on | drop |
| Stack shattering | one gritty crackle per row, bottom to top, dropping half a semitone a row | drop |
| Row cleared | a rising "powerup" trill with a "coin" sparkle on top, 462 ms | phrase |
| Any button on the title / play begins | a "blip" (and the music stops) / a rising "powerup" | phrase |
| Pause / unpause | the banner rumble / the same rising "powerup" that starts a game | phrase |
| Topping out | a gritty run down, 351 ms | phrase |
| Game over banner opening | a low "explosion" rumble, 251 ms | phrase |

A new sound plays if nothing is playing or if it ranks at least as high
as what is. So a hard drop's slam is not chopped by the settle of the
piece it dropped (the drop carries that row's tone itself), a row clear
does override the thud before it, and the fall tick only ever fills
silence. The game over sequence holds the
full stack on screen while the run down plays, then demolishes it.

`tools/preview_sound.cpp` renders a scripted half-minute of all this,
through the same engine the board runs, to a WAV — the build line is in
its header.

## Choices that were measured, not guessed

The art direction was settled by rendering the same frame several ways in
a host simulator and looking at them side by side, because this panel is
~200 nits with poor contrast and things that look fine in isolation stop
working once eighty saturated blocks are on screen.

- **Plasma dimmed to 1/8 inside the well, full brightness outside.** Two
  stops looked better on an empty well and lost badly on a full one.
  Dimming is a shift and a mask on the RGB565 value, not a second ramp
  table — a second table would be free per pixel but costs 512 bytes.
- **Blocks: 1 px black gutter, 3 px specular in the block's own colour,
  everything else saturated fill.** A full top-and-left bevel reads as a
  lit solid but eats a fifth of an 8×8 block and visibly desaturates it.
  A *shared* near-white specular costs no area but reads as somebody
  else's colour dropped on the corner — which is what bought the five
  lightened twins, at the price of the sixth block hue.
- **Sparks flash white for the first eighth of their life, not 40%.** An
  even five-way fade made every row clear read as white confetti instead
  of as the colours that were just destroyed.
- **Row-clear confetti launches at 8.5 px/frame.** At 5 it apexed 26 px
  up and fell back into the well, which looked like the row crumbling
  rather than exploding.
- **One grid dot per cell, centred, drawn first.** Dimming the well to
  near-black is what makes the blocks read, but this game spends most of
  its time with an almost empty well, and a 40×120 black void needed
  structure. Dotted lines down the column boundaries were the first
  attempt: they drew the gaps between columns, which is the part that
  never holds anything. Marking the slots themselves shows where a block
  will come to rest, and costs 75 pixels instead of 140. The dots go
  down before anything else in the scene — drawn with the frame they
  landed *after* the hard drop beam and perforated it.
- **No marker on the falling piece.** It used to strobe a white rim,
  which was legible but sat a flashing white box on top of the one block
  whose colour matters most. It is already the only block that moves,
  the only one with a smear behind it, and now the one the entire
  background has tinted itself to match.

## Two bugs from the original, fixed

Both are in the board rules and both are visible in the 2020 source.

**Out-of-bounds probe.** `boardCycle()` read `gameBoard[col][row + 2]`
with no bounds check. For a piece one row above the floor that indexes
one past the end of the column, and for the last column one past the end
of the array entirely. It usually got away with it because the byte it
landed on happened to hold a 2 rather than a 1, so the test failed and
control fell through to the "about to be on the ground" branch — which is
the right answer. Now it is an explicit compare.

**Hard drop onto an adjacent block deleted the piece.** `moveDown()` wrote
the landed block and *then* cleared the source cell:

```c
gameBoard[col][rowSearch - 1] = 1;
gameBoard[col][row] = 0;
```

When the piece was already resting directly on the stack those are the
same cell, so the clear undid the write and the block vanished. Clearing
first makes the two orders agree.

## Ported away from AVR

- **`PROGMEM` / `strcpy_P` / `pgm_read_word` are gone.** They existed
  because the AVR is a Harvard machine where a pointer to flash and a
  pointer to RAM are different kinds of thing. RISC-V has one flat
  address space, so a string literal already lives in flash and
  `const char *` already points at it. The word buffer went with them.
- **FixedPoints is gone.** `SQ7x8` is replaced by `int16_t` and a shift.
- **`Arduboy2` is gone.** Buttons are eight `INPUT_PULLUP` reads, sound
  is CHGameSound on the piezo, and the frame loop is `gfx_stream()`.

## Layout

```
 0        42        86       127
 +---------+---------+---------+
 |  BEST   |  frame  |  SCORE  |
 |         |#########|         |
 | words   |#  well #| points  |
 | float   |#   15  #| float   |
 | up here |#  rows #| up here |
 |         |#########|         |
 +---------+---------+---------+
```

The panel is the same width as the Arduboy and twice the height, and
that doubling goes straight into the well: 15 rows of 8 px cells instead
of 10 rows of 6. Centring it leaves two 42 px columns, which is exactly
seven characters of the 5×7 font — `Wicked!` is seven characters and
lands flush.

---

Original game copyright Kevin Bates, 2020.
