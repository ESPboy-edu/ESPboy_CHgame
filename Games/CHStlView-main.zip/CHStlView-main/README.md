# CHStlView

**A 3D wireframe viewer for `.STL` files on a 48 MHz microcontroller with 20 KB
of RAM.**

CHStlView runs on the [CHGame](https://github.com/bateske/CHGame) handheld: a
CH32X035 RISC-V MCU with no FPU, a 128×128 ST7735 LCD and a microSD card
sharing one SPI bus. Put STL files on the card, pick one, and it spins as a
depth-cued wireframe. Near edges are bright and far edges dim, and where two
wires cross the nearer one wins. The files are the same ones you would send to
a 3D printer, with no conversion step.

![Four models as the device draws them](sample/preview.gif)

*These frames come from `src/StlRender.cpp`, the same file the sketch compiles,
run on a PC by `tools/preview.py`. They use the device palette at 12 bpp.*

> **Status:** everything below is verified in simulation, and the sketch
> builds for the board, but it has **not yet been run on hardware**. The frame
> rates in [Speed](#speed) are estimates from measured bus timings.
> Measurements from a real board are very welcome.

## Features

- Reads **binary STL** straight off the card, in any folder, with **no size
  limit**. Fragmented files are handled.
- **Depth-cued wireframe**, with a free 4-bit "nearest wins" z-buffer.
- **Two modes**: X-RAY (every edge) and FRONT (only faces pointing at you).
- **Spin, rotate, zoom** from ×0.25 to ×16.
- **HUD** with name, triangle count, size in mm, frame rate and an XYZ gizmo.
- **Big models stay responsive.** While you turn them you see a point-cloud
  preview drawn from RAM, then the full model fills in when you let go.
- **No floating point.** Everything is integer maths, accurate to 0.1 px.

---

## Getting started

### What you need

- A **CHGame board**: CH32X035G8U6, ST7735S 1.44" 128×128, microSD on SPI1.
- **Arduino IDE 2.x** or **arduino-cli**, with:
  - the **CHGame board package** ([bateske/CHGame](https://github.com/bateske/CHGame))
  - the **CHGfx library, 1.2.0 or later** ([bateske/CHGfx](https://github.com/bateske/CHGfx)).
    Clone it into your sketchbook's `libraries/` folder.
- A microSD card formatted **FAT16 or FAT32**.

The SD card library is already included, in `src/SD`. It is a modified copy
with DMA streaming, so do not install another one.

### Build and upload

Clone into a folder called `CHStlView`. Arduino needs the folder name to match
the `.ino`.

```
git clone https://github.com/bateske/CHStlView.git
cd CHStlView
arduino-cli compile -b CHGame:ch32v:CHGame:opt=o2std,rtlib=nano .
arduino-cli upload  -b CHGame:ch32v:CHGame -p COMx .
```

In the IDE, select the CHGame board and set **Tools ▸ Optimize ▸ Faster
(-O2)**.

### The card

Copy the models in [`sample/`](sample) to the card to start with, then your
own:

- **Binary STL only.** ASCII STL is detected and you are told to re-export as
  binary. Most CAD tools and slicers write binary. OpenSCAD writes ASCII.
- **8.3 names.** The SD library only sees short names, so `my_bracket.stl` is
  listed as `MY_BRA~1.STL`. Rename to 8 characters to keep names readable.
- **Fragmented files** are followed, up to 16 fragments. Beyond that, copy the
  file to a freshly formatted card.

---

## Using it

### Buttons

| Where | Button | What it does |
|---|---|---|
| File list | UP / DOWN | Move (hold to repeat) |
| | LEFT / RIGHT | Page up / down |
| | A | Open the model or folder |
| | B | Up one folder |
| | START | Re-read the card |
| Viewer | D-pad | Rotate. Stops the spin. |
| | A / B (hold) | Zoom in / out |
| | A + B | Reset the view |
| | SELECT | **X-RAY** (every edge) / **FRONT** (only edges of faces towards you) |
| | START | Spin on / off |
| | START (hold ½ s) | Back to the file list |

### The HUD

Any button shows it for 3 seconds:

| Where | Shows |
|---|---|
| Top line | File name and number of triangles |
| Second line | Bounding box size in file units (usually mm). `open` on the right means the mesh isn't closed |
| Bottom right corner | XYZ axes: X red, Y green, Z blue |
| Bottom line | Mode (`X-RAY`, `FRONT` or `DRAFT`), zoom, then fps while moving, or how long the last full frame took while at rest |

### Big models

A model that takes more than 100 ms per frame opens standing still, and the
full render builds up on screen. While you turn it you see a **draft**: the
bounding box plus 256 points sampled from the surface when the file was
opened. The draft comes from RAM with no card access, so it moves at full frame
rate. Let go and the full model streams in again. Pressing a button during a
slow render stops it and starts over from the new view.

---

## Speed

Every frame re-reads the whole file, so the cost is mostly the card: about
**17 µs per triangle**. The estimates below use the rates already measured on
this board:

- ~0.6 ms per card read command
- ~0.17 ms per 512-byte block by DMA
- 0.5 µs per pixel to the panel at 12 bpp

They also assume about 10 µs of CPU per triangle, which overlaps the card DMA.

| Model | Triangles | File | Full frame (est.) | fps (est.) |
|---|---:|---:|---:|---:|
| `CUBE.STL` | 12 | 0.7 KB | ~6 ms | ~150 |
| `ICOSPH.STL` | 320 | 16 KB | ~8 ms | ~120 |
| `GEAR.STL` | 384 | 19 KB | ~9 ms | ~110 |
| `TORUS.STL` | 1,152 | 58 KB | ~22 ms | ~45 |
| `KNOT.STL` | 12,800 | 640 KB | ~225 ms | ~4 (draft ~120) |
| a typical downloaded part | 100,000 | 5 MB | ~1.8 s | draft |

Rule of thumb: about **800 triangles at 60 fps** and **1,700 at 30 fps**. At
128×128 anything beyond a few thousand triangles looks solid anyway (see the
knot).

### Measuring

Connect USB and open a serial monitor (any baud rate). You get a line per
opened file and one per second while frames are drawn. The numbers here are
only an example:

```
open /TORUS.STL  tris 1152  bad 0  closed 1  runs 1  blocks 113  scan ms 21
X-RAY full  fps 45  render 19800us  lcd 2100us  edges 1728  pixels 8531
```

- `render`: card streaming plus drawing, per frame.
- `lcd`: time spent waiting for the previous frame's panel transfer.
- `edges`, `pixels`: how much line drawing a frame took.

---

## How it works

The full reasoning is in the header of [src/StlRender.h](src/StlRender.h).

- **RAM is the limit, not the CPU.** CHGfx's 8 KB framebuffer, its LUT, the DMA
  buffers and the SD library leave about 2 KB. So no mesh is ever loaded. Each
  frame streams the file with one multi-block read (CMD18) per fragment. Every
  50-byte triangle is transformed and drawn while the next 512-byte block
  arrives by DMA.
- **No floating point.** Converting an IEEE-754 float to fixed point is one
  shift by its exponent. A scan when the file opens finds the bounding box and
  one shift for the whole model. After that each vertex is 3 shifts, 9
  multiplies (rotation with the fit-to-screen scale folded in) and 1 divide
  (perspective).
- **Each edge drawn once, with no adjacency data.** In a closed mesh every edge
  appears in two triangles in opposite directions. Drawing A→B only when
  `key(A) < key(B)` draws each edge exactly once and halves the line work. It
  is only exact for closed, consistently wound meshes. The scan checks for that
  with a signed hash sum over every directed edge, which is zero exactly when
  every edge is matched. Anything else falls back to drawing every edge.
- **A 4-bit z-buffer for free.** Wire colours are palette indices in brightness
  order, and a pixel is only written if the new index is higher. So the nearer
  wire wins at every crossing, whatever order the file is in.
- **The draft points share RAM with the file list.** They are never needed at
  the same time. During the scan, the raw samples sit in the part of the
  framebuffer the progress screen doesn't use.

### Memory

| | Used | Limit |
|---|---:|---:|
| Flash | 42,824 B | 50,944 B |
| Static RAM | 17,352 B | 18,416 B (a fixed 2 KB stack sits above it) |

About 1.8 KB of the RAM is hot code run from SRAM: the transform, line and
block-parsing loops. Flash has 3 wait states at 48 MHz.

---

## Testing without hardware

Everything under `tools/` runs on a PC. The C++ tools need a compiler: g++,
clang, or `pip install ziglang`. Set `CXX` to choose one.

| Tool | What it does |
|---|---|
| `tools/preview.py model.stl [out.gif]` | Renders a model with the real renderer and prints edge and pixel counts. Useful for checking a file before copying it to the card. Options: `--mode front`, `--draft`, `--zoom`, `--pitch` |
| `tools/make_samples.py` | Regenerates the models in `sample/` |
| `tools/sim/accuracy.cpp` | Checks the fixed-point pipeline against double precision over 7 views. Build with `-DSTL_TEST_HOOK` together with `src/StlRender.cpp` |
| `tools/sim/make_edge_cases.py` | Tiny, huge, far-from-origin and NaN models for the accuracy check |
| `tools/sim/run_app.py CARD SCRIPT OUT` | Runs the **whole sketch** on the PC against a folder standing in for the SD card, driven by a button script. Writes panel snapshots. It flags card access during a panel transfer and reads past a file fragment, and it fragments every file on purpose |

The accuracy check passes on all the samples and edge cases. The worst error
is 0.1 px at ×1 zoom and under 0.5 px at ×16, for models from micrometres to
kilometres across and far from the origin.

## Repository layout

```
CHStlView.ino        file browser, viewer, controls, HUD, SD streaming
src/StlRender.*      the renderer: scan, transform, clip, lines, draft
src/SD/              Arduino SD 1.3.0, modified for CH32X035 DMA streaming (GPL v3)
src/CHGame.*         button and frame helpers for the CHGame board
sample/              test models and the preview above
tools/               PC-side preview, sample generator and simulators
```

## Roadmap

- Measure on hardware, then tune `SLOW_MS` and `DRAFT_POINTS`.
- ASCII STL: a text parser feeding the same record pipeline. It would be about
  5× slower, since the file is 5× bigger.
- Long file names: the FAT directory has them, but the SD library skips them.
- Feature edges: hide edges between coplanar triangles, so CAD parts draw as
  clean line drawings rather than showing their triangulation.

## Credits

- The SD library in `src/SD` is Arduino SD 1.3.0 (SparkFun, and William
  Greiman's sdfatlib), with CH32X035 DMA streaming changes from
  [CHSpriteView](https://github.com/filmote/CHSpriteView) and this project.
  Every change is marked `CHGAME:`.
- `src/CHGame.*` comes from CHSpriteView, originally by Simon (filmote).
- Graphics by [CHGfx](https://github.com/bateske/CHGfx). Its 5×7 font, used by
  the PC simulator, is Adafruit's GLCD font (BSD).

## License

MIT for this project's own code; see [LICENSE](LICENSE). The SD library in
`src/SD` keeps its original **GPL v3** licence.
