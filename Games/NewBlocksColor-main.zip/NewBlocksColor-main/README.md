# New Blocks on the Kid — Colour Edition

[![License: GPL v3](https://img.shields.io/badge/license-GPLv3-blue.svg)](LICENSE)
![Platform: CHGame](https://img.shields.io/badge/platform-CHGame%20%28CH32X035%29-e05d44)
![Built with Arduino](https://img.shields.io/badge/built%20with-Arduino-00979D)

**One block at a time, in full colour.** A stacking game for the
**CHGame** handheld, ported from Kevin Bates's 1-bit
[Arduboy Game Jam #5 entry](https://github.com/bateske/NewBlocksOnTheKid)
and rebuilt around a 65,536-colour plasma that reacts to the game as
you play.

![Title screen, play, a row clear, confetti, a full well, the stack shattering, and the game over banner](docs/preview.png)

The rules are the 2020 original's, untouched. One block falls at a time
into a well five columns wide. Steer it, drop it, fill a row to clear
it, and don't let the stack reach the top. Everything else is new:

- **A living background.** A four-term plasma computed per pixel at the
  panel's full RGB565 depth, about 80 frames a second. It tints itself
  towards the colour of the falling piece, and it takes a slow breath
  when a piece lands and a deeper one when a row clears.
- **A palette that is never the same twice.** All sixteen colours are
  rebuilt every frame from a hue that walks the colour wheel every ~12 s,
  so blocks, sparks, frame and text drift through the spectrum together.
- **Sparks in the colour of whatever threw them.** 112 particles with
  sub-pixel motion, streaks and bounces. A landing sparks in the piece's
  own hue, and a row clear throws its five colours back out of the well
  as confetti.
- **Real type.** Bold 16 px and 12 px faces instead of a doubled 5×7
  font, with the title and game over words set as a bobbing rainbow wave.
- **A soundtrack.** Scott Joplin's *The Entertainer* on the title screen,
  a game over sting, and a dozen short effects on the piezo, ranked so
  the important ones are never cut off.

## How to play

A block appears at the top of the well and falls one row at a time.
Move it left and right as it falls, or slam it to the bottom. When it
lands, the next one starts. The game ends when the stack reaches the
top of the well.

| Score | For |
|---:|---|
| **+1** | every block that lands |
| **+20** | every full row cleared |
| **−1** | every row you push a falling block back **up** |

### Controls

| Button | Action |
|---|---|
| **Left / Right** | Move the falling block one column |
| **A / B** | Hard drop: instant, with a beam down the well |
| **Down** (hold) | Soft drop: falls about nine times faster, and still lands and scores normally |
| **Up** | Push the block back up one row, for a point. At zero points it does nothing |
| **Start** | Pause |
| **Select** | Mute or unmute, from any screen |

Press any button on the title screen to start. Your best score is shown
in the left column and lasts until the power goes off.

## The hardware

The game targets the **CHGame**, a handheld built around WCH's RISC-V
microcontroller.

| | |
|---|---|
| MCU | WCH CH32X035G8U6, RISC-V at 48 MHz. 50,944 B of flash for the sketch and 20 KB of SRAM |
| Display | ST7735S 128×128 TFT, RGB565, on SPI1 at 24 MHz with DMA |
| Controls | D-pad, A, B, Start and Select |
| Sound | Piezo on PB10 |

The panel is the same width as the Arduboy's and twice the height, and
all of the extra height goes into the well: 15 rows of 8 px cells
instead of 10 rows of 6.

## Building and flashing

### 1. Install the CHGame board package

In the Arduino IDE, open **File ▸ Preferences** and add this URL to
**Additional boards manager URLs**:

```
https://github.com/bateske/CH32SerialBoot/releases/latest/download/package_chgame_index.json
```

Then open **Tools ▸ Board ▸ Boards Manager**, search for **CHGame**,
and install **CHGame Boards**.

With `arduino-cli` instead:

```bash
arduino-cli core update-index --additional-urls https://github.com/bateske/CH32SerialBoot/releases/latest/download/package_chgame_index.json
```

```bash
arduino-cli core install CHGame:ch32v --additional-urls https://github.com/bateske/CH32SerialBoot/releases/latest/download/package_chgame_index.json
```

### 2. Install CHGfx 1.2.0 or later

The game draws with [CHGfx](https://github.com/bateske/CHGfx) and needs
its bundled fonts, which arrived in 1.2.0. Either download the repository
as a ZIP and use **Sketch ▸ Include Library ▸ Add .ZIP Library**, or
clone it from inside the `libraries` folder of your sketchbook:

```bash
git clone https://github.com/bateske/CHGfx.git
```

That is the only library to install. The sound library, CHGameSound,
ships inside this repository in [`src/CHGameSound`](src/CHGameSound/)
and builds as part of the sketch.

### 3. Get the game

```bash
git clone https://github.com/bateske/NewBlocksColor.git
```

The folder must be called `NewBlocksColor` to match the `.ino` file.
If you download a ZIP from GitHub, rename `NewBlocksColor-main` to
`NewBlocksColor` before opening it.

### 4. Build and upload

In the Arduino IDE, open `NewBlocksColor.ino` and choose:

- **Tools ▸ Board ▸ CHGame Boards ▸ CHGame**
- **Tools ▸ Optimize ▸ Faster (-O2)**
- **Tools ▸ Port**: the CHGame's USB serial port

Then press **Upload**. The uploader switches the CHGame into its
bootloader and back to the game by itself.

With `arduino-cli`, from the folder that contains `NewBlocksColor/`
(replace `COM5` with your port):

```bash
arduino-cli compile -b CHGame:ch32v:CHGame:opt=o2std -u -p COM5 NewBlocksColor
```

**Use -O2.** The default *Smallest (-Os)* setting also builds and runs,
but it is 10–20% slower in the drawing code, and this game spends its
whole frame there.

| Build | Flash | SRAM |
|---|---:|---:|
| Faster (-O2) | 47,700 B of 50,944 (93%) | 17,696 B of 20,480 (86%) |
| Smallest (-Os) | 41,704 B (81%) | 16,756 B (81%) |

The IDE prints *"Low memory available, stability problems may occur."*
It is safe to ignore here. The warning assumes heap and `String` use,
and this sketch has neither. Its measured worst-case stack is about
800 B against 2,784 B free.

## How it works

Every frame is a single `gfx_stream()` composite. CHGfx normally makes
you choose between a 16-colour framebuffer for sprites and a streaming
mode for full-colour procedural effects. This game uses both at once:

```mermaid
flowchart TD
    G["Game: board, input, particles, text"] --> F["4 bpp framebuffer of palette roles<br/>index 0 = nothing here"]
    F --> S{{"gfx_stream callback, for each pixel"}}
    S -- "index 1–15" --> P["palette colour,<br/>rebuilt every frame"]
    S -- "index 0" --> Q["plasma pixel, full RGB565,<br/>dimmed inside the well"]
    P --> L["SPI1 + DMA to the ST7735S"]
    Q --> L
```

The framebuffer never reaches the panel; it is a stencil. Nothing in
the game is stored as a colour, only as a role (block hue *n*, its
lighter twin, frame, text), so re-tinting the whole game is a matter
of rewriting sixteen palette entries.

The full story is in **[docs/DESIGN.md](docs/DESIGN.md)**. It covers
how the sixteen palette slots are spent, the four attempts it took to
make the background's zoom perfectly smooth, the art-direction choices
that were settled by measuring rather than guessing, and the sound
priority rules.

## What changed from the Arduboy original

- **Twice the screen.** The 128×128 colour panel replaces the 128×64
  OLED, and the extra height all goes into the well.
- **New controls.** Down is now a held soft drop rather than a hard
  drop, Up pushes the block back up for a point (it did nothing before),
  Start pauses, and Select mutes.
- **Two bugs fixed.** An out-of-bounds read in the board logic, and a
  hard drop onto an adjacent block that could delete the piece. Both are
  described in [the design notes](docs/DESIGN.md#two-bugs-from-the-original-fixed).
- **Ported off AVR.** `PROGMEM`, FixedPoints and Arduboy2 are gone; the
  CH32X035's flat address space and plain integer maths replace them.

## Repository layout

| Path | What is in it |
|---|---|
| `NewBlocksColor.ino` | Game rules, board, input, intro and game over |
| `Plasma.h` | The background and the per-pixel composite pass |
| `Palette.h` | The sixteen palette roles and the hue walk |
| `Particles.h` | The 112-particle system, physics and emitters |
| `Text.h` | Outlined text over a moving background |
| `Sound.h` | Music and effect playback, and the priority rules |
| `Music.h`, `MusicOver.h` | Title music and game over sting as Playtune scores (generated) |
| `Sfx.h` | The sound effects as effect steps (generated) |
| `Common.h` | Screen layout and the xorshift RNG |
| `Words.h` | The praise and the commiserations |
| `src/CHGameSound/` | Vendored copy of the CHGameSound library (MIT) |
| `music/` | MIDI sources for `Music.h` and `MusicOver.h` |
| `tools/gen_sfx.py` | Regenerates `Sfx.h` from effect parameters |
| `tools/midi2score.py`, `tools/score_tool.py` | Regenerate the music headers from `music/` |
| `tools/preview_sound.cpp` | Renders the music and effects to a WAV on a desktop, through the real sound engine |
| `docs/DESIGN.md` | Design notes |

The generators are standard-library Python 3. Run them from the sketch
folder:

```bash
python tools/gen_sfx.py
```

```bash
python tools/midi2score.py music/entertainer-swing.mid Music.h --name music --voice 0=t0:high --loop
```

```bash
python tools/midi2score.py music/gameover.mid MusicOver.h --name musicOver --voice 0=t0:high
```

The build line for the WAV previewer is at the top of
[`tools/preview_sound.cpp`](tools/preview_sound.cpp).

## Credits

- **Game design and original code:** Kevin Bates, 2020, for Arduboy
  Game Jam #5 ([NewBlocksOnTheKid](https://github.com/bateske/NewBlocksOnTheKid)).
- **Music:** *The Entertainer* by Scott Joplin (1902), public domain.
- **Sound effects:** generated with the algorithm from the Effects tab
  of cloud.arduboy.com. Each one in `Sfx.h` carries the `// SFX:` line
  that reopens it there.
- **Libraries:** [CHGfx](https://github.com/bateske/CHGfx) for graphics
  and CHGameSound for audio.

## License

[GNU General Public License v3.0](LICENSE), the same as the original
game. The vendored CHGameSound library in `src/CHGameSound/` is
MIT-licensed; see [its license](src/CHGameSound/LICENSE).
