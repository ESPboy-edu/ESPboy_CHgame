"""Build and run the whole CHStlView sketch on the PC (tools/sim/appsim).

    python tools/sim/run_app.py CARD_DIR SCRIPT OUT_DIR

CARD_DIR is a folder standing in for the microSD card, SCRIPT a button
script (see appsim/appsim.cpp), OUT_DIR where the panel snapshots go: one
PNG each plus sheet.png with all of them. Exits non-zero if the simulator
reported a bug (a card read while the panel was being fed, a read off the
end of a file fragment, ...).

Needs a C++ compiler (g++, clang++, or `pip install ziglang`; CXX
overrides) and the CHGfx library installed in the Arduino sketchbook, for
its font (CHGFX_SRC overrides the path).
"""
import os, re, subprocess, sys
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
SKETCH = os.path.abspath(os.path.join(HERE, '..', '..'))
sys.dont_write_bytecode = True     # keep the project folder clean
sys.path.insert(0, os.path.join(SKETCH, "tools"))
import preview  # palette and compiler discovery


def chgfx_src():
    if os.environ.get('CHGFX_SRC'):
        return os.environ['CHGFX_SRC']
    try:
        book = subprocess.run(['arduino-cli', 'config', 'get', 'directories.user'],
                              capture_output=True, text=True).stdout.strip()
    except OSError:
        book = ''
    for base in [book, os.path.join(os.path.expanduser('~'), 'Documents', 'Arduino')]:
        p = os.path.join(base, 'libraries', 'CHGfx', 'src')
        if base and os.path.exists(os.path.join(p, 'CHGfx_font.h')):
            return p
    sys.exit('CHGfx not found: set CHGFX_SRC to its src folder')


def build(out):
    ino = open(os.path.join(SKETCH, 'CHStlView.ino')).read()
    src = os.path.join(SKETCH, 'src').replace('\\', '/')
    ino = ino.replace('#include "src/SD/SD.h"', '#include "sdmock.h"')
    ino = ino.replace('#include "src/', '#include "' + src + '/')
    gen = os.path.join(out, 'CHStlView_host.cpp')
    with open(gen, 'w') as f:
        f.write('#include <Arduino.h>\n#line 1 "CHStlView.ino"\n' + ino)
    exe = os.path.join(out, 'appsim.exe' if os.name == 'nt' else 'appsim')
    cmd = preview.find_cxx() + [
        '-O1', '-g', '-std=c++17', '-Dstl_host_fb=gfx_fb',
        '-I', os.path.join(HERE, 'appsim'), '-I', chgfx_src(),
        '-o', exe, gen,
        os.path.join(HERE, 'appsim', 'appsim.cpp'),
        os.path.join(SKETCH, 'src', 'CHGame.cpp'),
        os.path.join(SKETCH, 'src', 'StlRender.cpp'),
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        sys.exit(r.stdout + r.stderr)
    return exe


def main():
    card, script, out = sys.argv[1:4]
    os.makedirs(out, exist_ok=True)
    for f in os.listdir(out):
        if f.endswith('.fb') or f.endswith('.png'):
            os.remove(os.path.join(out, f))
    exe = build(out)
    r = subprocess.run([exe, card, script, out], capture_output=True, text=True)
    sys.stdout.write(r.stdout + r.stderr)

    names = [l.split()[-1] for l in r.stdout.splitlines() if '] snap ' in l]
    tiles = []
    for n in names:
        img = preview.to_image(open(os.path.join(out, n + '.fb'), 'rb').read(), 2).convert('RGB')
        img.save(os.path.join(out, n + '.png'))
        tiles.append((n, img))
    if tiles:
        cols = min(4, len(tiles))
        rows = (len(tiles) + cols - 1) // cols
        w, h = tiles[0][1].size
        sheet = Image.new('RGB', (cols * (w + 8), rows * (h + 22)), (40, 40, 40))
        d = ImageDraw.Draw(sheet)
        for i, (n, img) in enumerate(tiles):
            x, y = (i % cols) * (w + 8), (i // cols) * (h + 22)
            sheet.paste(img, (x, y + 18))
            d.text((x + 2, y + 3), n, fill=(230, 230, 230))
        sheet.save(os.path.join(out, 'sheet.png'))
    sys.exit(r.returncode)


if __name__ == '__main__':
    main()
