/*
 * Text.h - legible text over a moving background, in two registers.
 *
 * The original drew white text on black and that was the end of it. Here
 * every glyph sits over a plasma that is a different colour under every
 * letter and changes underneath them while you read, so plain text
 * disappears wherever the background happens to agree with it.
 *
 * The fix is an outline, not a panel. A filled black box behind the
 * score would read fine but it would punch a dead rectangle in the
 * effect. Stamping the glyph in C_INK around the outside and then again
 * in colour on top costs a few passes over a short string and keeps the
 * background visible right up to the letterform - and because C_INK is a
 * real opaque palette entry rather than the stencil hole, the outline is
 * guaranteed black no matter what the plasma is doing.
 *
 * SMALL TEXT AND DISPLAY TEXT ARE DIFFERENT JOBS
 * ----------------------------------------------
 * Small text - the BEST/SCORE labels, the "Nice!" popups, the "+20" - is
 * the built-in 5x7 at 1:1. It is 6 px wide per character, which is what
 * makes seven characters fit a 42 px column exactly, and the whole
 * side-column layout is built on that number.
 *
 * Display text - the score itself, the title, the game over word - used
 * to be that same 5x7 font at scale 2, i.e. every pixel drawn as a 2x2
 * block. That is not a bigger font, it is the same font with bigger
 * pixels, and on a 128x128 panel it looks like exactly what it is.
 * Those now use real 16 px and 12 px faces from the library at 1:1, so
 * the curves are curves and the stems are one pixel wide.
 *
 * TWO ORIGINS, WHICH IS THE ONE THING TO WATCH
 * --------------------------------------------
 * CHGfx follows Adafruit_GFX here: for the built-in font `y` is the TOP
 * of the glyph box, for a custom font `y` is the BASELINE. Both
 * conventions are useful and this file exposes both rather than hiding
 * one:
 *
 *   textOut()     - y is the top. Adds gfx_fontBaseline() itself, so it
 *                   is correct for either font. Use for small text.
 *   textOutBase() - y is the baseline, the natural way to place a real
 *                   face. Use for display text.
 *
 * Bottom-aligning is why the second one exists: the score switches
 * between a 16 px and a 12 px face as it grows a digit, and two faces
 * drawn to a common baseline sit still while two faces drawn to a common
 * top visibly jump.
 */
#pragma once

#include <CHGfx.h>
#include "Palette.h"

/* Advance of one built-in glyph. The side-column layout depends on this
 * being 6: seven characters is 42 px is exactly one column. */
#define TEXT_ADV(scale) (6 * (scale))

/* Width in the CURRENTLY SELECTED font. Call gfx_setFont() first. */
static inline int textW(const char *s, uint8_t scale)
{
    return gfx_textWidthScaled(s, scale);
}

/*
 * The black surround. Four cardinal stamps always; the diagonals as well
 * whenever the strokes are thick enough for a cardinal-only outline to
 * leave visible notches at the corners - which means at scale 2 and up,
 * and for every custom face, since those are all display sizes sitting
 * on the busiest part of the picture.
 */
static void inkOutline(int x, int yb, const char *s, uint8_t scale, bool heavy)
{
    gfx_textScaled(x - 1, yb,     s, C_INK, scale);
    gfx_textScaled(x + 1, yb,     s, C_INK, scale);
    gfx_textScaled(x,     yb - 1, s, C_INK, scale);
    gfx_textScaled(x,     yb + 1, s, C_INK, scale);
    if (heavy) {
        gfx_textScaled(x - 1, yb - 1, s, C_INK, scale);
        gfx_textScaled(x + 1, yb - 1, s, C_INK, scale);
        gfx_textScaled(x - 1, yb + 1, s, C_INK, scale);
        gfx_textScaled(x + 1, yb + 1, s, C_INK, scale);
    }
}

/* y is the TOP of the text, whichever font is selected. */
static void textOut(int x, int y, const char *s, uint8_t c, uint8_t scale)
{
    const int yb = y + gfx_fontBaseline() * scale;
    inkOutline(x, yb, s, scale, scale > 1 || gfx_font() != nullptr);
    gfx_textScaled(x, yb, s, c, scale);
}

/* y is the BASELINE. For display text in a real face. */
static void textOutBase(int x, int yb, const char *s, uint8_t c)
{
    inkOutline(x, yb, s, 1, true);
    gfx_text(x, yb, s, c);
}

static void textOutBaseCentred(int cx, int yb, const char *s, uint8_t c)
{
    textOutBase(cx - gfx_textWidth(s) / 2, yb, s, c);
}

/* Unsigned decimal. Runs twice a frame on a number below 65536. */
static char *fmtU(char *buf, uint32_t v)
{
    char tmp[11];
    int n = 0;
    do { tmp[n++] = (char)('0' + (v % 10)); v /= 10; } while (v);
    for (int i = 0; i < n; i++) buf[i] = tmp[n - 1 - i];
    buf[n] = 0;
    return buf;
}

/* Right-aligned so the score grows leftward into the empty column
 * instead of drifting off the edge of the screen. Baseline-anchored:
 * every caller is display text in a real face. */
static void numOutRightBase(int rightX, int yb, uint32_t v, uint8_t c)
{
    char buf[12];
    fmtU(buf, v);
    textOutBase(rightX - gfx_textWidth(buf), yb, buf, c);
}
