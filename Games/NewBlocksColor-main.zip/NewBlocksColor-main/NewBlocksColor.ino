/*
 * ============================================================
 *   N E W   B L O C K S   O N   T H E   K I D
 *   colour edition  --  CHGame, CH32X035 @ 48 MHz + ST7735
 * ============================================================
 *
 * A port of the Arduboy Game Jam #5 entry to the CHGame handheld,
 * copyright Kevin Bates 2020, with the graphics taken somewhere it could
 * not go on a 1-bit 128x64 OLED.
 *
 * The rules are the original rules. One block at a time, falling, five
 * columns wide, move it left and right, drop it early if you want to.
 * A point for stacking, twenty for a full row, and it ends when the
 * stack reaches the top.
 *
 * THE CONTROLS
 * ------------
 *   LEFT / RIGHT   one column, as they always did
 *   A / B          hard drop - instant, with the beam
 *   DOWN           soft drop: held, the piece falls nine times faster,
 *                  and it is still a fall, so it still lands normally
 *   UP             one row back UP the well, and it costs a point. See
 *                  the note in moveCycle(); nothing else in this game
 *                  takes points away, and at zero the button is dead
 *   START          pause, during play
 *   SELECT         mute, from anywhere, at any time
 *
 * WHAT IS ACTUALLY DIFFERENT
 * --------------------------
 * 1. TWICE THE PANEL, ALL OF IT IN THE WELL. 128x128 instead of 128x64,
 *    so the well is 15 rows of 8 px cells instead of 10 rows of 6.
 *
 * 2. NO gfx_flush(). Every frame is a gfx_stream() composite: game
 *    elements go into the 4 bpp framebuffer as a stencil, and the stream
 *    callback fills every hole in it with a procedurally generated
 *    plasma at the full 65,536 colours the panel can show. See Plasma.h;
 *    that file is the centre of gravity of this whole port.
 *
 * 3. THE PALETTE IS NEVER THE SAME TWICE. All sixteen slots are rebuilt
 *    every frame from a hue that walks slowly round the wheel, so the
 *    blocks, the sparks, the frame and the text all drift through the
 *    spectrum together. Nothing is stored as a colour; everything is
 *    stored as a role - which is also why every block can carry a glint
 *    in a lighter tone of its own hue rather than a shared white one.
 *    See Palette.h.
 *
 * 4. THE PARTICLE SYSTEM GREW UP. 112 particles instead of 40, positions
 *    in sub-pixel fixed point, velocity streaks and real bounces. Every
 *    spark carries the hue of whatever threw it and cools white -> that
 *    hue lightened -> that hue -> dim, so a landing sparks in the colour
 *    of the piece and a row clear throws the row back out of the well as
 *    confetti in its own five colours. See Particles.h.
 *
 * 5. REAL TYPE, NOT DOUBLED PIXELS. The score, the title and the game
 *    over word were the built-in 5x7 font at scale 2 - the same font
 *    with 2x2 pixels, which on a 128x128 panel looks like exactly that.
 *    They now use the library's 16 px and 12 px bold faces at 1:1, so
 *    curves are curves and stems are one pixel. See Text.h.
 *
 * 6. THE BACKGROUND ANSWERS THE GAME, AND WEARS ITS COLOURS. The plasma
 *    tints itself towards whichever piece is falling, and events push a
 *    smooth zoom through it - a small breath when a piece settles, a
 *    deeper, longer one when a row clears. Everything eases; nothing
 *    jumps. See the note above plasmaPulse() in Plasma.h for why that
 *    matters more than it sounds like it should.
 *
 * 7. IT HAS A SOUNDTRACK. The Entertainer, as a Playtune score on the
 *    CHGameSound library's hardware tone, from 300 ms after power-on
 *    for as long as the title is up. The beeps became generated sound
 *    effects - a whoosh and a slam for a hard drop, a rising trill for a
 *    row, a crackle for every row of the stack as it comes apart - and a
 *    piece settling keeps the original's tone that rises with the
 *    height of the stack. See Sound.h for how one square wave carries
 *    all of it.
 *
 * 8. THE TITLE AND THE GAME OVER WORD ARE A RAINBOW WAVE. Each letter
 *    one hue step on from the last, the whole ramp drifting with the
 *    blocks' hue, every letter bobbing on a sine a little behind its
 *    neighbour. See textGradient in Palette.h for where the colours
 *    come from. The title also waits for a button now, rather than
 *    starting on its own.
 *
 * 9. THE OTHER FOUR BUTTONS DO SOMETHING. The Arduboy version had one
 *    verb, drop, on three buttons. DOWN is now a soft drop rather than a
 *    fourth way to spell the hard one; UP shoves the piece back up the
 *    well for a point off the score; START pauses into the game over
 *    banner; SELECT mutes, from any screen, and says so in the corner
 *    nearest the button.
 *
 * CONTRAST, WHICH DROVE MOST OF THE ART DIRECTION
 * -----------------------------------------------
 * This panel is about 200 nits and its contrast ratio is not good. Mid
 * tones turn to mud and thin lines disappear. So: everything that
 * matters is fully saturated, everything that does not is near black,
 * the plasma runs at an eighth brightness behind the well and full
 * brightness outside it, every block carries a black gutter and a three
 * pixel specular in its own colour, the frame and the score are keyed
 * opposite the plasma so they can never drift into agreement with it,
 * and every glyph is outlined in black rather than sat on a panel.
 * Nothing on screen is a mid grey, because a mid grey on this display is
 * nothing at all.
 *
 * Most of the numbers above were picked by rendering the same frame
 * several ways and looking at them side by side, not by taste. Two stops
 * of dimming, a full top-and-left bevel, a shared white glint and an
 * even five-way spark fade all looked fine alone and all lost to the
 * versions here once there were seventy saturated blocks on screen.
 *
 * BUILD
 * -----
 * Board: CHGame. Tools > Optimize > Faster (-O2) - the default -Os
 * costs 10-20% on the drawing primitives and this sketch spends its
 * whole frame in them.
 */
#include <CHGfx.h>

/*
 * The two display faces. Included here rather than from Text.h on
 * purpose: the Arduino builder decides which library include paths to
 * add by scanning the .ino only, so a header reached solely through
 * another header can fail to resolve. CHGfx.h above puts the library on
 * the path; these then find it.
 *
 * 1866 + 1444 bytes of flash between them, and every glyph is drawn at
 * 1:1 - see the note in Text.h about why the old scale-2 built-in font
 * was not actually a bigger font.
 */
#include <fonts/CHGfx_SansBold16.h>
#include <fonts/CHGfx_SansBold12.h>

/* The sound library is not an installed library: an unmodified copy of
 * CHGameSound lives in src/CHGameSound, which the builder compiles as part
 * of the sketch, so the relative include needs no include path. Naming it
 * here with angle brackets would pull in an installed copy as well. */
#include "src/CHGameSound/CHGameSound.h"

#include "Common.h"
#include "Palette.h"
#include "Plasma.h"
#include "Text.h"
#include "Words.h"
#include "Particles.h"
#include "Sound.h"

/* ------------------------------------------------------------------ */
/* Palette storage                                                     */
/* ------------------------------------------------------------------ */
/* Deliberately not handed to gfx_setPalette(). The composite pass reads
 * this array directly at full RGB565, so the driver never has to rebuild
 * its 256-entry expansion LUT - which would otherwise be the price of
 * changing the palette every single frame. */
uint16_t pal[16];

/* ------------------------------------------------------------------ */
/* Game state                                                          */
/* ------------------------------------------------------------------ */
enum : uint8_t { GS_PLAY = 1, GS_INTRO = 8, GS_OVER = 9 };

static uint8_t gameBoard[BOARD_W][BOARD_H];   /* 0 empty, 1 landed, 2 falling */
static uint8_t boardHue[BOARD_W][BOARD_H];    /* 0..4, which block hue         */

static uint8_t gameState = GS_INTRO;
static uint8_t gameSpeed = 26;                /* frames per row of fall        */
static uint8_t cycleCount;

/*
 * Soft drop. DOWN held divides the fall period by about nine, which at
 * ~80 fps is a row every 37 ms - fast enough to be a drop, slow enough
 * that you can still see which column it is in and let go a row early.
 * It is a rate, not an event: the piece falls through boardCycle() the
 * way it always does, so it still ticks, still smears, and still scores
 * by the height it comes to rest at. The instant drop is A and B, and
 * the beam belongs to them.
 */
#define SOFT_SPEED 3
static bool softDrop;

/* START, during play only. */
static bool paused;

static uint16_t currentScore, highScore;

/* Camera shake, exactly the three flavours the original had. */
static uint8_t shakeState, shakeCount;
static int8_t  shakeX, shakeY;

/* Sequence counters for the intro and the game over. */
static uint8_t startStage, endStage, stageCount;

/* The title prompt's own blink clock - see doGameStart(). */
#define PROMPT_HALF 22
static uint8_t promptCount;
static uint8_t endWord;

/* Latched button presses, consumed by moveCycle() as in the original.
 * DOWN is not among them any more - it is read as a held level rather
 * than an edge, because a soft drop is a state and not an event. */
static bool moveRight, moveLeft, moveUp, aButton, bButton;

/* Hard drop beam. */
static uint8_t dropCount, dropCol, dropRowFrom, dropRowTo, dropHue;

/* Which of the five hues the falling piece is wearing. The plasma tints
 * itself to match it, so it has to be recomputed every frame - the hue
 * INDEX is fixed for the life of the piece but the wheel angle that
 * index maps to is drifting the whole time. */
static uint8_t activeHueIdx;

/* Falling piece afterimage. */
static uint8_t smearCol, smearRow, smearLife;

/* The slow hue walk. 16.6 fixed so it can advance by a fraction of a
 * step per frame - a full trip round the wheel takes about 12 seconds,
 * which is slow enough to feel like drift and fast enough to notice. */
static uint16_t hueAccum;
static uint8_t  baseHue;

static bool seeded;

/* ------------------------------------------------------------------ */
/* Buttons                                                             */
/* ------------------------------------------------------------------ */
enum : uint8_t {
    B_UP = 0x01, B_DOWN = 0x02, B_LEFT = 0x04, B_RIGHT = 0x08,
    B_A  = 0x10, B_B    = 0x20, B_SEL  = 0x40, B_START = 0x80
};

static uint8_t btnNow, btnPrev;

static void buttonsBegin(void)
{
    pinMode(PIN_BTN_UP,    INPUT_PULLUP);
    pinMode(PIN_BTN_DOWN,  INPUT_PULLUP);
    pinMode(PIN_BTN_LEFT,  INPUT_PULLUP);
    pinMode(PIN_BTN_RIGHT, INPUT_PULLUP);
    pinMode(PIN_BTN_A,     INPUT_PULLUP);
    pinMode(PIN_BTN_B,     INPUT_PULLUP);
    pinMode(PIN_BTN_SELECT, INPUT_PULLUP);
    pinMode(PIN_BTN_START,  INPUT_PULLUP);
}

/* All eight switches are to ground, so pressed reads LOW. */
static void buttonsPoll(void)
{
    uint8_t b = 0;
    if (!digitalRead(PIN_BTN_UP))     b |= B_UP;
    if (!digitalRead(PIN_BTN_DOWN))   b |= B_DOWN;
    if (!digitalRead(PIN_BTN_LEFT))   b |= B_LEFT;
    if (!digitalRead(PIN_BTN_RIGHT))  b |= B_RIGHT;
    if (!digitalRead(PIN_BTN_A))      b |= B_A;
    if (!digitalRead(PIN_BTN_B))      b |= B_B;
    if (!digitalRead(PIN_BTN_SELECT)) b |= B_SEL;
    if (!digitalRead(PIN_BTN_START))  b |= B_START;
    btnPrev = btnNow;
    btnNow  = b;

    /* Entropy, the same trick the original used: the first time a human
     * touches the machine, the clock is a random number. */
    if (!seeded && b) { rngState = micros() | 1u; seeded = true; }
}

#define justPressed(m) (((btnNow & (m)) != 0) && ((btnPrev & (m)) == 0))

/* ------------------------------------------------------------------ */
/* Block sprites                                                       */
/* ------------------------------------------------------------------ */
/*
 * One 8x8 sprite per block hue, built into RAM at boot.
 *
 *   row 0, 7 : 1 1 1 1 1 1 1 1      1 = C_INK, the gutter
 *   row 1    : 1 g g h h h h 1      g = this hue lightened, C_LIT(h)
 *   row 2    : 1 g h h h h h 1      h = this block hue, C_BLK0..+4
 *   rows 3-6 : 1 h h h h h h 1
 *
 *   INK   a one pixel black gutter all the way round. Without it, two
 *         adjacent blocks of neighbouring hues merge into one shape on
 *         this panel and the whole stack turns to soup.
 *   LIT   three pixels of specular in the top left corner, in a lighter
 *         tone of THIS block's own colour. A shared near-white glint -
 *         which is what this was first - reads as a smudge of somebody
 *         else's colour dropped on the corner; a lighter tone of the
 *         block reads as light falling on a coloured solid. Paying five
 *         palette slots for the five twins is what cost the sixth block
 *         hue, and it is worth it.
 *         (A full bevel down the whole top and left edge was also tried:
 *         it eats a fifth of the visible area of an 8x8 block and
 *         desaturates it. Three pixels buy the same read for a twelfth
 *         of the area.)
 *   hue   fully saturated, no shading. Shading a colour on a 200 nit
 *         panel just makes it darker, not rounder.
 *
 * 4 bpp, two pixels per byte, even x in the low nibble - the same
 * packing as the framebuffer, so gfx_blit() takes its fast path.
 *
 * These live in flash, not RAM, and the reason is the point of the whole
 * palette design: a sprite stores palette INDICES. The colour of hue 3
 * changes on every single frame, but the index of hue 3 is always 5, so
 * there is nothing here that ever needs to be rewritten.
 */
#define BPAIR(h) (uint8_t)((h) * 0x11)
#define BEND(h)  (uint8_t)(0x10 | (h))
#define BROW(h)  (uint8_t)(((h) << 4) | 0x01), BPAIR(h), BPAIR(h), BEND(h)
#define BEDGE    0x11, 0x11, 0x11, 0x11
#define BLOCK(h) { BEDGE,                                                      \
                   (uint8_t)((C_LIT(h) << 4) | 0x01),                          \
                   (uint8_t)(((h) << 4) | C_LIT(h)), BPAIR(h), BEND(h),        \
                   (uint8_t)((C_LIT(h) << 4) | 0x01),                          \
                   BPAIR(h), BPAIR(h), BEND(h),                                \
                   BROW(h), BROW(h), BROW(h), BROW(h),                         \
                   BEDGE }

static const uint8_t blockSpr[BLOCK_HUES][CELL * CELL / 2] = {
    BLOCK(C_BLK0 + 0), BLOCK(C_BLK0 + 1), BLOCK(C_BLK0 + 2),
    BLOCK(C_BLK0 + 3), BLOCK(C_BLK0 + 4)
};

/* ------------------------------------------------------------------ */
/* Small drawing helpers                                               */
/* ------------------------------------------------------------------ */
/* A 50% checker fill. Used for the falling piece afterimage and the drop
 * beam, where a solid colour would read as a second, real block. The
 * dither is the cheapest translucency there is on an indexed buffer. */
static void ditherRect(int x, int y, int w, int h, uint8_t c, uint8_t phase)
{
    for (int j = 0; j < h; j++)
        for (int i = ((j + phase) & 1); i < w; i += 2)
            gfx_pixel(x + i, y + j, c);
}

/*
 * Display text as a rainbow wave: the title and the game over word.
 *
 * COLOUR. Letter i is drawn in gradient slot `first + i`, and the slots
 * are a hue ramp from baseHue (see textGradient in Palette.h), so the
 * word is a static rainbow - each letter a step further round the wheel
 * than the one before - and the whole ramp drifts with baseHue at the
 * same rate as the blocks. `first` lets a second line carry on from
 * where the first left off. Only meaningful while textGradient is set.
 *
 * MOTION. Each letter rides a sine, WAVE_STEP of phase behind its
 * neighbour, so the word rolls like a flag. WAVE_AMP px each way; the
 * phase is advanced once a frame in loop().
 *
 * The pen is advanced by measuring each glyph rather than by a fixed
 * step, because the display faces are proportional - a fixed step is
 * correct for the built-in 5x7 and wrong for everything else. Summing
 * per-glyph advances gives exactly the same positions gfx_text() would,
 * since GFXfont has no kerning.
 *
 * y is the BASELINE; these are always display faces.
 */
#define WAVE_AMP   3
#define WAVE_STEP  28
static uint8_t wavePhase;

static void textWaveBase(int x, int yb, const char *s, uint8_t first, uint8_t phase)
{
    char one[2] = { 0, 0 };
    for (int i = 0; s[i]; i++) {
        one[0] = s[i];
        const int dy = ((int)sinTab[(uint8_t)(phase - i * WAVE_STEP)] - 128) * WAVE_AMP / 128;
        textOutBase(x, yb + dy, one, (uint8_t)(C_BLK0 + ((first + i) % (2 * BLOCK_HUES))));
        x += gfx_textWidth(one);
    }
}

static void textWaveBaseCentred(int cx, int yb, const char *s, uint8_t first, uint8_t phase)
{
    textWaveBase(cx - gfx_textWidth(s) / 2, yb, s, first, phase);
}

/* ------------------------------------------------------------------ */
/* Scene drawing                                                       */
/* ------------------------------------------------------------------ */
/*
 * One dot at the centre of every cell. Dimming the plasma to an eighth
 * inside the well is what makes the blocks read, but it also means an
 * empty well is a black void 40 px wide and 120 tall - and this game
 * spends a lot of its time with an almost empty well, because only one
 * block falls at a time.
 *
 * A dot per cell rather than a dotted line per column boundary: the
 * lines drew the gaps between the columns, which is the part that never
 * holds anything. Marking the slots themselves shows you where a block
 * will actually come to rest, and 75 pixels is cheaper than the 140 the
 * lines cost.
 *
 * THIS IS DRAWN FIRST, before anything else in the scene. The dots are
 * the floor of the well, not part of the furniture: everything the game
 * does happens on top of them. Drawing them with the frame put them
 * after the hard drop beam, so the beam came out perforated - a stack of
 * dots punched through the one effect that most needs to look solid.
 */
static void drawGrid(void)
{
    for (int r = 0; r < BOARD_H; r++)
        for (int c = 0; c < BOARD_W; c++)
            gfx_pixel(CELL_X(c) + CELL / 2 + shakeX,
                      CELL_Y(r) + CELL / 2 + shakeY, C_GHOST);
}

static void drawFrame(void)
{
    /* Two rings: black on the outside so the neon has an edge against
     * the full-brightness plasma, neon on the inside against the dimmed
     * plasma in the well. Either ring alone gets lost on one side. */
    gfx_rect(FRAME_X + shakeX,     FRAME_Y + shakeY,     FRAME_W,     FRAME_H,     C_INK);
    gfx_rect(FRAME_X + shakeX + 1, FRAME_Y + shakeY + 1, FRAME_W - 2, FRAME_H - 2, C_FRAME);
}

/* Every score digit sits on this line, in both faces. */
#define SCORE_BASELINE 25

static void drawHud(void)
{
    /*
     * The labels stay on the built-in 5x7. "SCORE" in SansBold12 is
     * 45 px and the column is 42, so it would not fit - and a small
     * label over a big number is the right hierarchy anyway.
     */
    textOut(9, 3, "BEST", C_TEXT, 1);
    textOut(COL_R_X + 6, 3, "SCORE", C_TEXT, 1);

    /*
     * Two display faces, chosen by digit count so the number always fits
     * the 42 px column at 1:1 with no integer scaling anywhere:
     *
     *   SansBold16   11 px/digit   3 digits = 33 px
     *   SansBold12    8 px/digit   5 digits = 40 px
     *
     * The scores are uint16_t, so five digits is the most there can ever
     * be and neither face can overflow the column. Both are drawn to the
     * SAME BASELINE rather than the same top, so when the number grows a
     * digit and changes face it stays bottom-aligned and the swap is
     * invisible; aligned by their tops the digits would visibly jump.
     */
    gfx_setFont(highScore < 1000 ? &CHGfx_SansBold16 : &CHGfx_SansBold12);
    numOutRightBase(COL_L_W - 2, SCORE_BASELINE, highScore, C_WHITE);

    gfx_setFont(currentScore < 1000 ? &CHGfx_SansBold16 : &CHGfx_SansBold12);
    numOutRightBase(GFX_W - 2, SCORE_BASELINE, currentScore, C_WHITE);

    gfx_setFont(nullptr);      /* the popups and labels want the 5x7 back */
}

static void drawBoard(void)
{
    for (int row = 0; row < BOARD_H; row++) {
        for (int col = 0; col < BOARD_W; col++) {
            uint8_t v = gameBoard[col][row];
            if (!v) continue;
            /* The live piece gets no marker of its own. It used to
             * strobe a white rim, which was legible but sat a flashing
             * white box on top of the one block whose colour matters
             * most - and it is already the only block that is moving,
             * the only one with a smear behind it, and now the one the
             * entire background has tinted itself to match. */
            gfx_blit(blockSpr[boardHue[col][row]], CELL_X(col) + shakeX,
                     CELL_Y(row) + shakeY, CELL, CELL, -1);
            (void)v;
        }
    }

    if (smearLife) {
        smearLife--;
        ditherRect(CELL_X(smearCol) + 1 + shakeX, CELL_Y(smearRow) + 1 + shakeY,
                   CELL - 2, CELL - 2, C_GHOST, smearLife);
    }
}

/* The streak a hard drop leaves behind it. The original drew a one pixel
 * line with a random one pixel wobble; this is a three pixel beam with a
 * white core, which on a colour panel reads as speed instead of noise. */
static void drawDropBeam(void)
{
    if (!dropCount) return;
    dropCount--;
    const int x  = CELL_X(dropCol) + CELL / 2 + shakeX;
    const int y0 = CELL_Y(dropRowFrom) + shakeY;
    int h = CELL_Y(dropRowTo) - CELL_Y(dropRowFrom);
    if (h <= 0) return;
    gfx_vline(x - 1, y0, h, C_GHOST);
    gfx_vline(x + 1, y0, h, C_GHOST);
    gfx_vline(x,     y0, h, (dropCount & 1) ? C_WHITE : C_LIT(C_BLK0 + dropHue));
}

/* ------------------------------------------------------------------ */
/* Board rules - the original logic, with three genuine bugs fixed      */
/* ------------------------------------------------------------------ */
static void newPart(void);
static void partLanded(int col);
static void partStopped(int col, int row);
static void clearRow(void);

static void boardCycle(void)
{
    for (int row = BOARD_H - 1; row >= 0; row--) {
        for (int col = BOARD_W - 1; col >= 0; col--) {
            if (gameBoard[col][row] != 2) continue;

            /* Defensive: a live piece should never be on the bottom row,
             * because it is turned into a landed one on the way there. */
            if (row >= BOARD_H - 1) {
                gameBoard[col][row] = 1;
                partStopped(col, row);
                return;
            }

            /*
             * BUG FIX. The original read gameBoard[col][row + 2] with no
             * bounds check, which for a piece one row above the floor
             * indexes one past the end of the column - and for the last
             * column, one past the end of the array entirely. It usually
             * got away with it because the byte it landed on happened to
             * hold a 2 rather than a 1, so the test failed and the piece
             * fell through to the "about to be on the ground" branch,
             * which is the correct answer. Making that explicit costs a
             * compare and stops it depending on the memory layout.
             */
            const bool solidTwoBelow = (row + 2 < BOARD_H) && (gameBoard[col][row + 2] == 1);
            const bool solidOneBelow = (gameBoard[col][row + 1] == 1);

            if (solidTwoBelow) {
                if (solidOneBelow) {         /* something arrived under it late */
                    gameBoard[col][row] = 1;
                    partStopped(col, row);
                } else {
                    gameBoard[col][row + 1]  = 1;
                    boardHue[col][row + 1]   = boardHue[col][row];
                    gameBoard[col][row]      = 0;
                    partStopped(col, row + 1);
                }
                return;
            }

            if (row == BOARD_H - 2) {        /* about to be on the floor */
                if (solidOneBelow) {
                    gameBoard[col][row] = 1;
                    partStopped(col, row);
                } else {
                    gameBoard[col][row + 1] = 1;
                    boardHue[col][row + 1]  = boardHue[col][row];
                    gameBoard[col][row]     = 0;
                    partLanded(col);
                }
                return;
            }

            gameBoard[col][row + 1] = 2;
            boardHue[col][row + 1]  = boardHue[col][row];
            gameBoard[col][row]     = 0;
            smearCol = (uint8_t)col;
            smearRow = (uint8_t)row;
            smearLife = 4;
            /*
             * THE TICK IS THE SOFT DROP'S, not the fall's.
             *
             * On the free fall it fires every 26 frames for the whole
             * life of every piece, forever, and a metronome you did not
             * ask for and cannot stop is not rhythm - it is a dripping
             * tap. Under DOWN it is a different sound entirely at nine
             * times the rate: a rattle that lasts exactly as long as the
             * button is held and stops when it is let go. Same three
             * lines of code, and the only thing that changed is that it
             * is now something the player is doing rather than something
             * happening at them.
             */
            if (softDrop) sfxTick();
            return;
        }
    }
}

static void newPart(void)
{
    const int col = rndN(BOARD_W);
    activeHueIdx      = (uint8_t)rndN(BLOCK_HUES);
    gameBoard[col][0] = 2;
    boardHue[col][0]  = activeHueIdx;

    /*
     * BUG FIX. A piece spawned by the fall timer got a full fall period
     * on the top row because the caller reset the timer afterwards. A
     * piece spawned by a hard drop did not: moveCycle() runs before the
     * timer check in loop(), so with the count near its limit the new
     * piece was on row 0 for a frame or two and then fell - it looked
     * like it had appeared on the second row. Every new piece now starts
     * its own fall period, whichever way the last one landed.
     */
    cycleCount = 0;
}

static void partLanded(int col)
{
    const uint8_t hue = boardHue[col][BOARD_H - 1];
    sfxLand();
    newPart();
    fxLanded(col, hue);
    /* A small breath, not a jolt - this happens every few seconds. */
    plasmaPulse(30, 16);
    shakeState = 2;
    shakeCount = 5;

    int summer = 0;
    for (int c = 0; c < BOARD_W; c++) summer += gameBoard[c][BOARD_H - 1];
    if (summer == BOARD_W) {
        clearRow();
        fxPoints(20, highScore > currentScore);
        currentScore += 20;
    } else {
        fxPoints(1, highScore > currentScore);
        currentScore += 1;
    }
}

static void clearRow(void)
{
    /* The confetti has to be thrown before the row is shifted away,
     * because it inherits the colours of the blocks that are leaving. */
    uint8_t hues[BOARD_W];
    for (int col = 0; col < BOARD_W; col++) hues[col] = boardHue[col][BOARD_H - 1];
    fxCleared(BOARD_H - 1, hues);
    fxWord();

    /*
     * A zoom, and only a zoom. Twice the depth of the breath a single
     * block placement gets (30), and held three times as long, so it
     * reads as the bigger event without becoming a different kind of
     * event. This started at 140, which was a genuine lurch - the
     * background stopped being a background and started being the thing
     * you were looking at, right at the moment the player wants to see
     * the row leave. It also used to drag the ripples towards the row;
     * that read as a disturbance rather than a reaction and is gone.
     */
    plasmaPulse(60, 44);
    shakeState = 1;
    shakeCount = 10;

    sfxClear();

    for (int row = BOARD_H - 1; row > 0; row--) {
        for (int col = 0; col < BOARD_W; col++) {
            gameBoard[col][row] = gameBoard[col][row - 1];
            boardHue[col][row]  = boardHue[col][row - 1];
        }
    }
    for (int col = 0; col < BOARD_W; col++) gameBoard[col][0] = 0;
}

static void partStopped(int col, int row)
{
    const uint8_t hue = boardHue[col][row];
    sfxSettle(row);
    fxStopped(col, row, hue);
    plasmaPulse(26, 14);
    shakeState = 3;
    shakeCount = 1;

    if (row == 0) {                     /* stacked out - that is the game */
        gameState  = GS_OVER;
        endStage   = 0;
        stageCount = 0;
        endWord    = (uint8_t)rndN(NUM_BAD_WORDS);
        sfxOver();
    } else {
        int points = BOARD_H - row;
        fxPoints(points, highScore > currentScore);
        currentScore += (uint16_t)points;
        newPart();
    }
}

static void moveDown(void)
{
    for (int row = 0; row < BOARD_H; row++) {
        for (int col = 0; col < BOARD_W; col++) {
            if (gameBoard[col][row] != 2) continue;

            dropCol     = (uint8_t)col;
            dropRowFrom = (uint8_t)row;
            const uint8_t hue = boardHue[col][row];

            for (int rs = row; rs < BOARD_H; rs++) {
                if (gameBoard[col][rs] != 1) continue;
                /*
                 * BUG FIX. The original wrote the landed block first and
                 * then cleared the source cell. When the piece was
                 * already resting directly on the stack those are the
                 * same cell, so the clear undid the write and the piece
                 * simply vanished. Clearing first makes the two orders
                 * agree.
                 */
                gameBoard[col][row]    = 0;
                gameBoard[col][rs - 1] = 1;
                boardHue[col][rs - 1]  = hue;
                dropRowTo = (uint8_t)rs;
                dropCount = 6;
                dropHue   = hue;
                sfxDrop(rs - 1);
                fxDropSmoke(col, row, rs, hue);
                partStopped(col, rs - 1);
                return;
            }

            gameBoard[col][row]            = 0;
            gameBoard[col][BOARD_H - 1]    = 1;
            boardHue[col][BOARD_H - 1]     = hue;
            dropRowTo = BOARD_H;
            dropCount = 6;
            dropHue   = hue;
            sfxDrop(BOARD_H - 1);
            fxDropSmoke(col, row, BOARD_H, hue);
            partLanded(col);
            return;
        }
    }
}

static void moveCycle(void)
{
    if (aButton) { aButton = false; moveDown(); }
    if (bButton) { bButton = false; moveDown(); }

    for (int row = 0; row < BOARD_H; row++) {
        for (int col = 0; col < BOARD_W; col++) {
            if (gameBoard[col][row] != 2) continue;

            /*
             * UP, WHICH COSTS A POINT.
             *
             * This is not Tetris and there is nothing to rotate, so the
             * button was going spare - and a game about one block at a
             * time in five columns can afford to let you take one back.
             * One row per press, exactly like left and right.
             *
             * The toll is the joke and it is also what stops it being a
             * cheat, because it is denominated in the same currency the
             * stack pays out: undoing a bad drop by three rows costs
             * three of the points a good one would have earned. At zero
             * the button does nothing at all - the latch is still
             * consumed, so holding it cannot queue a refund against the
             * next point scored.
             */
            if (moveUp) {
                moveUp = false;
                if (row > 0 && currentScore > 0 && gameBoard[col][row - 1] == 0) {
                    gameBoard[col][row - 1] = 2;
                    boardHue[col][row - 1]  = boardHue[col][row];
                    gameBoard[col][row]     = 0;
                    currentScore--;
                    fxCost(1);
                    sfxMoveUp();
                    return;
                }
            }
            if (moveRight) {
                moveRight = false;
                if (col < BOARD_W - 1 && gameBoard[col + 1][row] == 0) {
                    gameBoard[col + 1][row] = 2;
                    boardHue[col + 1][row]  = boardHue[col][row];
                    gameBoard[col][row]     = 0;
                    sfxMove();
                    return;
                }
            }
            if (moveLeft) {
                moveLeft = false;
                if (col > 0 && gameBoard[col - 1][row] == 0) {
                    gameBoard[col - 1][row] = 2;
                    boardHue[col - 1][row]  = boardHue[col][row];
                    gameBoard[col][row]     = 0;
                    sfxMove();
                    return;
                }
            }
        }
    }
}

static void resetGame(void)
{
    if (currentScore > highScore) highScore = currentScore;
    currentScore = 0;
    for (int row = 0; row < BOARD_H; row++)
        for (int col = 0; col < BOARD_W; col++)
            gameBoard[col][row] = 0;

    aButton = bButton = moveLeft = moveRight = moveUp = false;
    softDrop = paused = false;
    dropCount = smearLife = 0;
    newPart();
    gameState = GS_PLAY;
}

/* ------------------------------------------------------------------ */
/* Intro                                                               */
/* ------------------------------------------------------------------ */
/*
 * Three beats. A title over the plasma at full brightness, then the same
 * two-part reveal the original used - a line down the middle, then a
 * rectangle opening out of it - with the well dimming into existence
 * behind it.
 *
 * NO PARTICLES ANYWHERE IN HERE. The intro used to run a fountain up the
 * title screen and shed sparks off the growing edges of the reveal. The
 * particle system is gameplay feedback - it tells you a piece landed, a
 * row went, the stack came apart - and spending it on decoration before
 * the game starts both muddies the title and spends the effect before it
 * means anything. The plasma is already moving; the title does not need
 * help.
 */
static void doGameStart(void)
{
    if (startStage == 0) {
        plasmaNoPlayfield();

        /* Baselines one 19 px line apart for the two title words, which
         * is the face's own line height - the title is set, not stacked
         * by eye. NEW is 42 px wide and BLOCKS 72; the widest thing on
         * this screen is ON THE KID at 77, all inside 128. */
        /* One rainbow across both words: BLOCKS carries on from the slot
         * after W, and the wave rolls through them as one line. */
        gfx_setFont(&CHGfx_SansBold16);
        textWaveBaseCentred(64, 36, "NEW",    0, wavePhase);
        textWaveBaseCentred(64, 55, "BLOCKS", 3, (uint8_t)(wavePhase - 3 * WAVE_STEP));

        gfx_setFont(&CHGfx_SansBold12);
        textOutBaseCentred(64, 72, "ON THE KID", C_WHITE);
        gfx_setFont(nullptr);

        /*
         * The prompt is the built-in 5x7 at 1:1 in plain white, and
         * deliberately so: it is an instruction, not a third line of the
         * title. Set in a display face directly under ON THE KID it
         * competed with the title it was supposed to be serving.
         * Sixteen characters at 6 px is 96 px, well inside 128 with the
         * outline on.
         *
         * It blinks on the hue clock, which never wraps awkwardly;
         * stageCount only gates the first moment.
         */
        /*
         * THE BLINK RUNS ON ITS OWN CLOCK, started the moment the prompt
         * first appears.
         *
         * It used to blink on a bit of the free running hue accumulator,
         * which meant the first ON was however much of that cycle was
         * left at frame 41 - which is two frames. So the very first
         * thing the player saw was the prompt flashing on for 25 ms,
         * disappearing for a third of a second, and only then settling
         * into its rhythm. A counter of its own guarantees the first
         * thing you see is a full ON, and every phase after it is the
         * same length as every other.
         */
        if (stageCount > 40) {
            if (promptCount < PROMPT_HALF)
                textOut(64 - textW("PRESS ANY BUTTON", 1) / 2, 100,
                        "PRESS ANY BUTTON", C_WHITE, 1);
            promptCount = (uint8_t)(promptCount + 1 >= 2 * PROMPT_HALF
                                    ? 0 : promptCount + 1);
        }

        /*
         * The mute state, bottom right - the corner nearest the SELECT
         * button that toggles it, so the label is where the thumb
         * already is. White for sound, red for silence.
         *
         * THE RED IS BORROWED. There is no spare palette slot for one:
         * all sixteen are roles and every one of them is spoken for. But
         * C_GHOST's three jobs - grid dots, smear trails, dying sparks -
         * are all things that cannot be on screen while the title is up,
         * so it is overwritten here for exactly the frames that need it.
         * pal[] is not read until the composite at the very end of
         * loop(), so writing it during the draw is what the draw comes
         * out as.
         */
        if (soundMuted) pal[C_GHOST] = gfx_rgb(255, 0, 0);
        textOut(GFX_W - textW("MUTE", 1) - 2, GFX_H - 10, "MUTE",
                soundMuted ? C_GHOST : C_WHITE, 1);

        if (stageCount < 255) stageCount++;

        /* The title waits. A button pressed on this frame - not one
         * still held from before - starts the game; the music was the
         * title's and stops here. */
        /* Every button except SELECT, which belongs to the mute for the
         * whole life of the program - otherwise checking that the sound
         * was off would start a game. */
        if (justPressed(B_UP | B_DOWN | B_LEFT | B_RIGHT | B_A | B_B | B_START)) {
            aButton = bButton = moveLeft = moveRight = moveUp = false;
            stageCount = 0;
            startStage = 1;
            musicStop();
            sfxTitle();
        }
        return;
    }

    /*
     * THE WELL IS REVEALED, NOT PRE-DIMMED.
     *
     * The dimmed rectangle behind the well is set for the whole
     * playfield every frame by loop(), which is right during play and
     * wrong here: with the line still coming down, a dark 40x120 slab
     * was already sitting behind it, and the rectangle then opened out
     * over a well that was visibly there before its container was. So
     * the line dims nothing, and the rectangle dims exactly its own
     * interior - the shadow spreads with the frame that casts it.
     */
    if (startStage == 1) {                       /* the line down the middle */
        plasmaNoPlayfield();
        const int h = stageCount * 4;
        gfx_vline(63, FRAME_Y, h > FRAME_H ? FRAME_H : h, C_WHITE);
        gfx_vline(64, FRAME_Y, h > FRAME_H ? FRAME_H : h, C_FRAME);
        if (h >= FRAME_H) { stageCount = 0; startStage = 2; }
        else stageCount++;
        return;
    }

    /* startStage 2 - the rectangle opening out of the line */
    int w = 2 + stageCount * 2;
    if (w > FRAME_W) w = FRAME_W;
    gfx_rect(64 - w / 2, FRAME_Y, w, FRAME_H, C_INK);
    gfx_rect(64 - w / 2 + 1, FRAME_Y + 1, w - 2, FRAME_H - 2, C_FRAME);
    plasmaSetPlayfield(64 - w / 2 + FRAME_T, PF_Y,
                       64 - w / 2 + w - FRAME_T, PF_Y + PF_H);

    if (w >= FRAME_W) {
        stageCount = 0;
        gameState  = GS_PLAY;
        sfxGo();
    } else {
        stageCount++;
    }
}

/* ------------------------------------------------------------------ */
/* Game over                                                           */
/* ------------------------------------------------------------------ */
/*
 * The original wiped the screen with a horizontal line that split into a
 * black band, printed a word, and closed it again. Same choreography,
 * with the stack demolished into confetti first - the well emptying
 * itself from the bottom up is a much better full stop than a line.
 */
#define BANNER_H 16

static void drawBanner(int half)
{
    gfx_fillRect(0, 64 - half, GFX_W, half * 2, C_INK);
    gfx_hline(0, 64 - half, GFX_W, C_FRAME);
    gfx_hline(0, 64 + half - 1, GFX_W, C_FRAME);
}

/*
 * PAUSED, in the game over banner and the game over face, because a
 * pause and a game over are the same gesture - the game stops and one
 * word says why.
 *
 * THE WELL IS HIDDEN, and not only out of good manners. textGradient
 * repaints the ten block slots into the hue ramp the wave needs, so a
 * board left standing underneath this word would have every block in it
 * recoloured - which is the same reason the stack is demolished before
 * the game over banner opens rather than left there. Not drawing the
 * board is what buys the word its rainbow, and a pause screen you cannot
 * study the stack through is the right answer anyway.
 */
static void drawPaused(void)
{
    drawBanner(BANNER_H);
    gfx_setFont(&CHGfx_SansBold16);
    textWaveBaseCentred(64, 70, "PAUSED", 0, wavePhase);
    gfx_setFont(nullptr);
}

static void doGameEnd(void)
{
    drawFrame();
    drawBoard();

    if (endStage == 0) {                         /* demolish the stack */
        /* A beat first. The stack stands, full, while the run down plays
         * into silence - it is only 350 ms, and the collapse lands
         * harder for having waited for it. */
        if (stageCount == 0 && sfxBusy(SP_PHRASE)) return;

        const int row = BOARD_H - 1 - (stageCount / 3);
        if ((stageCount % 3) == 0 && row >= 0) {
            bool any = false;
            for (int col = 0; col < BOARD_W; col++) {
                if (gameBoard[col][row]) {
                    fxShatter(col, row, boardHue[col][row]);
                    gameBoard[col][row] = 0;
                    any = true;
                }
            }
            if (any) {
                sfxShatter(row);
                plasmaPulse(40, 12);
                shakeState = 3;
                shakeCount = 2;
            }
        }
        if (row < 0) { stageCount = 0; endStage = 1; }
        else stageCount++;
        return;
    }

    if (endStage == 1) {                         /* the banner opens */
        if (stageCount == 0) sfxBanner();
        drawBanner(stageCount + 1);
        if (stageCount >= BANNER_H) { stageCount = 0; endStage = 2; }
        else stageCount++;
        return;
    }

    if (endStage == 2) {                         /* the word, and the wait */
        if (stageCount == 0) musicOverStart();
        drawBanner(BANNER_H);
        /* The banner is 32 px tall and centred on y=64; a 13 px cap
         * height on a baseline of 70 centres the ink in it. The widest
         * word is DESTROYED at 109 px, which clears 128 with the outline
         * on. */
        gfx_setFont(&CHGfx_SansBold16);
        textWaveBaseCentred(64, 70, badWords[endWord], 0, wavePhase);
        gfx_setFont(nullptr);
        if (stageCount < 20) {
            /* Swallow input for a moment so a mashed drop button does not
             * blow straight through the end screen. */
            aButton = bButton = false;
            stageCount++;
        } else if (aButton || bButton) {
            aButton = bButton = false;
            stageCount = BANNER_H;
            endStage = 3;
        }
        return;
    }

    if (endStage == 3) {                         /* and closes */
        drawBanner(stageCount + 1);
        if (stageCount == 0) { endStage = 4; }
        else stageCount--;
        return;
    }

    stageCount = 0;
    endStage   = 0;
    resetGame();
    sfxGo();                                      /* the same "go" as the intro */
}

/* ------------------------------------------------------------------ */
/* Setup and loop                                                      */
/* ------------------------------------------------------------------ */
void setup()
{
    /* 16 bpp. 12 bpp would buy 25% more frames and cost nothing behind a
     * 16-colour palette - but this game is not behind a 16-colour
     * palette. The plasma is generated at full RGB565 in the stream
     * callback, and 12 bpp would quantise its gradients into visible
     * banding, which is the one thing the whole effect cannot afford. */
    Gfx.begin(GFX_DIV2, GFX_16BPP);

    buttonsBegin();
    plasmaInit();
    particlesClear();

    /* Claims the piezo, TIM1 and TIM2. The music itself waits for the
     * panel: soundUpdate() starts it MUSIC_START_MS after reset. */
    soundBegin();

    gameBoard[2][0] = 2;                 /* the hard coded first piece */
    boardHue[2][0]  = 0;
    activeHueIdx    = 0;
}

void loop()
{
    /* One logic tick per rendered frame. gfx_stream() is blocking and
     * the composite is a fixed cost per frame, so the rate is stable at
     * whatever the wire allows - there is nothing to gain from a
     * separate fixed-step accumulator and it would only introduce
     * judder between the piece, the particles and the frame.
     *
     * The plasma is the one exception: it advances by measured time
     * inside plasmaStep(), because it is the only thing on screen that
     * moves continuously and slowly enough for a long frame to show as
     * a hitch. Nothing else moves in a way where that is visible. */
    buttonsPoll();
    soundUpdate();

    if (justPressed(B_RIGHT)) moveRight = true;
    if (justPressed(B_LEFT))  moveLeft  = true;
    if (justPressed(B_UP))    moveUp    = true;
    if (justPressed(B_A))     aButton   = true;
    if (justPressed(B_B))     bButton   = true;

    /* A level, not an edge: hold it and it keeps falling fast. */
    softDrop = (btnNow & B_DOWN) != 0;

    /* SELECT is global. It works on the title, in play, under the pause
     * banner and on the game over screen, and the popup it throws is the
     * only confirmation there is that the press landed - which is why
     * that popup is a particle rather than something one of the states
     * draws, since none of them can draw for the others. */
    if (justPressed(B_SEL)) fxMuteWord(soundToggleMute());

    /* START pauses, and only during play: the intro and the game over
     * are sequences the player is already waiting out. */
    if (gameState == GS_PLAY && justPressed(B_START)) {
        paused = !paused;
        if (paused) sfxBanner();
        else        sfxGo();          /* the same "go" that starts a game */
    }

    /* The slow walk. 12/1024 of a hue step per frame at ~80 fps is one
     * full circuit of the wheel every twelve seconds or so. */
    hueAccum = (uint16_t)(hueAccum + 12);
    baseHue  = (uint8_t)(hueAccum >> 6);

    /* The display-text palette mode, decided before plasmaStep() builds
     * this frame's palette: on for the title and for the game over word,
     * the two moments with no blocks on screen. The wave rolls one cycle
     * in about 64 frames. */
    textGradient = (gameState == GS_INTRO && startStage == 0)
                || (gameState == GS_OVER  && endStage == 2)
                || (gameState == GS_PLAY  && paused);
    wavePhase = (uint8_t)(wavePhase + 4);

    /* Camera shake, all three original flavours. */
    if (shakeState == 1) {
        if (shakeCount) { shakeCount--; shakeX = (int8_t)rndR(-2, 3); shakeY = (int8_t)rndR(-2, 3); }
        else shakeState = 0;
    } else if (shakeState == 2) {
        if (shakeCount) { shakeCount--; shakeY = (int8_t)rndR(-1, 2); }
        else shakeState = 0;
    } else if (shakeState == 3) {
        if (shakeCount) { shakeCount--; shakeY = 1; }
        else shakeState = 0;
    } else {
        shakeX = shakeY = 0;
    }

    /* The plasma tints towards the falling piece. The hue INDEX is fixed
     * for the life of the piece, but the wheel angle it maps to drifts
     * with baseHue, so the target has to be handed over every frame. */
    plasmaSetHue(blockHueAngle(baseHue, activeHueIdx));

    plasmaStep(baseHue);
    plasmaSetPlayfield(PF_X + shakeX, PF_Y + shakeY,
                       PF_X + PF_W + shakeX, PF_Y + PF_H + shakeY);

    gfx_clear(C_CLEAR);                  /* every hole shows the plasma */

    /* The well floor goes down before anything that happens in the well.
     * Not during the intro: the frame has not been revealed yet, so a
     * grid hanging in mid air would arrive before its container. */
    if (gameState != GS_INTRO) drawGrid();

    particlesUpdate();
    drawDropBeam();

    if (gameState == GS_PLAY) {
        if (paused) {
            /* Nothing latched while the board is frozen. A move pressed
             * against a stopped game would otherwise fire the instant it
             * started again, seconds after the button that asked for
             * it. */
            aButton = bButton = moveLeft = moveRight = moveUp = false;
            drawFrame();
            drawHud();
            drawPaused();
        } else {
            moveCycle();
            const uint8_t speed = softDrop ? SOFT_SPEED : gameSpeed;
            if (cycleCount >= speed) { boardCycle(); cycleCount = 0; }
            else cycleCount++;
            drawFrame();
            drawBoard();
            drawHud();
        }
    } else if (gameState == GS_INTRO) {
        doGameStart();
        if (startStage > 0) drawHud();
    } else {                             /* GS_OVER */
        doGameEnd();
        drawHud();
    }

    /* Particles last so sparks pass in front of the blocks that threw
     * them, and in front of the game over banner. */
    particlesDraw();

    plasmaRender();
}

/* end of file - original game copyright Kevin Bates 2020 */
