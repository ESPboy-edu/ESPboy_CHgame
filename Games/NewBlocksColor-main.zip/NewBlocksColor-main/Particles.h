/*
 * Particles.h - the particle zone, rebuilt.
 *
 * WHAT THE ORIGINAL DID, AND WHAT IS DIFFERENT
 * --------------------------------------------
 * The Arduboy version had 40 particles in a fixed array, positions in
 * whole pixels, velocities in SQ7x8 from the FixedPoints library, and
 * one colour, because there was only one colour. Emitters wrote to hard
 * coded index ranges - drawStopped() always used slots 0..2, drawLanded()
 * always used 0..9 - so a landing in the middle of a row clear silently
 * stomped the confetti that was still in flight. All of that is worth
 * keeping the shape of and none of it is worth keeping.
 *
 * This version:
 *
 *   112 particles, not 40. The pool is 1.5 KB and it is the single best
 *   use of the SRAM that is left after the framebuffer.
 *
 *   Positions AND velocities in 8.8 fixed point. The original stored x
 *   and y as whole pixels and truncated the velocity to int8 on the way
 *   in, so anything moving slower than one pixel per frame did not move
 *   at all and everything else moved in visible jerks. Sub-pixel
 *   positions cost two bytes per particle and buy smooth motion for
 *   free. FixedPoints is gone with it - int16 and a shift is the whole
 *   library.
 *
 *   Colour by age AND by source. Every spark carries a block hue index,
 *   so a landing throws sparks in the colour of the piece that landed,
 *   and each one cools white -> lightened hue -> hue -> dim over its
 *   life. A spark now tells you both how old it is and what made it.
 *
 *   Velocity streaks. A fast particle is drawn as a line from where it
 *   was to where it is - and "where it was" is just position minus
 *   velocity, so trails cost no extra state at all. This is most of why
 *   the bursts look violent.
 *
 *   Real bounces. The original set restitution to 0.000001 and multiplied
 *   by it, which is a long way of saying particles stopped dead at the
 *   floor. These bounce at about a third, lose energy sideways on impact,
 *   and settle.
 *
 *   A round-robin allocator instead of fixed index ranges, so emitters
 *   can no longer eat each other.
 */
#pragma once

#include <CHGfx.h>
#include "Common.h"
#include "Palette.h"
#include "Text.h"
#include "Words.h"

/* Pool size. 14 bytes each - see the SRAM arithmetic in the .ino. */
#define NPART 112

enum : uint8_t {
    PK_DEAD = 0,
    PK_SPARK,       /* ages white -> lit hue -> hue -> dim            */
    PK_CONFETTI,    /* keeps one block hue for life - shattered blocks */
    PK_WORD,        /* rising praise popup                            */
    PK_POINTS,      /* rising score popup                             */
    PK_MINUS,       /* the same popup, with a minus in front of it    */
    PK_MUTE         /* MUTED / UNMUTED, same corner, same rise        */
};

/* Everything from PK_WORD up is a text arc: gravity, no walls, no drag.
 * particlesUpdate() tests against this, so a new text popup only has to
 * be added above and it gets the lob for free. */

enum : uint8_t {
    PZ_BOARD = 0,   /* bounces off the well walls and floor           */
    PZ_SCREEN,      /* the whole panel                                */
    PZ_FREE         /* no bounds at all - text arcs off the top        */
};

/*
 * Twelve bytes, and the bitfields are why. Four int16 are eight; life and
 * life0 are ten; data is eleven. Kind, zone and size as separate bytes
 * would be fourteen after alignment padding, and 2 bytes x 112 particles
 * is 224 bytes on a part with about three kilobytes of headroom. They
 * need 3, 2 and 3 bits and they get exactly one byte between them.
 */
struct Particle {
    int16_t x, y;        /* 8.8 fixed, screen pixels */
    int16_t vx, vy;      /* 8.8 fixed, pixels/frame  */
    uint8_t life;
    uint8_t life0;
    uint8_t kind : 3;
    uint8_t zone : 2;
    uint8_t size : 3;    /* 1..4 */
    uint8_t data;        /* word index, points value, or block hue */
};

static Particle parts[NPART];
static uint8_t  pCursor;

/* 8.8 helpers. FP(1.5) is a pixel and a half per frame. */
#define FP(v)  ((int16_t)((v) * 256))
#define GRAV   31       /* 0.12 px/frame^2 in 8.8, as the original had */

/* ------------------------------------------------------------------ */
/* Allocation                                                          */
/* ------------------------------------------------------------------ */
/*
 * Round robin. Normally the first slot examined is free, so this is O(1)
 * in the common case; when the pool is genuinely full it overwrites in
 * age order, which for confetti is exactly what you want and is a strict
 * improvement on the original habit of always clobbering slot zero.
 */
static Particle *pAlloc(void)
{
    for (int n = 0; n < NPART; n++) {
        Particle *p = &parts[pCursor];
        pCursor = (uint8_t)(pCursor + 1 == NPART ? 0 : pCursor + 1);
        if (!p->life) return p;
    }
    Particle *p = &parts[pCursor];
    pCursor = (uint8_t)(pCursor + 1 == NPART ? 0 : pCursor + 1);
    return p;
}

static void particlesClear(void)
{
    for (int i = 0; i < NPART; i++) parts[i].life = 0;
}

/*
 * px, py are whole pixels and MUST be within -128..127. Position is 8.8
 * in an int16, so 128 is not a representable coordinate - it wraps to
 * -128 and the particle silently appears at the opposite edge. That is
 * exactly what happened to the title screen fountain, which tried to
 * spawn below the bottom of the screen at y = GFX_H + 2 and came out of
 * the ceiling instead. vx and vy are already 8.8; use FP().
 */
static void pEmit(int px, int py, int vx, int vy,
                  uint8_t life, uint8_t size, uint8_t kind, uint8_t zone, uint8_t data)
{
    Particle *p = pAlloc();
    p->x = (int16_t)(px << 8);
    p->y = (int16_t)(py << 8);
    p->vx = (int16_t)vx;
    p->vy = (int16_t)vy;
    p->life = p->life0 = life;
    p->size = size;
    p->kind = kind;
    p->zone = zone;
    p->data = data;
}

/* ------------------------------------------------------------------ */
/* Physics                                                             */
/* ------------------------------------------------------------------ */
static void particlesUpdate(void)
{
    for (int i = 0; i < NPART; i++) {
        Particle *p = &parts[i];
        if (!p->life) continue;
        p->life--;

        if (p->kind >= PK_WORD) {
            /* Text arcs: gravity only, no drag, no walls. Same lob the
             * original had - up fast, stall, fall back. */
            p->vy = (int16_t)(p->vy + GRAV);
            const int32_t ty = (int32_t)p->y + p->vy;
            /* A popup that outlives its own arc keeps falling, and 8.8
             * in an int16 stops at 127.996 px - so it would run off the
             * end of the number and reappear at the top of the panel.
             * It is off the bottom of the screen and it is finished;
             * end it here rather than let it come back. */
            if (ty >= (int32_t)GFX_H << 8) { p->life = 0; continue; }
            p->y = (int16_t)ty;
            continue;
        }

        /* Heavier particles fall faster, as in the original - it reads as
         * embers versus dust rather than as bad physics. */
        p->vy = (int16_t)(p->vy + GRAV * p->size);
        p->vx = (int16_t)((p->vx * 246) >> 8);      /* 0.96 drag       */
        p->vy = (int16_t)((p->vy * 253) >> 8);      /* light air drag  */

        /*
         * THE STEP IS TAKEN IN 32 BITS, and that is not fussiness.
         *
         * Position is 8.8 in an int16, so the largest coordinate it can
         * hold is 127.996 - and a size-4 confetti chunk pulls four times
         * gravity, so by the time a row clear's debris has arced up the
         * screen and come back down it is doing tens of pixels a frame.
         * Adding that to a y already down at 120 ran off the end of the
         * number and came back as -128, below every wall test here: the
         * particle was not clamped, it was TELEPORTED, and a row clear
         * threw its confetti out of the well, let it fall, and then
         * rained a second copy of it in from the top of the screen.
         *
         * The walls below put every particle back inside the panel
         * before it is stored, so the only value that ever reaches the
         * int16 is one that fits in it.
         */
        int32_t nx = (int32_t)p->x + p->vx;
        int32_t ny = (int32_t)p->y + p->vy;

        int x0, x1, y0, y1;
        if (p->zone == PZ_BOARD) {
            x0 = PF_X; x1 = PF_X + PF_W; y0 = PF_Y; y1 = PF_Y + PF_H;
        } else {
            x0 = 0; x1 = GFX_W; y0 = 0; y1 = GFX_H;
        }

        int px = (int)(nx >> 8);
        if (px < x0)       { nx = (int32_t)x0 << 8;       p->vx = (int16_t)(-p->vx >> 1); }
        else if (px >= x1) { nx = (int32_t)(x1 - 1) << 8; p->vx = (int16_t)(-p->vx >> 1); }

        int py = (int)(ny >> 8);
        if (py >= y1) {
            ny    = (int32_t)(y1 - 1) << 8;
            p->vy = (int16_t)(-((p->vy * 88) >> 8));    /* ~0.34 bounce   */
            p->vx = (int16_t)((p->vx * 190) >> 8);      /* floor friction */
        } else if (py < y0 && p->vy < 0) {
            ny    = (int32_t)y0 << 8;
            p->vy = (int16_t)(-(p->vy >> 2));
        }

        p->x = (int16_t)nx;
        p->y = (int16_t)ny;

        /* Shrink with age, as the original did. */
        if (p->size > 2 && p->life * 2 < p->life0) p->size = 2;
        if (p->size > 1 && p->life * 5 < p->life0) p->size = 1;
    }
}

/* ------------------------------------------------------------------ */
/* Colour                                                              */
/* ------------------------------------------------------------------ */
/*
 * Four stops down the fade, compared against fractions of life0 with
 * multiplies rather than a divide - 112 divides a frame on a core with
 * no divider worth the name is real money.
 *
 * There is no dedicated fire ramp any more. Every spark carries a block
 * hue index in `data` and cools white -> that hue lightened -> that hue
 * -> dim, which means a landing throws sparks in the colour of the block
 * that landed and a row clear throws five colours at once. Three palette
 * slots that used to hold a fixed orange ramp went to the lightened
 * twins instead, and the sparks came out more colourful for it.
 *
 * The stops are deliberately uneven. An even split spends the first 40%
 * of every spark white, and with a hundred on screen during a row clear
 * the burst reads as white confetti rather than as the colours that were
 * just destroyed.
 */
static inline uint8_t sparkColour(const Particle *p)
{
    unsigned l = p->life, L = p->life0;
    if (l * 8 > L * 7) return C_WHITE;              /* top 12%, the flash */
    if (l * 2 > L)     return C_LIT0 + p->data;     /* to 50%             */
    if (l * 5 > L)     return C_BLK0 + p->data;     /* to 20%             */
    return C_GHOST;                                 /* guttering out      */
}

/* ------------------------------------------------------------------ */
/* Drawing                                                             */
/* ------------------------------------------------------------------ */
static void particlesDraw(void)
{
    for (int i = 0; i < NPART; i++) {
        Particle *p = &parts[i];
        if (!p->life) continue;

        const int px = p->x >> 8;
        const int py = p->y >> 8;

        if (p->kind == PK_WORD) {
            const char *w = goodWords[p->data];
            /* Flicker between white and the rotating text hue. On this
             * panel a popup that only fades gets lost; one that strobes
             * stays readable all the way out. */
            uint8_t c = (p->life & 4) ? C_WHITE : C_TEXT;
            textOut(px, py, w, c, 1);
            textOut(px + textW(w, 1) + 2, py, "!", c, 1);
            continue;
        }
        if (p->kind == PK_POINTS || p->kind == PK_MINUS) {
            char buf[8];
            buf[0] = (p->kind == PK_MINUS) ? '-' : '+';
            fmtU(buf + 1, p->data);
            textOut(px, py, buf, (p->life & 4) ? C_WHITE : C_TEXT, 1);
            continue;
        }
        if (p->kind == PK_MUTE) {
            /* C_TEXT and C_WHITE, both of which are outside the ten
             * slots textGradient repaints - so this reads the same over
             * the title, the pause banner and the game over word as it
             * does over the well. */
            textOut(px, py, p->data ? "MUTED" : "UNMUTED",
                    (p->life & 4) ? C_WHITE : C_TEXT, 1);
            continue;
        }

        /* Confetti keeps the hue of the block it came from for almost
         * all of its life; the white strobe is only the first sixth, so
         * the row you just cleared is recognisable in the debris. */
        const uint8_t c = (p->kind == PK_CONFETTI)
                        ? (uint8_t)((p->life & 2) && p->life * 6 > p->life0 * 5
                                    ? C_WHITE : (C_BLK0 + p->data))
                        : sparkColour(p);

        /* The streak. Previous position is position minus velocity, so
         * the trail is exact and free. Only worth drawing once the
         * particle actually covers ground - below about 1.5 px a line
         * degenerates to the dot we are about to draw anyway. */
        const int qx = (int)((p->x - p->vx) >> 8);
        const int qy = (int)((p->y - p->vy) >> 8);
        const int dx = px - qx, dy = py - qy;
        if (dx * dx + dy * dy >= 3) gfx_line(qx, qy, px, py, c);

        if (p->size >= 3) {
            gfx_fillRect(px - 1, py - 1, 3, 3, c);
            gfx_pixel(px, py, C_WHITE);              /* hot core */
        } else if (p->size == 2) {
            gfx_fillRect(px, py, 2, 2, c);
        } else {
            gfx_pixel(px, py, c);
        }
    }
}

/* ------------------------------------------------------------------ */
/* Emitters                                                            */
/* ------------------------------------------------------------------ */
/*
 * The Arduboy emitters are all still here in spirit - same events, same
 * moments, same counts scaled up for a pool that is nearly three times
 * bigger and a well that is twice as tall.
 */

/* A piece settling on top of the stack: a short, tight scuff, in the
 * colour of the piece that made it. */
static void fxStopped(int col, int row, uint8_t hue)
{
    const int cx = CELL_X(col) + CELL / 2;
    const int cy = CELL_Y(row);
    for (int i = 0; i < 14; i++)
        pEmit(cx + rndR(-3, 4), cy,
              rndR(-FP(1.6), FP(1.6)), rndR(-FP(2.2), -FP(0.3)),
              (uint8_t)rndR(10, 20), (uint8_t)rndR(1, 3),
              PK_SPARK, PZ_BOARD, hue);
}

/* A piece hitting the floor: heavier, wider, with dust that hangs. */
static void fxLanded(int col, uint8_t hue)
{
    const int cx = CELL_X(col) + CELL / 2;
    const int cy = PF_Y + PF_H - 1;
    for (int i = 0; i < 22; i++)
        pEmit(cx + rndR(-4, 5), cy - rndN(4),
              rndR(-FP(3.0), FP(3.0)), rndR(-FP(3.4), -FP(0.6)),
              (uint8_t)rndR(14, 48), (uint8_t)rndR(1, 4),
              PK_SPARK, PZ_BOARD, hue);
}

/*
 * A completed row. This is the big one: the blocks that vanished come
 * apart into confetti in their own colours and leave the well entirely,
 * plus a sheet of sparks along the row. The plasma zoom that goes with
 * it is kicked from the caller.
 */
static void fxCleared(int row, const uint8_t *rowHues)
{
    const int cy = CELL_Y(row) + CELL / 2;
    /*
     * Launch velocities are large on purpose. Gravity here scales with
     * particle size, exactly as the original did, so a size-4 chunk
     * pulls 0.48 px/frame^2 - at the 5 px/frame this first used, the
     * confetti apexed 26 px up and fell straight back into the well,
     * which looked like the row had crumbled rather than exploded.
     * 8 px/frame carries it past the middle of the screen and it rains
     * back down across the whole panel.
     */
    for (int col = 0; col < BOARD_W; col++) {
        const int cx = CELL_X(col) + CELL / 2;
        for (int i = 0; i < 7; i++)
            pEmit(cx + rndR(-3, 4), cy + rndR(-3, 4),
                  rndR(-FP(5.5), FP(5.5)), rndR(-FP(8.5), -FP(3.0)),
                  (uint8_t)rndR(30, 90), (uint8_t)rndR(2, 5),
                  PK_CONFETTI, PZ_SCREEN, rowHues[col]);
    }
    for (int i = 0; i < 16; i++)
        pEmit(PF_X + rndN(PF_W), cy + rndR(-2, 3),
              rndR(-FP(7.0), FP(7.0)), rndR(-FP(6.0), FP(1.0)),
              (uint8_t)rndR(16, 50), (uint8_t)rndR(1, 4),
              PK_SPARK, PZ_SCREEN, (uint8_t)rndN(BLOCK_HUES));
}

/* The trail left by a hard drop, along the column the piece fell down. */
static void fxDropSmoke(int col, int rowFrom, int rowTo, uint8_t hue)
{
    const int cx = CELL_X(col) + CELL / 2;
    const int y0 = CELL_Y(rowFrom);
    const int y1 = CELL_Y(rowTo);
    if (y1 <= y0) return;
    for (int i = 0; i < 12; i++)
        pEmit(cx + rndR(-3, 4), y0 + rndN(y1 - y0),
              rndR(-FP(0.9), FP(0.9)), rndR(-FP(1.0), FP(0.4)),
              (uint8_t)rndR(6, 16), 1, PK_SPARK, PZ_BOARD, hue);
}

/* One block coming apart, used to demolish the stack on game over. */
static void fxShatter(int col, int row, uint8_t hue)
{
    const int cx = CELL_X(col) + CELL / 2;
    const int cy = CELL_Y(row) + CELL / 2;
    for (int i = 0; i < 3; i++)
        pEmit(cx + rndR(-3, 4), cy + rndR(-3, 4),
              rndR(-FP(3.0), FP(3.0)), rndR(-FP(4.0), FP(0.5)),
              (uint8_t)rndR(30, 80), (uint8_t)rndR(2, 4),
              PK_CONFETTI, PZ_SCREEN, hue);
}

/*
 * Praise, arcing up the left column. Centred by measurement rather than
 * by the leading spaces the original baked into the strings, and clamped
 * so the outline never crosses into the playfield frame.
 */
static void fxWord(void)
{
    const int idx = rndN(NUM_GOOD_WORDS);
    int w = textW(goodWords[idx], 1) + TEXT_ADV(1);      /* plus the "!" */
    int x = (COL_L_W - w) / 2;
    if (x > COL_L_W - 1 - w) x = COL_L_W - 1 - w;
    if (x < 0) x = 0;
    pEmit(x, GFX_H - 12, 0, -FP(3.5), 70, 1, PK_WORD, PZ_FREE, (uint8_t)idx);
}

/* Score, arcing up the right column. Awarded and spent points share
 * everything but the sign: a "-1" leaving the same corner, at the same
 * speed, in the same strobe is what makes the toll for a move back up
 * the well read as the opposite of a point rather than as a new kind of
 * event nobody has seen before. */
static void fxScorePop(int points, uint8_t kind, uint8_t life)
{
    char buf[8];
    buf[0] = (kind == PK_MINUS) ? '-' : '+';
    fmtU(buf + 1, (uint32_t)points);
    int w = textW(buf, 1);
    int x = COL_R_X + (COL_R_W - w) / 2 + rndR(-3, 4);
    if (x < COL_R_X) x = COL_R_X;
    if (x > GFX_W - 1 - w) x = GFX_W - 1 - w;
    pEmit(x, GFX_H - 12, 0, -FP(3.5), life, 1, kind, PZ_FREE, (uint8_t)points);
}

static inline void fxPoints(int points, bool beatingHighScore)
{
    fxScorePop(points, PK_POINTS, (uint8_t)(beatingHighScore ? 25 : 30));
}

/* The toll for shoving the piece back up. */
static inline void fxCost(int points)
{
    fxScorePop(points, PK_MINUS, 30);
}

/*
 * MUTED / UNMUTED, in the same corner and the same rising strobe as the
 * score - because that corner of the panel is the one the SELECT button
 * is physically nearest, and this is the only feedback there is that the
 * press registered.
 *
 * No random x jitter, unlike the score: this one can be pressed twice in
 * a second and two copies of a seven character word at different offsets
 * read as two different messages. "UNMUTED" is 42 px, which is exactly
 * the column, so it is centred and left there.
 */
static void fxMuteWord(bool muted)
{
    const char *s = muted ? "MUTED" : "UNMUTED";
    int x = COL_R_X + (COL_R_W - textW(s, 1)) / 2;
    if (x < COL_R_X) x = COL_R_X;
    pEmit(x, GFX_H - 12, 0, -FP(3.5), 30, 1, PK_MUTE, PZ_FREE, muted ? 1 : 0);
}

/*
 * The original had a drawPowerOn() boot flourish that it never called.
 * This port called it for a while and then took it back out: particles
 * here are gameplay feedback, and firing them at the title screen spends
 * the vocabulary before any of it means anything. It is now, once again,
 * a thing that does not happen - just without the dead code.
 */
