#pragma once
#include "CHGameSoundTypes.h"

namespace chgame {
enum class Mood : uint8_t { Curious, Happy, Alarmed, Sleepy };
// Fills caller-owned storage with original robot-like chirps. Seed explicitly
// for repeatability; never rewrites a buffer while the audio engine reads it.
class Robot {
public:
    explicit Robot(uint32_t seed = 0x52324432u) : state_(seed ? seed : 1) {}
    size_t phrase(Step *output, size_t capacity, Mood mood);
private:
    uint32_t state_;
    uint32_t random(uint32_t limit);
};
}
