#include <Arduino.h>
#include <HardwareTimer.h>
#include "CHGameSound.h"
#include "utility/Hardware.h"
using namespace chgame;
using namespace chgame::detail;

namespace {
CHGameSound *activeSound = nullptr;
#if defined(TIM_MODULE_ENABLED) && !defined(TIM_MODULE_ONLY)
HardwareTimer controlTimer;
bool timerReady = false;
#endif
constexpr uint32_t HalfFlag = 1u<<18;
constexpr uint32_t FullFlag = 1u<<17;
constexpr uint32_t ErrorFlag = 1u<<19;
constexpr uint32_t AllFlags = 15u<<16;
uint32_t cycles() { uint32_t n; asm volatile("rdcycle %0" : "=r"(n)); return n; }
}

bool CHGameSound::begin(Output output) {
    Critical lock;
    if (begun_) return output_==output;
    if (SystemCoreClock!=48000000u || (activeSound && activeSound!=this)) return false;
    if (output!=Output::Synth && output!=Output::Lead && output!=Output::Arpeggio) return false;
    // The caller must reserve the documented timers/DMA channel for this library.
    if (output==Output::Synth && (DMA1_Channel5->CFGR & 1)) return false;
    if (output!=Output::Synth && (TIM2->CTLR1 & 1)) return false;
    if (!claim(this)) return false;
    output_=output;
    engine_.reset(output);
    maxRenderCycles_=dmaFaults_=0;
    initPinTimer();
    activeSound=this;
    begun_=true;
    if (output==Output::Synth) {
        // 64 kHz carrier, 32 kHz update/DMA request via repetition count 1.
        // CH2 preload commits at update, synchronizing sample changes to PWM.
        TIM1->PSC=0;
        TIM1->ATRLR=749;
        TIM1->RPTCR=1;
        TIM1->CH2CVR=375;
        TIM1->SWEVGR=1;
        TIM1->INTFR=0;
        for (unsigned i=0;i<128;++i) buffer_[i]=375;
        RCC->AHBPCENR |= RCC_AHBPeriph_DMA1;
        DMA1_Channel5->CFGR=0;
        DMA1->INTFCR=AllFlags;
        DMA1_Channel5->PADDR=reinterpret_cast<uint32_t>(&TIM1->CH2CVR);
        DMA1_Channel5->MADDR=reinterpret_cast<uint32_t>(buffer_);
        DMA1_Channel5->CNTR=128;
        // Halfword memory/peripheral, memory increment, circular, mem->periph,
        // very high DMA arbitration priority, HT/TC/TE IRQ enabled.
        DMA1_Channel5->CFGR=0x35be;
        NVIC_ClearPendingIRQ(DMA1_Channel5_IRQn);
        NVIC_SetPriority(DMA1_Channel5_IRQn,0x80); // USB can preempt audio.
        NVIC_EnableIRQ(DMA1_Channel5_IRQn);
        DMA1_Channel5->CFGR |= 1;
        TIM1->DMAINTENR=0x100; // UDE
        TIM1->CTLR1=0x81;
    } else {
#if defined(TIM_MODULE_ENABLED) && !defined(TIM_MODULE_ONLY)
        if (!timerReady) { controlTimer.setup(TIM2); timerReady=true; }
        controlTimer.pause();
        controlTimer.setOverflow(1000,HERTZ_FORMAT);
        controlTimer.attachInterrupt(controlInterrupt);
        controlTimer.setInterruptPriority(1,0);
        controlTimer.resume();
#else
        RCC->APB1PCENR |= RCC_APB1Periph_TIM2;
        TIM2->DMAINTENR=1;
        TIM2->CTLR2=0;
        TIM2->SMCFGR=0;
        TIM2->CCER=0;
        NVIC_ClearPendingIRQ(TIM2_UP_IRQn);
        NVIC_EnableIRQ(TIM2_UP_IRQn);
#endif
        // Explicit known clock setup; don't depend on core prescaler heuristics.
        TIM2->CTLR1=0;
        TIM2->PSC=47;
        TIM2->ATRLR=999;
        TIM2->RPTCR=0;
        TIM2->SWEVGR=1;
        TIM2->INTFR=0;
        NVIC_SetPriority(TIM2_UP_IRQn,0x80);
        TIM2->CTLR1=1;
    }
    return true;
}
void CHGameSound::end() {
    Critical lock;
    if (!begun_) return;
    if (output_==Output::Synth) {
        TIM1->DMAINTENR=0;
        DMA1_Channel5->CFGR=0;
        NVIC_DisableIRQ(DMA1_Channel5_IRQn);
        DMA1->INTFCR=AllFlags;
        NVIC_ClearPendingIRQ(DMA1_Channel5_IRQn);
    } else {
#if defined(TIM_MODULE_ENABLED) && !defined(TIM_MODULE_ONLY)
        controlTimer.pause();
        controlTimer.detachInterrupt();
#else
        TIM2->CTLR1=0;
        TIM2->DMAINTENR=0;
        TIM2->INTFR=0;
#endif
        NVIC_DisableIRQ(TIM2_UP_IRQn);
        NVIC_ClearPendingIRQ(TIM2_UP_IRQn);
    }
    engine_.stopScore(); engine_.stopEffect();
    releaseHardware(this);
    activeSound=nullptr;
    begun_=false;
}
void CHGameSound::refreshLoud() {
    if (begun_ && output_!=Output::Synth) hardwareTone(engine_.loudFrequency());
}
bool CHGameSound::playScore(const uint8_t *score, size_t bytes) {
    Critical lock;
    if (!begun_) return false;
    bool result=engine_.playScore(score,bytes);
    refreshLoud();
    return result;
}
void CHGameSound::stopScore() { Critical lock; engine_.stopScore(); refreshLoud(); }
bool CHGameSound::playing() const { Critical lock; return begun_ && engine_.playing(); }
ScoreError CHGameSound::scoreError() const { Critical lock; return engine_.error(); }
void CHGameSound::instrument(uint8_t ch, const Patch &patch) { Critical lock; engine_.instrument(ch,patch); }
void CHGameSound::noteOn(uint8_t ch,uint16_t hz,uint8_t velocity) {
    Critical lock;
    if (!begun_) return;
    engine_.noteOn(ch,hz,velocity); refreshLoud();
}
void CHGameSound::noteOff(uint8_t ch) { Critical lock; engine_.noteOff(ch); refreshLoud(); }
bool CHGameSound::effect(const Step *steps,size_t count,bool loop) {
    Critical lock;
    if (!begun_) return false;
    bool result=engine_.playEffect(steps,count,loop); refreshLoud(); return result;
}
void CHGameSound::tone(uint16_t hz,uint16_t ms) {
    Critical lock;
    if (!begun_) return;
    engine_.beep(hz,ms); refreshLoud();
}
void CHGameSound::stopEffect() { Critical lock; engine_.stopEffect(); refreshLoud(); }
bool CHGameSound::effectPlaying() const { Critical lock; return begun_ && engine_.effectPlaying(); }
void CHGameSound::mute(bool value) {
    Critical lock; engine_.mute(value); refreshLoud();
    if (value && begun_ && output_==Output::Synth && !dmaFaults_) {
        for (unsigned i=0;i<128;++i) buffer_[i]=375;
        TIM1->CH2CVR=375;
    }
}
void CHGameSound::volume(uint8_t value) { Critical lock; engine_.volume(value); refreshLoud(); }
void CHGameSound::mixing(Mix mode) { Critical lock; engine_.mixing(mode); }
void CHGameSound::arpeggioPeriod(uint8_t ms) { Critical lock; engine_.arpeggioPeriod(ms); }
CHGameSound::Statistics CHGameSound::statistics() const {
    Critical lock; return {maxRenderCycles_,dmaFaults_};
}
bool CHGameSound::pcmSource(PCMSource source,void *context) {
    Critical lock;
    if (!begun_ || output_!=Output::Synth) return false;
    engine_.pcmSource(source,context);
    return true;
}
void CHGameSound::detachPCMSource(const void *context) {
    Critical lock;
    if (engine_.hasPCMSource(context)) engine_.stopScore();
}
bool CHGameSound::hasPCMSource(const void *context) const {
    Critical lock;
    return begun_ && engine_.hasPCMSource(context);
}
void CHGameSound::controlInterrupt() {
    if (!activeSound || activeSound->output_==Output::Synth) return;
    activeSound->engine_.tick(); activeSound->refreshLoud();
}
void CHGameSound::fill(unsigned offset) {
    uint32_t start=cycles();
    for (unsigned i=offset;i<offset+64;++i) {
        int32_t sample=engine_.sample();
        buffer_[i]=uint32_t(sample+32768)*750u>>16;
    }
    asm volatile("fence rw, rw" ::: "memory");
    uint32_t elapsed=cycles()-start;
    if (elapsed>maxRenderCycles_) maxRenderCycles_=elapsed;
}
void CHGameSound::dmaFault() {
    ++dmaFaults_;
    TIM1->DMAINTENR=0;
    DMA1_Channel5->CFGR=0;
    DMA1->INTFCR=AllFlags;
    hardwareSilence();
    // Latch silence; end()/begin() explicitly restarts after a missed deadline.
}
void CHGameSound::dmaInterrupt() {
    uint32_t flags=DMA1->INTFR & AllFlags;
    DMA1->INTFCR=flags;
    CHGameSound *s=activeSound;
    if (!s || s->output_!=Output::Synth || s->dmaFaults_) return;
    if ((flags & ErrorFlag) || ((flags & HalfFlag) && (flags & FullFlag))) { s->dmaFault(); return; }
    if (flags & HalfFlag) s->fill(0);
    else if (flags & FullFlag) s->fill(64);
    // A new boundary during refill means we have exhausted the 2 ms budget.
    if (DMA1->INTFR & (HalfFlag|FullFlag|ErrorFlag)) s->dmaFault();
}
extern "C" void DMA1_Channel5_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
extern "C" void DMA1_Channel5_IRQHandler(void) { CHGameSound::dmaInterrupt(); }
#if !defined(TIM_MODULE_ENABLED) || defined(TIM_MODULE_ONLY)
// The stripped core has no strong timer ISR. The ordinary core owns this symbol
// and routes the same callback through HardwareTimer instead.
extern "C" void TIM2_UP_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
extern "C" void TIM2_UP_IRQHandler(void) {
    if (TIM2->INTFR & 1) { TIM2->INTFR=uint16_t(~1u); CHGameSound::controlInterrupt(); }
}
#endif
