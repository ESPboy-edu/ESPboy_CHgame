#pragma once
#include "CHGameSoundTypes.h"
#include "utility/Engine.h"

class CHGameSound {
public:
    struct Statistics {
        uint32_t maxRenderCycles;
        uint32_t dmaFaults;
    };
    CHGameSound() = default;
    ~CHGameSound() { end(); }
    CHGameSound(const CHGameSound &) = delete;
    CHGameSound &operator=(const CHGameSound &) = delete;
    bool begin(chgame::Output output = chgame::Output::Arpeggio);
    void end();
    bool playScore(const uint8_t *score, size_t bytes);
    template<size_t N> bool playScore(const uint8_t (&score)[N]) { return playScore(score,N); }
    void stopScore();
    bool playing() const;
    chgame::ScoreError scoreError() const;
    void instrument(uint8_t channel, const chgame::Patch &patch);
    void noteOn(uint8_t channel, uint16_t hz, uint8_t velocity = 255);
    void noteOff(uint8_t channel);
    bool effect(const chgame::Step *steps, size_t count, bool loop = false);
    template<size_t N> bool effect(const chgame::Step (&steps)[N]) { return effect(steps,N,false); }
    template<size_t N> bool loopEffect(const chgame::Step (&steps)[N]) { return effect(steps,N,true); }
    void tone(uint16_t hz, uint16_t durationMs = 100);
    void stopEffect();
    bool effectPlaying() const;
    void mute(bool muted);
    void volume(uint8_t volume); // Synth: 0..255. Loud outputs: zero/nonzero only.
    void mixing(chgame::Mix mode);
    void arpeggioPeriod(uint8_t milliseconds);
    Statistics statistics() const;
    // Callback runs in the DMA ISR: no blocking, allocation, file I/O, or APIs.
    // The context must outlive attachment. Music/effects share master mute/volume.
    bool pcmSource(chgame::PCMSource source, void *context);
    void detachPCMSource(const void *context);
    bool hasPCMSource(const void *context) const;
    // Backend interrupt entry points, not sketch API.
    static void controlInterrupt();
    static void dmaInterrupt();
private:
    chgame::detail::Engine engine_;
    chgame::Output output_ = chgame::Output::Arpeggio;
    bool begun_ = false;
    volatile uint32_t maxRenderCycles_ = 0, dmaFaults_ = 0;
    alignas(4) uint16_t buffer_[128] = {};
    void refreshLoud();
    void fill(unsigned offset);
    void dmaFault();
};
