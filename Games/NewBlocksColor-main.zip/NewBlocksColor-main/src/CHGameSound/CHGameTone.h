#pragma once
#include <stdint.h>

// Minimal hardware-only tone driver. One owner of PB10/TIM1 at a time.
// No ISR and no heap. Call update() to expire a duration; indefinite tones need
// no servicing. CHGameSound provides interrupt-driven durations and sequencing.
class CHGameTone {
public:
    CHGameTone() = default;
    ~CHGameTone() { end(); }
    CHGameTone(const CHGameTone &) = delete;
    CHGameTone &operator=(const CHGameTone &) = delete;
    bool begin();
    void end();
    void tone(uint16_t hz, uint32_t durationMs = 0);
    void noTone();
    void update();
    bool playing() const { return sounding_; }
private:
    uint32_t started_ = 0, duration_ = 0;
    bool sounding_ = false;
};
