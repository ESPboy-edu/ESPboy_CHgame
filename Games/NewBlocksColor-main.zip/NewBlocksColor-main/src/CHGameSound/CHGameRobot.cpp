#include "CHGameRobot.h"
namespace chgame {
uint32_t Robot::random(uint32_t limit) {
    state_^=state_<<13; state_^=state_>>17; state_^=state_<<5;
    return state_%limit;
}
size_t Robot::phrase(Step *out,size_t capacity,Mood mood) {
    if (!out || capacity<2) return 0;
    size_t count=8+random(13);
    if (count>capacity) count=capacity;
    uint16_t base=uint16_t(900+random(900));
    for (size_t i=0;i<count;++i) {
        bool pause=(i%5==4);
        uint16_t hz=uint16_t(base+random(1700));
        uint16_t end=uint16_t(800+random(2900));
        uint16_t ms=uint16_t(25+random(90));
        Preset patch=Preset::Robot;
        if (mood==Mood::Happy) { end=uint16_t(hz+300+random(650)); ms=uint16_t(25+random(55)); patch=Preset::Beep; }
        if (mood==Mood::Curious) { end=uint16_t(hz+100+random(700)); ms=uint16_t(60+random(110)); }
        if (mood==Mood::Alarmed) { hz=(i&1)?3400:1500; end=(i&1)?1700:3700; ms=uint16_t(25+random(45)); patch=Preset::Laser; }
        if (mood==Mood::Sleepy) { hz=uint16_t(650+random(650)); end=uint16_t(hz/2); ms=uint16_t(160+random(170)); patch=Preset::Soft; }
        out[i]={uint16_t(pause?0:hz),end,uint16_t(pause?60+random(160):ms),patch,255};
    }
    return count;
}
}
