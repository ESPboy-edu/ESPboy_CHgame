#include "Engine.h"
#include "Tables.h"

namespace chgame {
Patch preset(Preset which) {
    Patch p;
    switch (which) {
    case Preset::Pluck: p.wave=Wave::Pulse; p.duty=96; p.decayMs=90; p.sustain=55; p.releaseMs=30; break;
    case Preset::Bell: p.wave=Wave::FM; p.fmRatio=3; p.fmDepth=90; p.decayMs=220; p.sustain=25; p.releaseMs=100; break;
    case Preset::Bass: p.wave=Wave::Triangle; p.decayMs=30; p.sustain=210; p.releaseMs=15; break;
    case Preset::Laser: p.wave=Wave::Saw; p.decayMs=140; p.sustain=30; p.releaseMs=10; break;
    case Preset::Noise: p.wave=Wave::Noise; p.attackMs=0; p.decayMs=70; p.sustain=0; p.releaseMs=5; break;
    case Preset::Robot: p.wave=Wave::FM; p.fmRatio=2; p.fmDepth=42; p.vibratoHz=25; p.vibratoDepth=45; p.releaseMs=8; break;
    case Preset::Soft: p.wave=Wave::Sine; p.attackMs=12; p.decayMs=80; p.sustain=180; p.releaseMs=60; break;
    default: break;
    }
    return p;
}
namespace detail {
Engine::Engine() { reset(Output::Arpeggio); }
void Engine::reset(Output mode) {
    output_ = mode;
    source_=nullptr; sourceContext_=nullptr;
    for (unsigned i=0; i<Channels; ++i) {
        voices_[i] = Voice();
        voices_[i].noise += i * 73471u;
    }
    fx_ = Voice();
    fx_.noise = 0xbadeu;
    score_=nullptr; scoreSize_=scorePos_=0; wait_=0; scoreRunning_=false;
    error_=ScoreError::None;
    steps_=nullptr; stepCount_=stepPos_=0; effectTick_=0;
    effectRunning_=effectLoop_=false;
    master_=255; muted_=false; mix_=Mix::Adaptive;
    arpMs_=6; arpTick_=arpChannel_=sampleTick_=0;
}
void Engine::pitch(Voice &v, uint16_t hz) {
    if (hz > 15000) hz=15000;
    v.hz=hz;
    v.baseStep=uint32_t((uint64_t(hz)<<32)/SampleRate);
    v.step=v.baseStep;
    v.modStep=v.step*v.patch.fmRatio;
}
void Engine::envelope(Voice &v, uint8_t stage, int32_t target, uint16_t ms) {
    v.stage=stage; v.envTarget=target; v.envTicks=ms;
    v.envDelta=ms ? (target-v.env)/ms : 0;
    if (!ms) v.env=target;
}
void Engine::start(Voice &v, uint16_t hz, uint8_t velocity) {
    if (!hz) { release(v); return; }
    pitch(v,hz);
    v.phase=v.modPhase=0;
    v.velocity=velocity;
    v.gate=true;
    v.env=0;
    envelope(v,1,255<<8,v.patch.attackMs);
    if (!v.patch.attackMs) {
        envelope(v,2,int32_t(v.patch.sustain)<<8,v.patch.decayMs);
        if (!v.patch.decayMs) v.stage=3;
    }
}
void Engine::release(Voice &v) {
    v.gate=false;
    if (!v.stage) return;
    envelope(v,4,0,v.patch.releaseMs);
    if (!v.envTicks) v.stage=0;
}
void Engine::control(Voice &v) {
    if (!v.stage) return;
    if (v.envTicks) {
        v.env += v.envDelta;
        if (!--v.envTicks) v.env=v.envTarget;
    }
    // Zero-time stages complete in the same control tick.
    if (!v.envTicks && v.stage==1) envelope(v,2,int32_t(v.patch.sustain)<<8,v.patch.decayMs);
    if (!v.envTicks && v.stage==2) v.stage=3;
    if (!v.envTicks && v.stage==4) v.stage=0;
    v.lfoPhase += uint16_t(uint32_t(v.patch.vibratoHz)*65536u/1000u);
    int32_t delta=int32_t(sineTable[v.lfoPhase>>8])*v.patch.vibratoDepth;
    // Multiply after division to keep the 32-bit intermediate bounded.
    int32_t increment=(delta*1048); // ~2^32/(32000*128)
    int64_t step=int64_t(v.baseStep)+increment;
    if (step<1) step=1;
    if (step>2013265920LL) step=2013265920LL; // 15 kHz
    v.step=uint32_t(step);
    v.modStep=v.step*v.patch.fmRatio;
}
void Engine::instrument(uint8_t ch, const Patch &patch) {
    if (ch>=Channels) return;
    voices_[ch].patch=patch;
    Patch &p=voices_[ch].patch;
    if (uint8_t(p.wave)>uint8_t(Wave::FM)) p.wave=Wave::Square;
    if (!p.duty) p.duty=1;
    if (p.duty>254) p.duty=254;
    if (!p.fmRatio) p.fmRatio=1;
    if (p.fmRatio>8) p.fmRatio=8;
    voices_[ch].modStep=voices_[ch].step*p.fmRatio;
}
void Engine::noteOn(uint8_t ch, uint16_t hz, uint8_t velocity) {
    if (ch<Channels) start(voices_[ch],hz,velocity);
}
void Engine::noteOff(uint8_t ch) { if (ch<Channels) release(voices_[ch]); }
bool Engine::active(uint8_t ch) const { return ch<Channels && voices_[ch].stage!=0; }
uint16_t Engine::frequency(uint8_t ch) const { return ch<Channels ? voices_[ch].hz : 0; }
uint16_t Engine::midiHz(uint8_t note) { return note<128 ? midiFrequencies[note] : 0; }

void Engine::stopScore() {
    source_=nullptr; sourceContext_=nullptr;
    scoreRunning_=false;
    wait_=0;
    // Stop is immediate, including release tails; per-note off uses envelopes.
    for (unsigned i=0;i<Channels;++i) { voices_[i].stage=0; voices_[i].gate=false; voices_[i].env=0; }
}
void Engine::fail(ScoreError error) { stopScore(); error_=error; }
bool Engine::playScore(const uint8_t *data, size_t size) {
    stopScore();
    score_=data; scoreSize_=size; scorePos_=0; error_=ScoreError::None;
    if (!data || !size) { fail(ScoreError::Truncated); return false; }
    scoreRunning_=true;
    commands();
    return error_==ScoreError::None;
}
void Engine::commands() {
    // Bound interrupt execution even for E0-only loops and hostile input.
    for (unsigned budget=0; budget<64 && scoreRunning_; ++budget) {
        if (scorePos_>=scoreSize_) { fail(ScoreError::Truncated); return; }
        uint8_t op=score_[scorePos_++];
        if (!(op & 0x80)) {
            if (scorePos_>=scoreSize_) { fail(ScoreError::Truncated); return; }
            wait_=(uint16_t(op)<<8)|score_[scorePos_++];
            if (wait_) return;
        } else if ((op & 0xf0)==0x90 || (op & 0xf0)==0x80) {
            uint8_t ch=op & 15;
            if (ch>=Channels) { fail(ScoreError::InvalidChannel); return; }
            if ((op & 0xf0)==0x90) {
                if (scorePos_>=scoreSize_) { fail(ScoreError::Truncated); return; }
                uint8_t note=score_[scorePos_++];
                if (note>127) { fail(ScoreError::InvalidNote); return; }
                start(voices_[ch],midiHz(note),255);
                voices_[ch].step=voices_[ch].baseStep=midiSteps[note];
                voices_[ch].modStep=midiSteps[note]*voices_[ch].patch.fmRatio;
            } else noteOff(ch);
        } else if (op==0xf0) { stopScore(); return;
        } else if (op==0xe0) { scorePos_=0;
        } else { fail(ScoreError::InvalidCommand); return; }
    }
    if (scoreRunning_) fail(ScoreError::CommandBudget);
}
bool Engine::playEffect(const Step *steps, size_t count, bool loop) {
    if (!steps || !count) return false;
    // Validate up front at the call site. Bound the table to keep critical-
    // section latency and indexing predictable.
    if (count>256) return false;
    for (size_t i=0;i<count;++i) if (!steps[i].durationMs || uint8_t(steps[i].sound)>uint8_t(Preset::Soft)) return false;
    steps_=steps; stepCount_=count; stepPos_=0; effectLoop_=loop;
    effectRunning_=true;
    startStep();
    return true;
}
void Engine::startStep() {
    const Step &s=steps_[stepPos_];
    effectTick_=0;
    fx_.patch=preset(s.sound);
    fx_.stage=0; fx_.env=0; fx_.gate=false;
    if (s.hz) start(fx_,s.hz,s.volume);
}
void Engine::stopEffect() { effectRunning_=false; fx_.stage=0; fx_.env=0; }
void Engine::beep(uint16_t hz, uint16_t ms) {
    if (!hz || !ms) { stopEffect(); return; }
    beepStep_={hz,hz,ms,Preset::Beep,255};
    playEffect(&beepStep_,1,false);
}
void Engine::tick() {
    if (scoreRunning_) {
        if (wait_) --wait_;
        if (!wait_) commands();
    }
    if (effectRunning_) {
        const Step &s=steps_[stepPos_];
        if (++effectTick_>=s.durationMs) {
            ++stepPos_;
            if (stepPos_==stepCount_) {
                if (effectLoop_) stepPos_=0; else stopEffect();
            }
            if (effectRunning_) startStep();
        } else if (s.hz && s.endHz) {
            int32_t hz=int32_t(s.hz)+(int32_t(s.endHz)-s.hz)*effectTick_/s.durationMs;
            pitch(fx_,uint16_t(hz));
        }
        if (effectRunning_ && output_==Output::Synth) {
            const Step &current=steps_[stepPos_];
            uint16_t left=current.durationMs-effectTick_;
            if (fx_.gate && left<=fx_.patch.releaseMs) release(fx_);
        }
    }
    for (unsigned i=0;i<Channels;++i) control(voices_[i]);
    control(fx_);
    if (++arpTick_>=arpMs_) {
        arpTick_=0;
        for (unsigned n=0;n<Channels;++n) {
            arpChannel_=(arpChannel_+1)%Channels;
            const Voice &v=voices_[arpChannel_];
            if (v.gate && v.velocity && v.patch.volume) break;
        }
    }
}
uint16_t Engine::loudFrequency() const {
    if (muted_ || !master_) return 0;
    if (effectRunning_) return fx_.gate && fx_.velocity ? fx_.hz : 0;
    for (unsigned n=0;n<Channels;++n) {
        unsigned i=(output_==Output::Lead) ? n : (arpChannel_+n)%Channels;
        const Voice &v=voices_[i];
        if (v.gate && v.velocity && v.patch.volume) return v.hz;
    }
    return 0;
}
int32_t Engine::oscillator(Voice &v) {
    uint32_t old=v.phase;
    v.phase+=v.step;
    v.modPhase+=v.modStep;
    uint8_t p=v.phase>>24;
    int32_t value=0;
    switch (v.patch.wave) {
    case Wave::Square: value=p<128 ? 127 : -127; break;
    case Wave::Pulse:
        // Center each asymmetric pulse so duty modulation doesn't add a large DC offset.
        value=p<v.patch.duty ? 255-v.patch.duty : -int32_t(v.patch.duty); break;
    case Wave::Triangle: value=p<128 ? int32_t(p)*2-127 : 383-int32_t(p)*2; break;
    case Wave::Saw: value=int32_t(p)-128; break;
    case Wave::Noise:
        if (v.phase<old) {
            v.noise^=v.noise<<13; v.noise^=v.noise>>17; v.noise^=v.noise<<5;
        }
        value=(v.noise & 1) ? 127 : -127; break;
    case Wave::Sine: value=sineTable[p]; break;
    case Wave::FM: {
        int32_t mod=int32_t(sineTable[v.modPhase>>24])*v.patch.fmDepth/128;
        value=sineTable[uint8_t(int32_t(p)+mod)]; break;
    }
    }
    int32_t gain=(v.env>>8)*v.patch.volume/255;
    gain=gain*v.velocity/255;
    return value*gain; // Normally +/-32385; pulse can be asymmetric.
}
int16_t Engine::sample() {
    int32_t sum=0;
    unsigned count=0;
    // Always advance an external source, including while an effect ducks it.
    int32_t external=source_ ? source_(sourceContext_) : 0;
    if (effectRunning_) {
        if (fx_.stage) { sum=oscillator(fx_); count=1; }
        // Music phases continue while ducked, preserving oscillator continuity.
        for (unsigned i=0;i<Channels;++i) if (voices_[i].stage) {
            voices_[i].phase+=voices_[i].step; voices_[i].modPhase+=voices_[i].modStep;
        }
    } else if (source_) {
        sum=external;
    } else {
        for (unsigned i=0;i<Channels;++i) {
            Voice &v=voices_[i];
            if (v.stage && v.velocity && v.patch.volume) {
                sum+=oscillator(v);
                if (v.env>0) ++count;
            }
        }
    }
    if (!source_ && !effectRunning_ && count) {
        if (mix_==Mix::Headroom) sum/=Channels;
        else if (mix_==Mix::Adaptive) sum/=int32_t(count);
        // Drive intentionally saturates instead of dividing down the voices.
    }
    if (sum>32767) sum=32767;
    if (sum<-32767) sum=-32767;
    sum=sum*master_/255;
    if (muted_) sum=0;
    if (++sampleTick_==SampleRate/1000) { sampleTick_=0; tick(); }
    return int16_t(sum);
}
} }
