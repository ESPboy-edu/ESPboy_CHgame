#!/usr/bin/env python3
"""Generate Sfx.h: the game's sound effects as CHGameSound Step arrays.

This is a straight port of the generator in CH32Sound's SfxGenerator example
(itself the Effects tab of https://cloud.arduboy.com), so every effect below is
a saved slider state rather than a hand-typed frequency list. Each array in the
output is headed by the same "// SFX: ..." line the web app and the on-device
generator print; paste it into the Effects tab to hear or edit that sound there,
then copy the numbers back here.

    python tools/gen_sfx.py            # rewrites ../Sfx.h next to the sketch

Standard library only. Output pitches use the on-device midiHz() rounding so a
sound generated here is byte-identical to the one the CHGame would print.
"""
import math
from pathlib import Path

UP, DOWN, PEAK, VALLEY = 0, 1, 2, 3
DIRECTION_NAMES = ['up', 'down', 'peak', 'valley']
MASK = 0xFFFFFFFF


class Params:
    def __init__(self, length, pitch, range_, direction, speed, grit=0, repeat=1,
                 vibe=0, curve=0, shape=0, attack=10, seed=0x1234ABCD):
        self.length, self.pitch, self.range, self.direction = length, pitch, range_, direction
        self.speed, self.grit, self.repeat, self.vibe = speed, grit, repeat, vibe
        self.curve, self.shape, self.attack, self.seed = curve, shape, attack, seed


# ---- mulberry32, exactly as the web app and the sketch -----------------------
class Rng:
    def __init__(self, seed):
        self.state = seed & MASK

    def __call__(self):
        self.state = (self.state + 0x6D2B79F5) & MASK
        t = self.state
        t = ((t ^ (t >> 15)) * (1 | t)) & MASK
        t = ((t + (((t ^ (t >> 7)) * (61 | t)) & MASK)) ^ t) & MASK
        return ((t ^ (t >> 14)) & MASK) / 4294967296.0


def js_round(x):
    return math.floor(x + 0.5)


# ---- pitch curve shaping ------------------------------------------------------
def remap_time_to_pivot(t, attack):
    pivot = min(max(attack * 0.5, 0.001), 0.999)
    return 0.5 * (t / pivot) if t < pivot else 0.5 + 0.5 * ((t - pivot) / (1.0 - pivot))


def apply_curve(t, curve):
    if abs(curve) < 0.02:
        return t
    p = 1.0 + abs(curve) * 4.0
    return t ** p if curve < 0 else 1.0 - (1.0 - t) ** p


def apply_shape(t, shape):
    if abs(shape) < 0.01:
        return t
    k = 1.0 + abs(shape) * 4.0
    s = 0.5 * (2.0 * t) ** k if t < 0.5 else 1.0 - 0.5 * (2.0 * (1.0 - t)) ** k
    return s if shape > 0 else t + (t - s)


def shape_pipeline(t, curve, attack, shape):
    return apply_shape(apply_curve(remap_time_to_pivot(t, attack), curve), shape)


# ---- the generator ------------------------------------------------------------
OCTAVE8 = [4186, 4435, 4699, 4978, 5274, 5588, 5920, 6272, 6645, 7040, 7459, 7902]


def midi_hz(note):
    """The sketch's integer table lookup, so pitches match the device output."""
    shift = (119 - note) // 12
    return (OCTAVE8[note % 12] + (1 << shift) // 2) >> shift


def generate(p):
    """Return a list of (hz, duration_ms) steps; hz 0 is a rest."""
    curve, attack, shape = p.curve / 10.0, p.attack / 10.0, p.shape / 10.0
    note_count = p.length or 1
    length_norm = min((note_count - 1) / 12.0, 1.0)
    dur_attack_influence = 1.0 - length_norm
    rnd = Rng(p.seed)
    events = []
    for i in range(note_count):
        t = i / (note_count - 1) if note_count > 1 else 0.0
        if p.direction == UP:
            note = p.pitch + p.range * shape_pipeline(t, curve, attack, shape)
        elif p.direction == DOWN:
            note = p.pitch + p.range * (1.0 - shape_pipeline(t, curve, attack, shape))
        else:
            half = t * 2 if t <= 0.5 else (1.0 - t) * 2
            shaped = shape_pipeline(half, curve, attack, shape)
            note = p.pitch + p.range * (shaped if p.direction == PEAK else 1.0 - shaped)
        if p.vibe:
            note += -p.vibe if i & 1 else p.vibe
        if p.grit:
            note += (rnd() - 0.5) * 2 * p.grit
        dur = p.speed * (0.85 + rnd() * 0.3)
        if dur_attack_influence > 0.1:
            dur *= 1.0 + (attack - 1.0) * (1.0 - t) * dur_attack_influence
        rest = p.speed * 0.05 + rnd() * p.speed * 0.2 if p.grit > 6 else p.speed * 0.05
        if p.grit <= 6 and rest < 2:
            rest = 2
        n = min(max(js_round(note), 0), 119)
        d = max(js_round(dur), 10)
        r = max(js_round(rest), 0)
        events.append((n, d, r))
    steps = []
    for _ in range(p.repeat):
        for n, d, r in events:
            steps.append((midi_hz(n), d))
            if r:
                steps.append((0, r))
    return steps


def tenths(v):
    if v % 10 == 0:
        return str(v // 10)
    sign = '-' if v < 0 else ''
    return f'{sign}{abs(v) // 10}.{abs(v) % 10}'


def sfx_line(p):
    return (f'// SFX: direction={DIRECTION_NAMES[p.direction]} length={p.length} speed={p.speed} '
            f'pitch={p.pitch} range={p.range} vibe={p.vibe} grit={p.grit} curve={tenths(p.curve)} '
            f'attack={tenths(p.attack)} shape={tenths(p.shape)} repeat={p.repeat} seed={p.seed}')


# ---- the game's sounds --------------------------------------------------------
#
# The piezo is a 4 kHz resonant part that is usable from roughly 190 Hz to
# 3 kHz (MIDI 55..103), so every pattern here sits an octave or two above where
# the web app's presets put it: an "explosion" at MIDI 36 is 65 Hz, which this
# speaker cannot make at all. Durations are short on purpose. The output is a
# single hardware square wave, so an effect silences the music for exactly as
# long as it lasts.
#
# One sound may be a sequence of patterns (a hard drop is a whoosh, then a slam);
# each keeps its own SFX line.

SOUNDS = [
    ('SFX_MOVE', 'Piece moved sideways: two-note click, high and short.', [
        Params(2, 98, 5, DOWN, 12),
    ]),
    ('SFX_TICK', 'Piece stepped down a row: one 10 ms tick that keeps time.', [
        Params(1, 74, 1, DOWN, 5),
    ]),
    ('SFX_LAND', 'Piece hit the floor: a heavier, longer thud.', [
        Params(4, 63, 13, DOWN, 24, grit=1, curve=-5, attack=16),
    ]),
    ('SFX_DROP', 'Hard drop: a fast whoosh down the well ("laser"). Sound.h appends the landing tone for the row.', [
        Params(8, 66, 34, DOWN, 8, curve=3),
    ]),
    ('SFX_CLEAR', 'Row cleared: rising "powerup" with a trill, then a "coin" sparkle on top.', [
        Params(10, 76, 14, UP, 30, vibe=2, curve=-3),
        Params(4, 88, 12, UP, 38),
    ]),
    ('SFX_TITLE', 'A pressed on the title: a "blip".', [
        Params(4, 84, 6, VALLEY, 30),
    ]),
    ('SFX_GO', 'Well revealed, play begins: rising "powerup".', [
        Params(9, 72, 19, UP, 42, curve=-1),
    ]),
    ('SFX_OVER', 'Topped out: a gritty descending run.', [
        Params(8, 60, 30, DOWN, 40, grit=4, curve=2, attack=12),
    ]),
    ('SFX_SHATTER', 'One row of the stack coming apart: a noisy crackle. Transposed per row at runtime.', [
        Params(3, 70, 8, DOWN, 12, grit=10),
    ]),
    ('SFX_BANNER', 'The game over banner opening: a low "explosion" rumble.', [
        Params(12, 58, 14, DOWN, 18, grit=14),
    ]),
]

# Per-row pitch multipliers (x/256) for the shatter crackle: the demolition
# runs bottom to top and drops half a semitone a row as it climbs, like the
# original's 440 - 10 Hz per step. (A piece settling on the stack is not
# generated here at all: it is the original's own 587 + 30 Hz per row tone,
# computed in Sound.h.)
ROWS = 15
SHATTER_ROW = [round(256 * 2 ** (-(ROWS - 1 - row) * 0.5 / 12)) for row in range(ROWS)]


def emit_array(name, comment, patterns, out):
    steps = []
    lines = []
    for p in patterns:
        lines.append(sfx_line(p))
        steps.extend(generate(p))
    total = sum(d for _, d in steps)
    out.append(f'/* {comment} {total} ms, {len(steps)} steps. */')
    out.extend(lines)
    out.append(f'static const chgame::Step {name}[] = {{')
    row = []
    for hz, d in steps:
        row.append(f'{{{hz}, 0, {d}, chgame::Preset::Beep, {255 if hz else 0}}}')
        if len(row) == 3:
            out.append('    ' + ', '.join(row) + ',')
            row = []
    if row:
        out.append('    ' + ', '.join(row) + ',')
    out.append('};')
    out.append('')
    return total


def main():
    out = [
        '/*',
        ' * Sfx.h - the sound effects, as CHGameSound effect steps.',
        ' *',
        ' * GENERATED by tools/gen_sfx.py - edit the parameters there, not the',
        ' * numbers here. Every array comes from the CH32Sound SfxGenerator',
        ' * algorithm (the cloud.arduboy.com Effects tab); the "// SFX:" line',
        ' * above each one reopens that exact sound in the web app.',
        ' *',
        ' * A Step is {startHz, endHz, ms, preset, volume}. hz 0 is a rest. The',
        ' * game plays these on the Lead output, one full-swing square wave, so',
        ' * preset and volume are carried but not audible.',
        ' */',
        '#pragma once',
        '#include "src/CHGameSound/CHGameSound.h"',
        '',
    ]
    for name, comment, patterns in SOUNDS:
        emit_array(name, comment, patterns, out)
    out.append('/* Pitch multipliers (x/256) by board row, 0 = top. See tools/gen_sfx.py. */')
    out.append('static const uint16_t SFX_SHATTER_ROW[%d] = { %s };' % (ROWS, ', '.join(map(str, SHATTER_ROW))))
    out.append('')
    target = Path(__file__).resolve().parents[1] / 'Sfx.h'
    target.write_text('\n'.join(out), newline='\n')
    print('wrote', target)
    for name, _, patterns in SOUNDS:
        steps = [s for p in patterns for s in generate(p)]
        total = sum(d for _, d in steps)
        notes = [hz for hz, _ in steps if hz]
        print(f'  {name:12s} {total:4d} ms  {len(steps):2d} steps  {min(notes)}..{max(notes)} Hz')


if __name__ == '__main__':
    main()
