#pragma once
#include "../CHGameSoundTypes.h"

namespace chgame { namespace detail {
// Portable synthesis/sequencing core. Called serially by the hardware backend.
class Engine {
public:
    static constexpr unsigned Channels = 4;
    static constexpr unsigned SampleRate = 32000;
    Engine();
    void reset(Output mode);
    bool playScore(const uint8_t *data, size_t size);
    void stopScore();
    bool playEffect(const Step *steps, size_t count, bool loop);
    void stopEffect();
    void beep(uint16_t hz, uint16_t ms);
    void noteOn(uint8_t channel, uint16_t hz, uint8_t velocity = 255);
    void noteOff(uint8_t channel);
    void instrument(uint8_t channel, const Patch &patch);
    void tick();                    // Exactly one millisecond.
    int16_t sample();               // Signed PCM, includes its own 1 ms clock.
    uint16_t loudFrequency() const;
    bool playing() const { return scoreRunning_; }
    bool effectPlaying() const { return effectRunning_; }
    bool active(uint8_t ch) const;
    uint16_t frequency(uint8_t ch) const;
    ScoreError error() const { return error_; }
    void mute(bool value) { muted_ = value; }
    void volume(uint8_t value) { master_ = value; }
    void mixing(Mix value) { mix_ = value; }
    void arpeggioPeriod(uint8_t ms) { arpMs_ = ms ? ms : 1; }
    void pcmSource(PCMSource source, void *context) { stopScore(); source_=source; sourceContext_=context; }
    bool hasPCMSource(const void *context) const { return source_ && sourceContext_==context; }
    static uint16_t midiHz(uint8_t note);

private:
    struct Voice {
        Patch patch;
        uint32_t phase = 0, modPhase = 0, step = 0, modStep = 0, baseStep = 0;
        uint32_t noise = 0x1ace1u;
        uint16_t hz = 0, envTicks = 0;
        int32_t env = 0, envDelta = 0, envTarget = 0;
        uint8_t stage = 0, velocity = 255, lfo = 0;
        uint16_t lfoPhase = 0;
        bool gate = false;
    };
    Voice voices_[Channels], fx_;
    Output output_ = Output::Arpeggio;
    Mix mix_ = Mix::Adaptive;
    uint8_t master_ = 255, arpMs_ = 6, arpTick_ = 0, arpChannel_ = 0;
    uint8_t sampleTick_ = 0;
    bool muted_ = false;
    PCMSource source_ = nullptr;
    void *sourceContext_ = nullptr;
    const uint8_t *score_ = nullptr;
    size_t scoreSize_ = 0, scorePos_ = 0;
    uint16_t wait_ = 0;
    bool scoreRunning_ = false;
    ScoreError error_ = ScoreError::None;
    const Step *steps_ = nullptr;
    size_t stepCount_ = 0, stepPos_ = 0;
    uint16_t effectTick_ = 0;
    bool effectRunning_ = false, effectLoop_ = false;
    Step beepStep_ = {};
    void commands();
    void fail(ScoreError error);
    void startStep();
    static void start(Voice &v, uint16_t hz, uint8_t velocity);
    static void release(Voice &v);
    static void envelope(Voice &v, uint8_t stage, int32_t target, uint16_t ms);
    static void control(Voice &v);
    static int32_t oscillator(Voice &v);
    static void pitch(Voice &v, uint16_t hz);
};
} }
