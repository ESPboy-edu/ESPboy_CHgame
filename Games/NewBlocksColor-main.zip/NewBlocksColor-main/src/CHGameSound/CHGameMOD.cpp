#include "CHGameMOD.h"
#include "utility/Hardware.h"
using chgame::detail::Critical;
bool CHGameMOD::play(const uint8_t *data,size_t bytes,bool loop) {
    stop();
    // Validation is outside the critical section and cannot be raced by audio:
    // this player's callback is detached until validation completes.
    if (!player_.load(data,bytes,loop)) return false;
    if (!audio_.pcmSource(render,this)) { player_.stop(); return false; }
    return true;
}
void CHGameMOD::stop() { audio_.detachPCMSource(this); player_.stop(); }
bool CHGameMOD::playing() const { Critical lock; return audio_.hasPCMSource(this) && player_.playing(); }
chgame::MODError CHGameMOD::error() const { Critical lock; return player_.error(); }
void CHGameMOD::gain(uint16_t q8) { Critical lock; player_.gain(q8); }
int16_t CHGameMOD::render(void *context) { return static_cast<CHGameMOD *>(context)->player_.sample(); }
