/*
 * appsim - run the whole CHStlView sketch on a PC.
 *
 *   appsim CARD_DIR SCRIPT OUT_DIR
 *
 * CARD_DIR stands in for the microSD card. SCRIPT drives the buttons and
 * says when to photograph the panel:
 *
 *   end  <ms>                   stop the simulation
 *   at   <ms> <BUTTONS|->       from <ms> on, exactly these are held
 *   tap  <ms> <BUTTONS>         held for 60 ms from <ms>
 *   snap <ms> <name>            write the panel to OUT_DIR/<name>.fb
 *
 * BUTTONS is a +-joined list of A B UP DOWN LEFT RIGHT START SELECT.
 *
 * Time is virtual. It advances with the device's measured costs for card
 * reads and panel transfers, plus a little per loop(); drawing itself is
 * free, which is close to the truth for this sketch because its drawing
 * overlaps the card DMA. Serial output goes to stdout with a timestamp.
 */
#include <Arduino.h>
#include <CHGfx.h>
#include "sdmock.h"
#include "CHGfx_font.h"      /* the real 5x7 font, from the installed CHGfx */

#include <algorithm>
#include <dirent.h>
#include <map>
#include <string>
#include <sys/stat.h>
#include <vector>

void setup();
void loop();

/* ------------------------------------------------------------------------ */
/* Clock, buttons, snapshots                                                 */
/* ------------------------------------------------------------------------ */
static uint64_t nowUs;
static std::vector<std::pair<uint32_t, uint8_t>> buttonEvents;   /* (ms, mask) */
static std::vector<std::pair<uint32_t, std::string>> snaps;
static size_t nextSnap;
static std::string outDir;
static uint32_t endMs = 10000;
static int bugs;

uint8_t sim_panel[GFX_FB_BYTES];

static void takeSnaps()
{
    while (nextSnap < snaps.size() && snaps[nextSnap].first * 1000ull <= nowUs) {
        std::string p = outDir + "/" + snaps[nextSnap].second + ".fb";
        FILE *f = fopen(p.c_str(), "wb");
        if (f) { fwrite(sim_panel, 1, sizeof sim_panel, f); fclose(f); }
        printf("[%7.1f ms] snap %s\n", nowUs / 1000.0, snaps[nextSnap].second.c_str());
        nextSnap++;
    }
}

void simAdvanceUs(uint64_t us)
{
    nowUs += us;
    takeSnaps();
    if (nowUs / 1000 > endMs + 60000) { printf("stuck: no way out of a loop\n"); exit(3); }
}

uint32_t millis(void) { return (uint32_t)(nowUs / 1000); }
uint32_t micros(void) { return (uint32_t)nowUs; }
void delay(uint32_t ms) { simAdvanceUs(ms * 1000ull); }

static uint8_t buttonsNow()
{
    uint8_t m = 0;
    const uint32_t t = millis();
    for (auto &e : buttonEvents) if (e.first <= t) m = e.second;
    return m;
}

int digitalRead(int pin)
{
    static const uint8_t bit[] = { 0, 1, 2, 4, 8, 16, 32, 64, 128 };  /* A B UP DOWN LEFT RIGHT START SELECT */
    if (pin < PIN_BTN_A || pin > PIN_BTN_SELECT) return HIGH;
    return (buttonsNow() & bit[pin]) ? LOW : HIGH;
}

SerialMock Serial;

void simBug(const char *what)
{
    printf("[%7.1f ms] BUG: %s\n", nowUs / 1000.0, what);
    bugs++;
}

/* ------------------------------------------------------------------------ */
/* CHGfx                                                                     */
/* ------------------------------------------------------------------------ */
uint8_t  gfx_fb[GFX_FB_BYTES];
uint16_t gfx_pal[16];
CHGfx    Gfx;
static uint8_t  chunk[2 * GFX_CHUNK_BYTES];
static uint64_t busyUntil;

static void checkIdle(const char *who)
{
    if (nowUs < busyUntil) {
        char b[96];
        snprintf(b, sizeof b, "%s while an async flush is still reading the framebuffer", who);
        simBug(b);
    }
}

void gfx_begin(uint8_t, uint8_t) {}
void gfx_setPalette(const uint16_t *p, uint8_t n) { memcpy(gfx_pal, p, n * 2); }

/* CHGfx in 12 bpp rounds x and w outwards to multiples of 8. */
static uint64_t sendRect(int x, int y, int w, int h)
{
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > GFX_W) w = GFX_W - x;
    if (y + h > GFX_H) h = GFX_H - y;
    if (w <= 0 || h <= 0) return 0;
    int x0 = x & ~7, x1 = (x + w + 7) & ~7;
    for (int r = y; r < y + h; r++)
        memcpy(sim_panel + r * GFX_FB_STRIDE + x0 / 2, gfx_fb + r * GFX_FB_STRIDE + x0 / 2, (x1 - x0) / 2);
    return 40 + (uint64_t)(x1 - x0) * h / 2;      /* 0.5 us per pixel at 12 bpp, 24 MHz */
}

void gfx_wait(void) { if (nowUs < busyUntil) simAdvanceUs(busyUntil - nowUs); }
bool gfx_busy(void) { return nowUs < busyUntil; }
void gfx_flush(void) { gfx_wait(); simAdvanceUs(sendRect(0, 0, GFX_W, GFX_H)); }
void gfx_flushAsync(void) { gfx_wait(); busyUntil = nowUs + sendRect(0, 0, GFX_W, GFX_H); }
void gfx_flushRect(int x, int y, int w, int h) { gfx_wait(); simAdvanceUs(sendRect(x, y, w, h)); }
void gfx_flushRectAsync(int x, int y, int w, int h) { gfx_wait(); busyUntil = nowUs + sendRect(x, y, w, h); }
uint8_t *gfx_chunkScratch(void) { return chunk; }

void gfx_pixel(int x, int y, uint8_t c)
{
    if ((unsigned)x >= GFX_W || (unsigned)y >= GFX_H) return;
    uint8_t *p = gfx_fb + y * GFX_FB_STRIDE + (x >> 1);
    *p = (x & 1) ? (uint8_t)((*p & 0x0F) | (c << 4)) : (uint8_t)((*p & 0xF0) | (c & 15));
}
void gfx_clear(uint8_t c) { checkIdle("gfx_clear"); memset(gfx_fb, (c & 15) * 0x11, sizeof gfx_fb); }
void gfx_hline(int x, int y, int w, uint8_t c) { for (int i = 0; i < w; i++) gfx_pixel(x + i, y, c); }
void gfx_vline(int x, int y, int h, uint8_t c) { for (int i = 0; i < h; i++) gfx_pixel(x, y + i, c); }
void gfx_fillRect(int x, int y, int w, int h, uint8_t c)
{
    checkIdle("gfx_fillRect");
    for (int j = 0; j < h; j++) gfx_hline(x, y + j, w, c);
}
void gfx_rect(int x, int y, int w, int h, uint8_t c)
{
    gfx_hline(x, y, w, c); gfx_hline(x, y + h - 1, w, c);
    gfx_vline(x, y, h, c); gfx_vline(x + w - 1, y, h, c);
}
void gfx_text(int x, int y, const char *s, uint8_t c)
{
    checkIdle("gfx_text");
    for (; *s; s++, x += 6) {
        const unsigned ch = (unsigned char)*s;
        if (ch < 32 || ch > 126) continue;
        for (int col = 0; col < 5; col++) {
            const uint8_t bits = chgfx_font5x7[(ch - 32) * 5 + col];
            for (int row = 0; row < 7; row++) if (bits & (1 << row)) gfx_pixel(x + col, y + row, c);
        }
    }
}
int gfx_textWidth(const char *s) { return 6 * (int)strlen(s); }

/* ------------------------------------------------------------------------ */
/* SD                                                                        */
/* ------------------------------------------------------------------------ */
struct SimNode {
    std::string host, name;
    bool dir = false;
    uint32_t size = 0;
    std::vector<std::shared_ptr<SimNode>> kids;
    std::vector<std::pair<uint32_t, uint32_t>> runs;     /* (lba, blocks) */
};

struct Extent { uint32_t lba, blocks, fileBlock; std::shared_ptr<SimNode> node; };
static std::vector<Extent> extents;
static std::shared_ptr<SimNode> root;
static std::string cardRoot;
static uint32_t nextLba = 1000;
SDClass SD;

void simSetCardRoot(const char *d) { cardRoot = d; }

static std::shared_ptr<SimNode> scanHost(const std::string &host, const std::string &name)
{
    auto n = std::make_shared<SimNode>();
    n->host = host; n->name = name;
    struct stat st;
    if (stat(host.c_str(), &st) != 0) return nullptr;
    if (S_ISDIR(st.st_mode)) {
        n->dir = true;
        DIR *d = opendir(host.c_str());
        std::vector<std::string> names;
        while (dirent *e = d ? readdir(d) : nullptr) names.push_back(e->d_name);
        if (d) closedir(d);
        std::sort(names.begin(), names.end(), [](const std::string &a, const std::string &b) {
            return std::hash<std::string>()(a) < std::hash<std::string>()(b);   /* FAT order is not sorted */
        });
        for (auto &nm : names) {
            if (nm == "." || nm == "..") continue;
            if (auto k = scanHost(host + "/" + nm, nm)) n->kids.push_back(k);
        }
    } else {
        n->size = (uint32_t)st.st_size;
        uint32_t blocks = (n->size + 511) / 512, done = 0;
        /* Fragment it: pieces of 7, 40, 3, 1000... blocks, scattered. */
        static const uint32_t pieces[] = { 7, 40, 3, 1000, 64, 5000 };
        for (int i = 0; blocks > done; i++) {
            uint32_t take = blocks <= 16 ? blocks : std::min<uint32_t>(pieces[i % 6], blocks - done);
            n->runs.push_back({ nextLba, take });
            extents.push_back({ nextLba, take, done, n });
            nextLba += take + 777;
            done += take;
        }
    }
    return n;
}

bool SDClass::begin(uint8_t)
{
    checkIdle("SD.begin");
    extents.clear();
    root = scanHost(cardRoot, "/");
    simAdvanceUs(50000);
    return (bool)root;
}

File SDClass::open(const char *path)
{
    checkIdle("SD.open");
    simAdvanceUs(2000);
    std::shared_ptr<SimNode> n = root;
    std::string p = path;
    size_t i = 0;
    while (n && i < p.size()) {
        while (i < p.size() && p[i] == '/') i++;
        if (i >= p.size()) break;
        size_t j = p.find('/', i);
        std::string part = p.substr(i, j == std::string::npos ? std::string::npos : j - i);
        std::shared_ptr<SimNode> found;
        for (auto &k : n->kids) if (k->name == part) found = k;
        n = found;
        i = j == std::string::npos ? p.size() : j;
    }
    return n ? File(n) : File();
}

uint32_t File::size() { return node ? node->size : 0; }
char *File::name() { return node ? (char *)node->name.c_str() : (char *)""; }
bool File::isDirectory() { return node && node->dir; }

int File::read(void *buf, uint16_t n)
{
    if (!node || node->dir) return -1;
    FILE *f = fopen(node->host.c_str(), "rb");
    if (!f) return -1;
    fseek(f, pos, SEEK_SET);
    const int got = (int)fread(buf, 1, n, f);
    fclose(f);
    pos += got;
    simAdvanceUs(1500);
    return got;
}

File File::openNextFile()
{
    if (!node || !node->dir || dirIndex >= node->kids.size()) return File();
    simAdvanceUs(200);
    return File(node->kids[dirIndex++]);
}

uint8_t File::blockRuns(uint32_t *lba, uint32_t *blocks, uint8_t maxRuns)
{
    if (!node || node->dir || node->runs.size() > maxRuns) return 0;
    for (size_t i = 0; i < node->runs.size(); i++) { lba[i] = node->runs[i].first; blocks[i] = node->runs[i].second; }
    return (uint8_t)node->runs.size();
}

uint8_t Sd2Card::readBlocksPipelined(uint32_t block, uint16_t count, uint8_t *buf0, uint8_t *buf1,
                                     BlockFn fn, void *user)
{
    checkIdle("readBlocksPipelined");
    const Extent *ex = nullptr;
    for (auto &e : extents) if (block >= e.lba && block < e.lba + e.blocks) ex = &e;
    if (!ex) { simBug("read of a block that belongs to no file"); return 0; }
    if (block + count > ex->lba + ex->blocks) { simBug("read runs off the end of a fragment"); return 0; }
    FILE *f = fopen(ex->node->host.c_str(), "rb");
    for (uint16_t i = 0; i < count; i++) {
        uint8_t *buf = (i & 1) ? buf1 : buf0;
        memset(buf, 0xA5, 512);                   /* past EOF: someone else's data */
        const long off = (long)(ex->fileBlock + (block - ex->lba) + i) * 512;
        fseek(f, off, SEEK_SET);
        fread(buf, 1, 512, f);
        fn(buf, user);
    }
    fclose(f);
    simAdvanceUs(600 + 170ull * count);
    return 1;
}

/* ------------------------------------------------------------------------ */
/* main                                                                      */
/* ------------------------------------------------------------------------ */
static uint8_t parseButtons(const char *s)
{
    if (!strcmp(s, "-")) return 0;
    static const char *names[] = { "A", "B", "UP", "DOWN", "LEFT", "RIGHT", "START", "SELECT" };
    uint8_t m = 0;
    std::string str = s;
    size_t i = 0;
    while (i <= str.size()) {
        size_t j = str.find('+', i);
        std::string part = str.substr(i, j == std::string::npos ? std::string::npos : j - i);
        for (int b = 0; b < 8; b++) if (part == names[b]) m |= (uint8_t)(1 << b);
        if (j == std::string::npos) break;
        i = j + 1;
    }
    return m;
}

int main(int argc, char **argv)
{
    if (argc < 4) { fprintf(stderr, "usage: appsim CARD_DIR SCRIPT OUT_DIR\n"); return 2; }
    simSetCardRoot(argv[1]);
    outDir = argv[3];
    FILE *sf = fopen(argv[2], "r");
    if (!sf) { perror(argv[2]); return 2; }
    char line[256];
    while (fgets(line, sizeof line, sf)) {
        char cmd[16], a[64] = "", b[64] = "";
        unsigned t = 0;
        if (line[0] == '#' || sscanf(line, "%15s %u %63s %63s", cmd, &t, a, b) < 2) continue;
        if (!strcmp(cmd, "end")) endMs = t;
        else if (!strcmp(cmd, "at")) buttonEvents.push_back({ t, parseButtons(a) });
        else if (!strcmp(cmd, "tap")) { buttonEvents.push_back({ t, parseButtons(a) }); buttonEvents.push_back({ t + 60, 0 }); }
        else if (!strcmp(cmd, "snap")) snaps.push_back({ t, a });
    }
    fclose(sf);
    std::stable_sort(buttonEvents.begin(), buttonEvents.end(),
                     [](const std::pair<uint32_t, uint8_t> &x, const std::pair<uint32_t, uint8_t> &y) { return x.first < y.first; });
    std::stable_sort(snaps.begin(), snaps.end());

    setvbuf(stdout, nullptr, _IOLBF, 4096);
    setup();
    while (millis() < endMs) {
        loop();
        simAdvanceUs(30);              /* button polling and loop overhead */
    }
    printf("[%7.1f ms] end, %d bug(s)\n", nowUs / 1000.0, bugs);
    return bugs ? 1 : 0;
}
