#pragma once
#include "CHGameSound.h"
#include "utility/MODPlayer.h"

// Owns tracker state; sample bytes stay in caller-owned flash/RAM.
// Declare audio before this object so it outlives the player.
class CHGameMOD {
public:
    explicit CHGameMOD(CHGameSound &audio) : audio_(audio) {}
    ~CHGameMOD() { stop(); }
    CHGameMOD(const CHGameMOD &)=delete;
    CHGameMOD &operator=(const CHGameMOD &)=delete;
    bool play(const uint8_t *mod,size_t bytes,bool loop=false);
    template<size_t N> bool play(const uint8_t (&mod)[N]) { return play(mod,N,false); }
    void stop();
    bool playing() const;
    chgame::MODError error() const;
    void gain(uint16_t q8); // 256=unity, up to 1024; higher values may clip.
private:
    CHGameSound &audio_;
    chgame::detail::MODPlayer player_;
    static int16_t render(void *context);
};
