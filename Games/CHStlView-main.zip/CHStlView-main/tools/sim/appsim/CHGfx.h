/* Host stand-in for CHGfx: the same 4 bpp framebuffer and the calls
 * CHStlView makes. "Flushing" copies the framebuffer to a simulated panel
 * (with CHGfx's 12 bpp rounding of x to multiples of 8) and charges the
 * virtual clock what the real transfer costs. Drawing into the framebuffer,
 * or touching the SD card, while an async flush is in flight is reported as
 * a bug: on the device that tears the image or corrupts the shared bus. */
#pragma once
#include <Arduino.h>

#define GFX_W           128
#define GFX_H           128
#define GFX_FB_STRIDE   (GFX_W / 2)
#define GFX_FB_BYTES    (GFX_FB_STRIDE * GFX_H)
#define GFX_CHUNK_ROWS  2
#define GFX_CHUNK_BYTES (GFX_W * GFX_CHUNK_ROWS * 2)

enum : uint8_t { GFX_16BPP = 0, GFX_12BPP = 1, GFX_18BPP = 2 };
enum : uint8_t { GFX_DIV2 = 2, GFX_DIV4 = 4, GFX_DIV8 = 8, GFX_DIV16 = 16 };

extern uint8_t  gfx_fb[GFX_FB_BYTES];
extern uint16_t gfx_pal[16];

void gfx_begin(uint8_t spiDiv, uint8_t colorMode);
void gfx_setPalette(const uint16_t *rgb565, uint8_t count);
static inline uint16_t gfx_rgb(uint8_t r, uint8_t g, uint8_t b) {
    return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}

void gfx_flush(void);
void gfx_flushAsync(void);
bool gfx_busy(void);
void gfx_wait(void);
void gfx_flushRect(int x, int y, int w, int h);
void gfx_flushRectAsync(int x, int y, int w, int h);
uint8_t *gfx_chunkScratch(void);

void gfx_clear(uint8_t c);
void gfx_pixel(int x, int y, uint8_t c);
void gfx_hline(int x, int y, int w, uint8_t c);
void gfx_vline(int x, int y, int h, uint8_t c);
void gfx_fillRect(int x, int y, int w, int h, uint8_t c);
void gfx_rect(int x, int y, int w, int h, uint8_t c);
void gfx_text(int x, int y, const char *s, uint8_t c);
int  gfx_textWidth(const char *s);

class CHGfx {
public:
    void begin(uint8_t spiDiv = GFX_DIV2, uint8_t colorMode = GFX_16BPP) { gfx_begin(spiDiv, colorMode); }
    void drawPixel(int x, int y, uint8_t c) { gfx_pixel(x, y, c); }
};
extern CHGfx Gfx;

/* Simulator side. */
extern uint8_t sim_panel[GFX_FB_BYTES];   /* what the glass shows, 4 bpp */
void simBug(const char *what);
