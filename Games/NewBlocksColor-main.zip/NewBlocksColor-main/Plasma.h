/*
 * Plasma.h - the background, and the single pass that composites the
 *            whole game on top of it.
 *
 * WHY THERE IS NO gfx_flush() ANYWHERE IN THIS GAME
 * -------------------------------------------------
 * CHGfx gives you two rendering modes and they are usually a choice:
 * a 4 bpp framebuffer for sprites and geometry, or gfx_stream() for
 * procedural effects that touch every pixel and want all 65,536
 * colours. Neither one alone can draw this game.
 *
 * So we use both at once, the way the Demoscene copper part does. Every
 * game element is drawn into the 4 bpp framebuffer with the ordinary
 * library calls, using palette index 0 to mean "nothing here". Then
 * gfx_stream() walks the frame and, per pixel, either emits the palette
 * colour for a non-zero nibble or computes a plasma pixel at full
 * RGB565 depth. Geometry engine and procedural renderer, composited in
 * one pass, at wire speed. The framebuffer never reaches the panel; it
 * is a stencil.
 *
 * THE PLASMA ITSELF
 * -----------------
 * Four sine terms averaged into one 0..255 index, then a colour ramp:
 *
 *   - one horizontal scroll   (per-x table, hoisted out of the row loop)
 *   - one vertical scroll     (per-row scalar, one lookup per row)
 *   - two concentric ripples about moving centres
 *
 * The ripples are what stop it looking like wallpaper. Distance is
 * squared, not rooted: (x-cx)^2 + (y-cy)^2 fed into the sine table gives
 * rings that bunch up toward the edges, which is prettier than true
 * circles anyway and costs one 16-bit add per pixel because the x half
 * is a table built once per frame. Adding a phase to the ring index
 * makes the rings travel outward.
 *
 * All four terms are multiplied by one spatial scale factor when the
 * per-frame tables are built, which is what lets the whole field zoom in
 * and back out as one coherent thing when something happens in the game.
 * See plasmaPulse() below - that turned out to be the difference between
 * the background reacting and the background glitching.
 *
 * WHY NOTHING HERE IS TRUNCATED TO A WHOLE UNIT
 * --------------------------------------------
 * The field was jittery for a while, and the cause was not the frame
 * rate. Slowing it down had been done by giving the phases fractional
 * rates - 0.44 wheel units a frame and so on - but every use of a phase
 * then threw the fraction away: the ring phase went into the sine index
 * as a whole unit, the scroll phase the same, and the ripple centres
 * were rounded to whole pixels. So at 0.44 units a frame the picture
 * moved by one unit on some frames and by nothing on others, in the
 * pattern 0,1,0,1,0,0,1: an irregular ~35 Hz stutter laid over a slow
 * drift, which the eye reads as exactly the shimmer it was.
 *
 * Every consumer now keeps the fraction, and none of it costs anything
 * per pixel:
 *
 *   - The ring phases are folded into the per-row squared-distance
 *     constants BEFORE the shift that turns distance into a sine index,
 *     at the resolution of the shift (1/32 and 1/64 of a unit). The
 *     ring boundaries therefore move in space by fractions of an index
 *     step, and the inner loop loses two adds rather than gaining any.
 *   - The scroll terms are a table and a per-row scalar, so those go
 *     through sinQ(): the sine table linearly interpolated at an 8.8
 *     angle. 128 + 128 interpolations a frame.
 *   - The ripple centres are held in 1/8 px, from the same interpolated
 *     sine, and the squared distances are computed at that resolution
 *     and scaled back. The tables stay 16-bit; only the arithmetic that
 *     builds them widened.
 *
 * And the phases advance by measured elapsed time rather than by frame,
 * so a frame that runs long because a row just exploded into two hundred
 * sparks moves the field proportionally further instead of leaving it a
 * step behind. The rates are still written per nominal 80 fps frame -
 * that is what they were tuned at - and the game logic is deliberately
 * NOT on the same clock; see loop() in the sketch for why.
 *
 * CONTRAST, AND THE TWO BRIGHTNESSES
 * ----------------------------------
 * The panel is ~200 nits with mediocre contrast, so a bright background
 * behind the playfield would swallow the blocks. The plasma therefore
 * runs at full brightness outside the well and an eighth inside it: one
 * continuous, coherent field that drops three stops exactly where the
 * game lives. Two stops was tried first and looked better in isolation;
 * with the well full of saturated blocks it was still competing with
 * them, and three is where the interior stops reading as a picture and
 * starts reading as a black background with something alive behind it.
 *
 * Dimming is a shift and a mask on the RGB565 value, not a second ramp
 * table. A second table would make it free per pixel but costs 512 bytes
 * of a 20 KB part, and after the framebuffer, the driver LUT and the
 * particle pool there is not 512 bytes going spare. The shift amount and
 * mask are per-segment variables the row loop swaps at two x positions,
 * so there is still no branch in the inner loop - just two ALU ops that
 * are a no-op on the border rows. Measured cost is under 3% of a frame.
 *
 * BUDGET
 * ------
 * 32 CPU cycles per pixel at 16 bpp is the wire speed ceiling. Counted
 * out of the -O2 disassembly, the both-pixels-plasma path through this
 * loop is 68 instructions per two pixels - 34 per pixel including the
 * loop overhead and the stencil test, or very close to one instruction
 * per available cycle.
 *
 * So the plasma is a little over budget and pixels covered by the
 * stencil - blocks, glyphs, frame, particles - are well under it, since
 * they are a load, a test and a palette lookup. In practice the frame
 * lands slightly under the 90 fps wire ceiling rather than at it, which
 * is the documented behaviour: go over budget and the frame rate
 * degrades in proportion, nothing breaks.
 *
 * Two things were worth the effort to get it this close. It lives in
 * SRAM, because flash is 3 wait states on this part and measures 2.2x
 * slower on exactly this shape of loop. And the squared distances are
 * kept in 32-bit unsigned rather than uint16_t: written the narrow way
 * the compiler emitted a slli/srli pair per ripple per pixel to redo a
 * truncation that can never trigger, which was 8 of the 76 instructions
 * this loop used to take.
 */
#pragma once

#include <CHGfx.h>
#include "Palette.h"

/* Hot loops into SRAM. See the note above. */
#define FX __attribute__((section(".srodata.ramfunc"), noinline))

/* ------------------------------------------------------------------ */
/* Tables                                                              */
/* ------------------------------------------------------------------ */
static uint8_t  sinTab[256];        /* full circle, 0..255 unsigned    */
static uint16_t lutHi[256];         /* the colour ramp, full brightness */
static uint8_t  colA[GFX_W];        /* horizontal scroll, per frame    */
static uint16_t sqx1[GFX_W];        /* (x - cx1)^2, per frame          */
static uint16_t sqx2[GFX_W];        /* (x - cx2)^2, per frame          */

/* Sine of an 8.8 angle, linearly interpolated between table entries.
 * Returns 0..255 in 8.8, so the caller decides what to do with the
 * fraction. Adjacent entries differ by at most 4, so the interpolation
 * is one small multiply and never leaves 0..65535. */
static inline unsigned sinQ(uint16_t a)
{
    const unsigned i  = a >> 8;
    const int      s0 = sinTab[(uint8_t)i];
    const int      s1 = sinTab[(uint8_t)(i + 1)];
    return (unsigned)((s0 << 8) + (s1 - s0) * (int)(a & 0xFFu));
}

/* The ripple centres and the distances measured from them carry this
 * many fractional bits: 1/8 px. Enough that the centre's drift never
 * shows as a whole-pixel hop of the entire ring pattern. */
#define SUB 3

/* 64 + amp * sin(angle), in 1/8 px. sinQ() - 32768 is the sine in Q15. */
static inline int lissajous(uint16_t angle, int amp)
{
    return (64 << SUB) + ((((int)sinQ(angle) - 32768) * amp) >> (15 - SUB));
}

/* The frame the RATE_* numbers below were tuned at. Phases advance by
 * measured time scaled against this, so the tuning holds at any actual
 * frame rate. A host port can supply its own clock. */
#define NOMINAL_FRAME_US 12500
#ifndef PLASMA_NOW_US
#define PLASMA_NOW_US() micros()
#endif

/* One eighth brightness, applied to a packed RGB565 value. The mask
 * drops the three bits of each component that the shift would otherwise
 * have dragged down into the component below it. */
#define DIM_SHIFT 3
#define DIM_MASK  0x18E3

/* The dimmed rectangle, in screen pixels. x bounds are forced even so
 * the row loop can switch brightness on a byte boundary, never mid-pair. */
static int pfX0 = GFX_W, pfX1 = GFX_W, pfY0 = GFX_H, pfY1 = GFX_H;

/* Ring 2 wavelength. Fixed now that the zoom below handles scale, which
 * lets the compiler use an immediate shift in the inner loop. */
#define RING2_SHIFT 6

/*
 * HUE_SPAN is how much of the colour wheel one wrap of the ramp covers,
 * in wheel units. It is the dial between "the background is a rainbow"
 * and "the background is the colour of the piece you are holding".
 *
 * At 512 the ramp crosses the wheel twice and the plasma is every colour
 * at once - which looks great, but means shifting its base hue changes
 * nothing you can see, so it cannot track anything. At 150 the ramp is a
 * little over half the wheel centred on one hue: still plenty of colour
 * variation, but with an unmistakable overall cast that can follow the
 * falling piece.
 */
#define HUE_SPAN 150

/*
 * HOW FAST THE FIELD MOVES
 * ------------------------
 * All in 8.8 fixed point, where 256 is one wheel unit per nominal frame
 * (see NOMINAL_FRAME_US). These were whole numbers to begin with - 1, 2,
 * 1, 2 - which at ~80 fps is a lot of travel, and the background read as
 * agitated rather than as something drifting behind the game. The
 * fractions are honoured all the way down; see the note at the top.
 *
 * Everything is about 45% of what it was. Turn one number to retune one
 * axis; scale all four to change the overall pace.
 */
#define RATE_T1    112          /* horizontal scroll, 0.44 units/frame */
#define RATE_T2    224          /* vertical scroll,   0.88            */
#define RATE_PH1   112          /* ring 1 travel,     0.44, backwards */
#define RING_REST  224          /* ring 2 travel,     0.88            */

/* The Lissajous angles, also 8.8 per nominal frame. Four incommensurate
 * rates, so the two ripple centres never settle into a repeating figure
 * the eye can lock on to. */
#define RATE_A1     76
#define RATE_A2     44
#define RATE_A3    108
#define RATE_A4     60

static struct {
    uint32_t lastUs;            /* when the phases were last advanced     */
    uint16_t a1, a2, a3, a4;    /* 8.8 Lissajous angles for the centres   */
    uint16_t t1a, t2a;          /* 8.8 linear scroll phases               */
    uint16_t ph1a, ph2a;        /* 8.8 ring phases - advancing = travel   */
    uint8_t  hue;               /* ramp centre, chases hueTarget          */
    uint8_t  hueTarget;         /* the active piece's hue                 */
    uint8_t  zoomT, zoomLen;    /* zoom envelope position and length      */
    uint8_t  zoomDepth;         /* zoom envelope peak                     */
    uint16_t zoom;              /* 8.8 spatial scale, 256 = neutral       */
    int16_t  cx1, cy1, cx2, cy2;/* ripple centres, 1/8 px                 */
} P;

/* ------------------------------------------------------------------ */
/* Setup                                                               */
/* ------------------------------------------------------------------ */
/*
 * A quarter sine table mirrored into a full circle. sinf() would pull in
 * libm - 8.5 KB of a 50 KB flash budget - for a function we only need to
 * 8 bits of precision, once, at boot.
 */
static const uint8_t sinQuarter[64] = {   /* sin(i*pi/128) * 127 */
      0,   3,   6,   9,  12,  16,  19,  22,  25,  28,  31,  34,  37,  40,
     43,  46,  49,  51,  54,  57,  60,  63,  65,  68,  71,  73,  76,  78,
     81,  83,  85,  88,  90,  92,  94,  96,  98, 100, 102, 104, 106, 107,
    109, 111, 112, 113, 115, 116, 117, 118, 120, 121, 122, 122, 123, 124,
    125, 125, 126, 126, 126, 127, 127, 127
};

static void plasmaInit(void)
{
    for (int i = 0; i < 256; i++) {
        int q = i & 63;
        int v = (i & 64) ? sinQuarter[63 - q] : sinQuarter[q];
        if (i & 128) v = -v;
        sinTab[i] = (uint8_t)(v + 128);
    }
    P.a1 = 0; P.a2 = 36000; P.a3 = 18464; P.a4 = 16000;
    P.zoom = 256;
    P.lastUs = PLASMA_NOW_US();
}

static void plasmaNoPlayfield(void)
{
    pfX0 = pfX1 = GFX_W;
    pfY0 = pfY1 = GFX_H;
}

/* Round the playfield rect outward to even x so the ramp swap in the
 * row loop always lands between pixel pairs. An empty rect means no
 * dimming at all - it must not become a zero-width one, because the
 * row loop would take the dark swap and never reach the bright one. */
static void plasmaSetPlayfield(int x0, int y0, int x1, int y1)
{
    if (x1 <= x0 || y1 <= y0) { plasmaNoPlayfield(); return; }
    pfX0 = x0 & ~1;
    pfX1 = (x1 + 1) & ~1;
    pfY0 = y0;
    pfY1 = y1;
}

/*
 * THE ZOOM, WHICH REPLACED A JOLT
 * -------------------------------
 * The first version of this answered gameplay by snapping: the ring
 * centre teleported to the impact, the ring wavelength jumped a whole
 * shift, and the ramp hue jumped 48 units in one frame. All three read
 * as a glitch rather than as a reaction, because one frame is not long
 * enough for the eye to see a change as motion - it only sees that the
 * picture is suddenly different.
 *
 * So nothing jumps any more. A pulse eases a spatial scale factor in and
 * back out along a half sine, which makes the whole field breathe toward
 * the viewer and settle. The scale is applied when the per-frame tables
 * are built, so all four terms - both scrolls and both ripples - zoom
 * together and stay one coherent field. It costs one multiply per table
 * entry per frame, three per row, and nothing at all per pixel.
 *
 * `depth` is how far in, out of 256. 140 roughly doubles the size of
 * everything at the peak. `frames` is the whole round trip.
 */
static bool plasmaPulse(uint8_t depth, uint8_t frames)
{
    if (!depth || !frames) return false;

    /* Do not let a small event cut short a bigger one already running. */
    if (P.zoomT < P.zoomLen && P.zoomDepth > depth) return false;

    /*
     * START THE NEW ARC WHERE THE OLD ONE HAD GOT TO.
     *
     * Restarting the envelope at zero means its value jumps back to the
     * top of a fresh curve, and if the scale was deep at the time that is
     * a step - measured at 57 units of target in one frame when a second
     * row cleared 26 frames into the first one, which is entirely
     * reachable by hard dropping twice in a row.
     *
     * So solve the envelope backwards instead: find the phase whose value
     * already equals the current scale, and begin there. The curve is a
     * rising quarter sine over its first half, so a 64 step walk inverts
     * it, and this runs a few times a second at most.
     */
    unsigned e0 = 0;
    if (P.zoom < 256) {
        const unsigned want = ((256u - (unsigned)P.zoom) << 7) / depth;
        e0 = want > 127u ? 127u : want;
    }
    uint8_t idx0 = 0;
    while (idx0 < 64 && (unsigned)(sinTab[idx0 + 1] - 128) < e0) idx0++;

    P.zoomDepth = depth;
    P.zoomLen   = frames;
    P.zoomT     = (uint8_t)(((unsigned)idx0 * frames) / 128u);
    return true;
}

/* The plasma tints itself towards whichever piece is falling. Set the
 * wheel angle here; plasmaStep eases the ramp centre towards it, so a
 * new piece bleeds the background into its colour over about a second
 * instead of switching it. */
static void plasmaSetHue(uint8_t angle) { P.hueTarget = angle; }

/* ------------------------------------------------------------------ */
/* Per-frame table rebuild                                             */
/* ------------------------------------------------------------------ */
static void plasmaStep(uint8_t baseHue)
{
    /*
     * How much of a nominal frame has actually passed, in 8.8. Measured
     * between calls, so it is the interval at which the panel will see
     * consecutive frames - near enough, since the stream that follows is
     * a fixed cost. Clamped so the first frame, a stall in a tone timer
     * or a debugger halt cannot throw the field across the screen.
     */
    const uint32_t now = PLASMA_NOW_US();
    uint32_t dt = now - P.lastUs;
    P.lastUs = now;
    if (dt < 6000u)  dt = 6000u;
    if (dt > 25000u) dt = 25000u;
    const unsigned dq = (unsigned)((dt * 256u) / NOMINAL_FRAME_US);
#define ADV(rate) ((uint16_t)(((unsigned)(rate) * dq) >> 8))

    P.a1 = (uint16_t)(P.a1 + ADV(RATE_A1));
    P.a2 = (uint16_t)(P.a2 + ADV(RATE_A2));
    P.a3 = (uint16_t)(P.a3 + ADV(RATE_A3));
    P.a4 = (uint16_t)(P.a4 + ADV(RATE_A4));

    P.t1a  = (uint16_t)(P.t1a  + ADV(RATE_T1));
    P.t2a  = (uint16_t)(P.t2a  + ADV(RATE_T2));
    P.ph1a = (uint16_t)(P.ph1a - ADV(RATE_PH1));

    P.ph2a = (uint16_t)(P.ph2a + ADV(RING_REST));
#undef ADV

    /*
     * THE EVENT ENVELOPE.
     *
     * `env` is a half sine, 0 -> 127 -> 0 across the life of the event,
     * and the zoom scale is the only thing derived from it. A half sine
     * has zero slope at both ends, so the scale never has a frame where
     * it changes discontinuously.
     *
     * A cleared row used to also drag the second ripple centre to the
     * row and speed its rings up off the same envelope - a surge. It was
     * eased every way it could be, and on the panel it still read as
     * the background being disturbed rather than answering: rings
     * sliding sideways while the whole field also zoomed was two motions
     * where the eye wanted one. The zoom alone carries the event, so the
     * surge is gone, together with the centre pull, the speed ramp and
     * the second easing they needed. The ripple centres now only ever
     * follow their Lissajous paths.
     */
    unsigned env = 0;                               /* 0 .. 127 .. 0 */
    if (P.zoomT < P.zoomLen) {
        P.zoomT++;
        const uint8_t idx = (uint8_t)(((unsigned)P.zoomT * 128u) / P.zoomLen);
        env = (unsigned)sinTab[idx] - 128u;
    }

    /* Chase the active piece hue the short way round the wheel. Two units
     * a frame crosses half the wheel in about a second and a half: fast
     * enough to feel connected to the piece, slow enough that it reads as
     * the background bleeding rather than as a cut. */
    {
        const int d = (int8_t)(P.hueTarget - P.hue);
        if      (d >  1) P.hue = (uint8_t)(P.hue + 2);
        else if (d < -1) P.hue = (uint8_t)(P.hue - 2);
        else             P.hue = P.hueTarget;
    }

    /*
     * The zoom scale off the envelope, followed rather than taken: a
     * second event arriving mid-arc restarts the envelope, and without
     * this the scale could jump from wherever it had got to onto a fresh
     * curve. Costs two or three frames of lag on a 44 frame arc; in
     * exchange no sequence of events can produce a step.
     */
    {
        const uint16_t target = (uint16_t)(256u - ((P.zoomDepth * env) >> 7));
        const int d = (int)target - (int)P.zoom;
        P.zoom = (d > 3 || d < -3) ? (uint16_t)((int)P.zoom + d / 3) : target;
    }

    P.cx1 = (int16_t)lissajous(P.a1, 74);
    P.cy1 = (int16_t)lissajous(P.a2, 74);
    P.cx2 = (int16_t)lissajous(P.a3, 92);
    P.cy2 = (int16_t)lissajous(P.a4, 92);

    /* Squared distances at 1/8 px resolution, scaled by the zoom and
     * brought back to whole px^2 so the tables stay 16-bit. The widest
     * term is (156 px * 8)^2 * 256, well inside 32 bits. The scroll goes
     * through the interpolated sine at its full 8.8 angle. */
    const uint16_t z = P.zoom;
    for (int x = 0; x < GFX_W; x++) {
        const int d1 = (x << SUB) - P.cx1;
        const int d2 = (x << SUB) - P.cx2;
        sqx1[x] = (uint16_t)(((uint32_t)(d1 * d1) * z) >> (8 + 2 * SUB));
        sqx2[x] = (uint16_t)(((uint32_t)(d2 * d2) * z) >> (8 + 2 * SUB));
        colA[x] = (uint8_t)(sinQ((uint16_t)(x * 2 * z + P.t1a)) >> 8);
    }

    /*
     * The ramp. Four bright bands per wrap, squared so the dark parts
     * are genuinely black and the bright parts are a narrow neon vein -
     * which is exactly the shape a low-contrast panel renders best. Hue
     * runs twice around the wheel across the same range, so the veins
     * are never all the same colour at once.
     */
    const uint8_t hue0 = (uint8_t)(P.hue - HUE_SPAN / 2);
    for (int i = 0; i < 256; i++) {
        uint8_t  band = sinTab[(uint8_t)(i * 4)];
        uint8_t  v    = (uint8_t)((band * band) >> 8);
        lutHi[i] = hsv565((uint8_t)(hue0 + ((i * HUE_SPAN) >> 8)), 255, v);
    }

    paletteUpdate(baseHue, P.hue, sinTab[(uint8_t)(P.t2a >> 7)]);
}

/* ------------------------------------------------------------------ */
/* The composite pass                                                  */
/* ------------------------------------------------------------------ */
FX static void bgRows(uint8_t *dst, int y0, int rows, void *user)
{
    (void)user;
    uint16_t       *d   = (uint16_t *)dst;
    const uint8_t  *sn  = sinTab;
    const uint16_t *ink = pal;

    const int      cy1 = P.cy1, cy2 = P.cy2;
    const uint16_t t2  = P.t2a;
    const uint16_t z   = P.zoom;

    /* The ring phases, in the units of the squared-distance sums they
     * are about to be added to - one sine index is 32 px^2 for ring 1
     * and 64 for ring 2, so the phase keeps 5 and 6 fractional bits.
     * Adding here and shifting afterwards is what lets the rings move
     * by less than an index step per frame. */
    const unsigned ph1 = P.ph1a >> (8 - 5);
    const unsigned ph2 = P.ph2a >> (8 - RING2_SHIFT);

    for (int r = 0; r < rows; r++) {
        const int y = y0 + r;

        /*
         * These stay 32-bit unsigned on purpose. Written as uint16_t the
         * compiler has to narrow every intermediate, and the sum below
         * picked up a slli/srli pair per ripple per pixel - four wasted
         * instructions out of about twenty-seven on the hot path. The
         * per-pixel sums cannot overflow 16 bits meaningfully anyway,
         * and the uint8_t cast on the index below is the intended wrap.
         */
        /* Three multiplies a row apply the zoom to the vertical half of
         * both ripples and to the vertical scroll. The horizontal halves
         * were already scaled when the tables were built. */
        int dy = (y << SUB) - cy1;
        const unsigned sqy1 = (((unsigned)(dy * dy) * z) >> (8 + 2 * SUB)) + ph1;
        dy     = (y << SUB) - cy2;
        const unsigned sqy2 = (((unsigned)(dy * dy) * z) >> (8 + 2 * SUB)) + ph2;
        const unsigned rowA = sinQ((uint16_t)(y * 3 * z - t2)) >> 8;

        const uint8_t *frow = gfx_fb + y * GFX_FB_STRIDE;

        /* Ramp swap points for this row. Parked off-screen when the row
         * misses the playfield, so the compare is never taken and the
         * border rows pay nothing for it. */
        const bool inPf     = (y >= pfY0 && y < pfY1);
        const int  segDark   = inPf ? pfX0 : GFX_W;
        const int  segBright = inPf ? pfX1 : GFX_W;
        unsigned   dim  = 0;
        unsigned   keep = 0xFFFF;

        for (int x = 0; x < GFX_W; x += 2) {
            if      (x == segDark)   { dim = DIM_SHIFT; keep = DIM_MASK; }
            else if (x == segBright) { dim = 0;         keep = 0xFFFF;   }

            const uint8_t pair = frow[x >> 1];
            const uint8_t lo   = (uint8_t)(pair & 0x0F);
            const uint8_t hi   = (uint8_t)(pair >> 4);

            if (lo) {
                d[x] = ink[lo];
            } else {
                unsigned a = sqx1[x] + sqy1;
                unsigned b = sqx2[x] + sqy2;
                unsigned v = colA[x] + rowA
                           + sn[(uint8_t)(a >> 5)]
                           + sn[(uint8_t)(b >> RING2_SHIFT)];
                d[x] = (uint16_t)((lutHi[v >> 2] >> dim) & keep);
            }

            if (hi) {
                d[x + 1] = ink[hi];
            } else {
                unsigned a = sqx1[x + 1] + sqy1;
                unsigned b = sqx2[x + 1] + sqy2;
                unsigned v = colA[x + 1] + rowA
                           + sn[(uint8_t)(a >> 5)]
                           + sn[(uint8_t)(b >> RING2_SHIFT)];
                d[x + 1] = (uint16_t)((lutHi[v >> 2] >> dim) & keep);
            }
        }
        d += GFX_W;
    }
}

static inline void plasmaRender(void) { gfx_stream(bgRows, nullptr); }
