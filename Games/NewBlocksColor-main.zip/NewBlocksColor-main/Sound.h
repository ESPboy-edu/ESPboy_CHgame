/*
 * Sound.h - music and sound effects over the CHGameSound library.
 *
 * WHY NOT tone()
 * --------------
 * The CHGame board package's default Peripherals setting ("Game") builds
 * with TIM_MODULE_ONLY, and in that configuration the core's tone()
 * ignores its arguments. Every beep this game ever made
 * was silent. CHGameSound drives the piezo on PB10 through TIM1 directly
 * and does not need the core's timer classes at all.
 *
 * THE OUTPUT IS ONE SQUARE WAVE
 * ----------------------------
 * The board has a single piezo on a single GPIO. Output::Lead is the same
 * hardware tone path as the library's BasicTone and Playtune examples: a
 * TIM1 PWM at 50% duty, retuned from a 1 kHz TIM2 interrupt whenever the
 * score or an effect changes note. No DMA, no synthesis, no per-sample CPU
 * work - the audio cost per frame is nothing, which matters in a frame
 * that already spends itself in the compositor.
 *
 * That means "effects over the music" is done by priority, not mixing: an
 * effect takes the tone for exactly as long as it lasts, and the music
 * keeps counting underneath and comes back on its next note boundary the
 * moment the effect ends. Every effect here is short for that reason - a
 * hard drop is 183 ms, a row clear 462 ms - and the soft drop tick, which
 * fires every row DOWN is held for, is ten.
 *
 * PRIORITY
 * --------
 * The library replaces whatever effect is playing when a new one starts,
 * so the game decides. Each sound has a rank; a new sound plays if nothing
 * is playing or if it ranks at least as high as what is. So a hard drop's
 * slam is not chopped by the settle blip of the piece it just dropped, a
 * row clear does override the landing thud that preceded it, and the
 * fall tick only ever fills silence.
 *
 * MUSIC
 * -----
 * Scott Joplin's The Entertainer (1902, public domain), the "Arduino Club
 * Mix - more swing" arrangement in music/, converted by the library's
 * midi2score.py (copied to tools/) to a single-channel Playtune score
 * (Music.h). It is the title screen's: it starts 300 ms after power-on,
 * which is when the LCD has finished its own boot and the title appears,
 * loops while the title sits there, and stops the moment the player
 * presses a button to start. Play itself has only the effects.
 */
#pragma once

#include "src/CHGameSound/CHGameSound.h"
#include "Common.h"
#include "Music.h"
#include "MusicOver.h"
#include "Sfx.h"

static CHGameSound audio;

/* When the music starts, in milliseconds after reset. The ST7735 takes
 * about this long to come out of its own reset and light up. */
#define MUSIC_START_MS 300

/* Set to 0 to drop the fall tick and leave the rhythm to the music. */
#ifndef SFX_FALL_TICK
#define SFX_FALL_TICK 1
#endif

/* Ranks. Higher wins; equal replaces. */
enum : uint8_t {
    SP_CLICK  = 0,      /* fall tick                                */
    SP_BLIP   = 1,      /* sideways move                            */
    SP_PIECE  = 2,      /* a piece coming to rest                   */
    SP_DROP   = 3,      /* hard drop, stack shattering              */
    SP_PHRASE = 4       /* row clear, title, go, game over, banner  */
};

static uint8_t sfxRank;
static bool    musicStarted;        /* set once; the music never comes back */
static bool    soundMuted;

/*
 * One RAM step buffer for the sounds that are built at play time: the
 * settle tone is computed from the row, the shatter crackle is transposed
 * by it, and the hard drop is the whoosh with that row's landing tone
 * appended. The library reads steps from wherever they are for as long as
 * they play, so the buffer is only ever rewritten after stopEffect(),
 * never underneath a running one. Sized for the whoosh plus one tone.
 */
#define SFX_BUF_STEPS (sizeof SFX_DROP / sizeof SFX_DROP[0] + 1)
static chgame::Step sfxBuf[SFX_BUF_STEPS];

static void soundBegin(void)
{
    /* Lead: the plain hardware tone. Claims PB10/TIM1 and the TIM2 update
     * interrupt; CHGfx uses SPI1 and DMA channel 3, so nothing collides.
     * If this fails (another owner of TIM2, wrong clock) every call below
     * is a harmless no-op and the game is simply silent. */
    audio.begin(chgame::Output::Lead);
}

static void musicStart(void)
{
    musicStarted = true;
    audio.playScore(music);
}

/* Ends the music for good: the title is the only place it plays. */
static void musicStop(void)
{
    musicStarted = true;
    audio.stopScore();
}

/* The game over sting: a 2.1 s single-channel Playtune score with no loop
 * command, so it plays through once and stops itself. Started when the
 * banner's word appears; effects still duck it exactly like the title
 * music, and it simply finishes on its own if play resumes underneath it. */
static void musicOverStart(void)
{
    audio.playScore(musicOver);
}

/*
 * SELECT toggles the whole device, from anywhere: the title, play, the
 * pause banner, the game over screen. It is a property of the audio
 * hardware and not of any game state, which is why it lives here and why
 * nothing above it needs to know about it.
 *
 * Mute rather than stop. The score and any running effect keep counting
 * underneath - the engine simply stops handing a frequency to the tone
 * unit - so unmuting halfway through the title returns you to where The
 * Entertainer would have been, not to the top of the bar.
 */
static bool soundToggleMute(void)
{
    soundMuted = !soundMuted;
    audio.mute(soundMuted);
    return soundMuted;
}

/* Once per frame. */
static void soundUpdate(void)
{
    if (!musicStarted && millis() >= MUSIC_START_MS) musicStart();
}

/* Can a sound of this rank start now? */
static inline bool sfxFree(uint8_t rank)
{
    return rank >= sfxRank || !audio.effectPlaying();
}

/* Is a sound of at least this rank still going? */
static inline bool sfxBusy(uint8_t rank)
{
    return sfxRank >= rank && audio.effectPlaying();
}

static void sfxStart(const chgame::Step *steps, size_t n, uint8_t rank)
{
    if (!sfxFree(rank)) return;
    sfxRank = rank;
    audio.effect(steps, n);
}

template <size_t N>
static inline void sfxStart(const chgame::Step (&steps)[N], uint8_t rank)
{
    sfxStart(steps, N, rank);
}

/* The same, with every pitch multiplied by scale/256 on the way through
 * the RAM buffer. */
template <size_t N>
static void sfxStartScaled(const chgame::Step (&steps)[N], uint16_t scale, uint8_t rank)
{
    if (!sfxFree(rank)) return;
    const size_t n = N < SFX_BUF_STEPS ? N : SFX_BUF_STEPS;
    audio.stopEffect();                 /* the buffer may be what is playing */
    for (size_t i = 0; i < n; i++) {
        sfxBuf[i]    = steps[i];
        sfxBuf[i].hz = (uint16_t)(((uint32_t)steps[i].hz * scale) >> 8);
    }
    sfxRank = rank;
    audio.effect(sfxBuf, n);
}

static inline void sfxSetTone(chgame::Step *s, uint16_t hz, uint16_t ms)
{
    s->hz         = hz;
    s->endHz      = 0;
    s->durationMs = ms;
    s->sound      = chgame::Preset::Beep;
    s->volume     = 255;
}

/* A single plain tone through the RAM buffer. */
static void sfxTone(uint16_t hz, uint16_t ms, uint8_t rank)
{
    if (!sfxFree(rank)) return;
    audio.stopEffect();
    sfxSetTone(&sfxBuf[0], hz, ms);
    sfxRank = rank;
    audio.effect(sfxBuf, 1);
}

/*
 * The landing tone: the original's 587 Hz plus 30 Hz for every row of
 * height, so the pitch climbs as the stack does - 587 Hz resting on the
 * floor row, 1007 Hz stopped at the very top. The original held it three
 * frames; 45 ms is the same length.
 */
#define SETTLE_MS 45
static inline uint16_t settleHz(int row)
{
    return (uint16_t)(587 + (BOARD_H - 1 - row) * 30);
}

/* ------------------------------------------------------------------ */
/* The events                                                          */
/* ------------------------------------------------------------------ */
static inline void sfxMove(void)           { sfxStart(SFX_MOVE, SP_BLIP); }

/*
 * The same two-note click an octave down - 3136/2350 Hz becomes
 * 1568/1175 - for the move that costs a point.
 *
 * The same click rather than a new sound, because it IS the same move:
 * one cell, one press, the piece is somewhere else. Down an octave is
 * the cheapest way to say "and that one was backwards" without teaching
 * the player a second noise, and a fifth was tried first and is not far
 * enough to hear as different when the two are pressed a moment apart.
 * It goes through the transposing path the shatter crackle already uses,
 * so it costs no flash of its own.
 */
static inline void sfxMoveUp(void)         { sfxStartScaled(SFX_MOVE, 128, SP_BLIP); }
static inline void sfxTick(void)           { if (SFX_FALL_TICK) sfxStart(SFX_TICK, SP_CLICK); }
static inline void sfxLand(void)           { sfxStart(SFX_LAND, SP_PIECE); }
static inline void sfxSettle(int row)      { sfxTone(settleHz(row), SETTLE_MS, SP_PIECE); }

/*
 * A hard drop: the whoosh down the well, then the landing tone for the
 * row the piece ends up on - the same pitch a piece settling there by
 * itself would make, so the ear learns one scale for the stack's height
 * however the piece arrived.
 */
static void sfxDrop(int row)
{
    if (!sfxFree(SP_DROP)) return;
    const size_t n = sizeof SFX_DROP / sizeof SFX_DROP[0];
    audio.stopEffect();
    for (size_t i = 0; i < n; i++) sfxBuf[i] = SFX_DROP[i];
    sfxSetTone(&sfxBuf[n], settleHz(row), SETTLE_MS);
    sfxRank = SP_DROP;
    audio.effect(sfxBuf, n + 1);
}
static inline void sfxClear(void)          { sfxStart(SFX_CLEAR, SP_PHRASE); }
static inline void sfxTitle(void)          { sfxStart(SFX_TITLE, SP_PHRASE); }
static inline void sfxGo(void)             { sfxStart(SFX_GO, SP_PHRASE); }
static inline void sfxShatter(int row)     { sfxStartScaled(SFX_SHATTER, SFX_SHATTER_ROW[row], SP_DROP); }
static inline void sfxBanner(void)         { sfxStart(SFX_BANNER, SP_PHRASE); }

static inline void sfxOver(void)           { sfxStart(SFX_OVER, SP_PHRASE); }
