#pragma GCC optimize("Os")   // cold code: size over speed
#include "../../config.h"
#include "Slots.h"
#include "Strips.h"
#include <string.h>

static const uint8_t BETS[M_COUNT][4] = {{1, 5, 10, 25}, {5, 10, 25, 50}, {5, 10, 25, 50}};

// Three of a kind on the classic line, x bet.
static const uint16_t CLASSIC_PAY[C_COUNT] = {
    20, 15, 50, 100, 250, 500,          // CHERRY LEMON BELL BAR SEVEN CHEST
    25, 40, 50, 30,                     // PLUM GRAPE WATERMELON BANANA
    75, 100, 200, 25, 15,               // CLOVER HORSESHOE DIAMOND APPLE ORANGE
};
// Cherries also pay one or two at a time, anywhere on the line.
constexpr uint8_t CHERRY_1 = 1, CHERRY_2 = 5;
// The bonus wheel, clockwise from the top, x bet.
static const uint8_t WHEEL[WHEEL_SEGS] = {3, 5, 4, 10, 3, 6, 30, 4, 8, 3, 20, 60};

// Fortune line pays for 3, 4 and 5 of a kind, in fifths of the bet.
static const uint8_t FORTUNE_PAY[F_DRAGON][3] = {
    {1, 3, 10},     // JADE
    {1, 3, 10},     // FAN
    {1, 4, 12},     // LANTERN
    {2, 5, 15},     // ENVELOPE
    {3, 8, 25},     // KOI
    {4, 12, 40},    // INGOT
    {5, 20, 80},    // CAT
};
// SWEET: three on a line, in fifths of the bet; the last is three lollipops.
static const uint8_t SWEET_PAY[S_COUNT] = {5, 8, 12, 16, 30, 60, 150, 250};
static const uint8_t RUSH[RUSH_STEPS] = {1, 2, 3, 5};
// 3, 4, 5 gongs, x bet.
static const uint8_t SCATTER_PAY[3] = {2, 10, 50};

// The 25 lines: the row on each reel, two bits a reel, reel 1 lowest.
#define L(a, b, c, d, e) (uint16_t)((a) | (b) << 2 | (c) << 4 | (d) << 6 | (e) << 8)
static const uint16_t LINE[LINES] = {
    L(1,1,1,1,1), L(0,0,0,0,0), L(2,2,2,2,2), L(0,1,2,1,0), L(2,1,0,1,2),
    L(0,0,1,0,0), L(2,2,1,2,2), L(1,0,0,0,1), L(1,2,2,2,1), L(1,0,1,0,1),
    L(1,2,1,2,1), L(0,1,0,1,0), L(2,1,2,1,2), L(1,1,0,1,1), L(1,1,2,1,1),
    L(0,1,1,1,0), L(2,1,1,1,2), L(0,0,1,2,2), L(2,2,1,0,0), L(0,2,0,2,0),
    L(2,0,2,0,2), L(1,0,2,0,1), L(1,2,0,2,1), L(0,2,2,2,0), L(2,0,0,0,2),
};
#undef L

// Coins: chances in 256 of each K_*, cumulative. MAJOR only turns up during
// Hold and Spin.
static const uint8_t COIN_ODDS[2][K_COUNT - 1] = {
    {150, 210, 236, 250, 254, 255, 255},
    {150, 210, 236, 249, 253, 254, 255},
};
static const uint8_t COIN_X[K_MINI] = {0, 1, 2, 3, 5};
// A respin lands a coin on an empty cell one time in HOLD_ODDS.
constexpr uint8_t HOLD_ODDS = 22;

void Slots::seed(uint32_t s) { rng = s ? s : 0x9E3779B9u; reseeded = true; }

void Slots::mix(uint32_t e) {
    if (reseeded) return;                       // scripts replay the same spins
    rng ^= e * 2654435761u;
    rand32();
}

uint32_t Slots::rand32() {
    if (!rng) rng = 0x9E3779B9u;
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    return rng;
}

// 0..n-1 from the top of a 32-bit draw: one multiply-high, bias ~1e-8.
uint32_t Slots::below(uint32_t n) { return (uint32_t)(((uint64_t)rand32() * n) >> 32); }

void Slots::newGame() {
    purse = START_PURSE;
    betIdx[M_CLASSIC] = 1;
    betIdx[M_FORTUNE] = 0;
    betIdx[M_SWEET] = 0;
    rush = 0;
    freeLeft = freePlayed = 0;
    holding = false;
    lastWin = 0;
    memset(&res, 0, sizeof res);
    memset(held, 0, sizeof held);
}

uint16_t Slots::betOf(uint8_t m, uint8_t idx) { return BETS[m][idx]; }
uint16_t Slots::bet() const { return BETS[machine][betIdx[machine]]; }

bool Slots::changeBet(int d) {
    int i = betIdx[machine] + d;
    if (i < 0 || i > 3 || (d > 0 && BETS[machine][i] > purse)) return false;
    betIdx[machine] = (uint8_t)i;
    return true;
}

void Slots::fitBet() {
    while (betIdx[machine] && bet() > purse) betIdx[machine]--;
}

int32_t Slots::goal() const {
    return opt.goal == GOAL_1000 ? 1000 : (opt.goal == GOAL_5000 ? 5000 : 0);
}

uint8_t Slots::stripLen() const {
    return machine == M_CLASSIC ? CLASSIC_STOPS : (machine == M_FORTUNE ? FORTUNE_STOPS : SWEET_STOPS);
}

uint8_t Slots::stripSym(uint8_t reel, int idx) const {
    int n = stripLen();
    idx %= n;
    if (idx < 0) idx += n;
    if (machine == M_SWEET) return SWEET_STRIP[reel][idx];
    return machine == M_CLASSIC ? CLASSIC_STRIP[reel][idx] : FORTUNE_STRIP[reel][idx];
}

uint8_t Slots::lineRow(uint8_t line, uint8_t reel) { return (uint8_t)((LINE[line] >> (reel * 2)) & 3); }

int32_t Slots::classicPay(uint8_t a, uint8_t b, uint8_t c) {
    if (a == b && b == c) return CLASSIC_PAY[a];
    uint8_t k = (uint8_t)((a == C_CHERRY) + (b == C_CHERRY) + (c == C_CHERRY));
    return k == 2 ? CHERRY_2 : (k == 1 ? CHERRY_1 : 0);
}

uint8_t Slots::sweetPay(uint8_t sym) { return SWEET_PAY[sym]; }
uint8_t Slots::rushMult(uint8_t step) { return RUSH[step < RUSH_STEPS ? step : RUSH_STEPS - 1]; }
uint8_t Slots::wheelPrize(uint8_t seg) { return WHEEL[seg % WHEEL_SEGS]; }

uint8_t Slots::fortunePay(uint8_t sym, uint8_t count) {
    return (sym < F_DRAGON && count >= 3) ? FORTUNE_PAY[sym][count - 3] : 0;
}

int32_t Slots::meter(uint8_t j) const {
    int32_t b = bet();
    switch (j) {
        case J_MINI:  return 20 * b;
        case J_MINOR: return 50 * b;
        case J_MAJOR: return 200 * b + (int32_t)(pot[0] / 10);
        default:      return 1000 * b + (int32_t)(pot[1] / 5);
    }
}

int32_t Slots::coinValue(uint8_t k) const {
    if (k == K_NONE) return 0;
    if (k < K_MINI) return (int32_t)COIN_X[k] * bet();
    return meter((uint8_t)(k - K_MINI));
}

int32_t Slots::linePay(uint8_t line) const {
    if (!res.lineCount[line]) return 0;
    if (machine == M_CLASSIC)
        return classicPay(res.grid[0][1], res.grid[1][1], res.grid[2][1]) * bet();
    if (machine == M_SWEET) return (int32_t)SWEET_PAY[res.lineSym[line]] * (bet() / 5) * res.mult;
    return (int32_t)fortunePay(res.lineSym[line], res.lineCount[line]) * (bet() / 5) * (res.wasFree ? 2 : 1);
}

uint8_t Slots::drawCoin(bool inHold) {
    uint8_t r = (uint8_t)below(256), k = 0;
    while (r > COIN_ODDS[inHold][k]) k++;
    return (uint8_t)(K_X1 + k);
}

// ---------------------------------------------------------------------------
// A spin
// ---------------------------------------------------------------------------
void Slots::spin() {
    bool free = freeLeft > 0;
    if (free) { freeLeft--; freePlayed++; stats.freeGames++; }
    else {
        uint16_t b = bet();
        purse -= b;
        if (machine == M_FORTUNE) { pot[0] += b; pot[1] += b; }
        lastWin = 0;
        freePlayed = 0;
    }
    stats.spins++;
    memset(&res, 0, sizeof res);
    res.wasFree = free;
    uint8_t n = reels();
    for (uint8_t i = 0; i < n; i++) {
        res.stop[i] = isForced ? forced[i] : (uint8_t)below(stripLen());
        for (uint8_t row = 0; row < ROWS; row++) res.grid[i][row] = stripSym(i, res.stop[i] + row);
    }
    isForced = false;
    if (machine == M_CLASSIC) evalClassic();
    else if (machine == M_FORTUNE) evalFortune();
    else evalSweet();
    purse += res.total;
    lastWin += res.total;
    if (lastWin > stats.biggestWin) stats.biggestWin = lastWin;
    if (purse > stats.bestPurse) stats.bestPurse = purse;
}

void Slots::evalClassic() {
#if CHSL_DEBUG || defined(CHTEST)
    if (feature == 5) { res.grid[0][1] = C_CLOVER; res.grid[1][1] = C_HORSESHOE; feature = 0; }    // the wheel
#endif
    uint8_t a = res.grid[0][1], b = res.grid[1][1], c = res.grid[2][1];
    int32_t p = classicPay(a, b, c);
    // Two lucky charms on the line: one spin of the bonus wheel.
    uint8_t lucky = 0;
    for (uint8_t i = 0; i < 3; i++) lucky += res.grid[i][1] == C_CLOVER || res.grid[i][1] == C_HORSESHOE;
    if (lucky >= 2) {
        res.wheel = (uint8_t)(1 + below(WHEEL_SEGS));
        res.wheelPay = (int32_t)WHEEL[res.wheel - 1] * bet();
        res.total = res.wheelPay;
    }
    if (!p) return;
    bool three = a == b && b == c;
    res.lineCount[0] = three ? 3 : (uint8_t)((a == C_CHERRY) + (b == C_CHERRY) + (c == C_CHERRY));
    res.lineSym[0] = three ? a : (uint8_t)C_CHERRY;
    res.nLines = 1;
    res.linePay = p * bet();
    res.total += res.linePay;
}

// Five lines over the 3x3 window (the first five of the 25: the three rows,
// then the diagonals). A lollipop stands for anything. Every win pays at the
// sugar-rush multiplier and raises it for the next spin; a miss resets it.
void Slots::evalSweet() {
    Result &r = res;
    r.mult = rushMult(rush);
    int32_t unit = (int32_t)(bet() / 5) * r.mult;
    for (uint8_t l = 0; l < SWEET_LINES; l++) {
        uint8_t s = S_LOLLY;
        bool hit = true;
        for (uint8_t i = 0; i < 3; i++) {
            uint8_t x = r.grid[i][lineRow(l, i)];
            if (x == S_LOLLY) continue;
            if (s == S_LOLLY) s = x;
            else if (x != s) hit = false;
        }
        if (!hit) continue;
        r.lineCount[l] = 3;
        r.lineSym[l] = s;
        r.nLines++;
        r.linePay += SWEET_PAY[s] * unit;
    }
    r.total = r.linePay;
    rush = r.total ? (uint8_t)(rush + 1 < RUSH_STEPS ? rush + 1 : RUSH_STEPS - 1) : 0;
}

void Slots::evalFortune() {
    Result &r = res;
#if CHSL_DEBUG || defined(CHTEST)
    if (feature) {
        switch (feature) {
            case 1: r.grid[0][1] = r.grid[2][0] = r.grid[4][2] = F_GONG; break;
            case 2: for (uint8_t i = 0; i < 6; i++) r.grid[i / 3 * 2][i % 3] = F_COIN;
                    r.grid[1][1] = F_COIN; break;
            case 3: r.grid[0][1] = r.grid[1][0] = F_KOI; r.grid[2][2] = F_DRAGON; r.grid[3][1] = F_KOI; break;
            default: for (uint8_t i = 0; i < 5; i++) r.grid[i][1] = F_CAT; break;
        }
        feature = 0;
    }
#endif
    for (uint8_t i = 0; i < 5; i++)
        for (uint8_t row = 0; row < ROWS; row++) {
            uint8_t s = r.grid[i][row];
            if (s == F_DRAGON) r.wild |= (uint8_t)(1 << i);
            else if (s == F_GONG) r.scatters++;
            else if (s == F_COIN) { r.coins++; r.coin[i][row] = drawCoin(false); }
        }
    int32_t unit = bet() / 5 * (r.wasFree ? 2 : 1);
    for (uint8_t l = 0; l < LINES; l++) {
        uint8_t s = r.grid[0][lineRow(l, 0)];
        if (s >= F_DRAGON) continue;            // reel 1 has no dragon: a line starts on a picture
        uint8_t cnt = 1;
        while (cnt < 5 && ((r.wild >> cnt & 1) || r.grid[cnt][lineRow(l, cnt)] == s)) cnt++;
        if (cnt < 3) continue;
        r.lineCount[l] = cnt;
        r.lineSym[l] = s;
        r.nLines++;
        r.linePay += fortunePay(s, cnt) * unit;
    }
    if (r.scatters >= 3) {
        r.scatterPay = (int32_t)SCATTER_PAY[r.scatters - 3] * bet();
        r.freeTrigger = true;
        freeLeft = (uint8_t)(freeLeft + FREE_GAMES > FREE_MAX ? FREE_MAX : freeLeft + FREE_GAMES);
    }
    if (r.coins >= HOLD_COINS) {
        r.holdTrigger = true;
        holding = true;
        respins = HOLD_RESPINS;
        heldNew = 0;
        holdPay = 0;
        holdJackpot = 0;
        for (uint8_t i = 0; i < CELLS; i++) held[i] = r.coin[i / 3][i % 3];
        stats.holdSpins++;
    }
    r.total = r.linePay + r.scatterPay;
}

// ---------------------------------------------------------------------------
// Hold and Spin
// ---------------------------------------------------------------------------
bool Slots::respin() {
    if (!holding) return false;
    heldNew = 0;
    uint8_t count = 0;
    for (uint8_t i = 0; i < CELLS; i++) {
        if (!held[i] && below(HOLD_ODDS) == 0) { held[i] = drawCoin(true); heldNew |= (uint16_t)(1u << i); }
        if (held[i]) count++;
    }
    if (heldNew) respins = HOLD_RESPINS;
    else respins--;
    if (count < CELLS && respins) return true;
    endHold();
    return false;
}

void Slots::endHold() {
    uint8_t count = 0;
    holdPay = 0;
    for (uint8_t i = 0; i < CELLS; i++) {
        uint8_t k = held[i];
        if (!k) continue;
        count++;
        holdPay += coinValue(k);
        if (k >= K_MINI) {
            stats.jackpots++;
            if (k - K_MINI + 1 > holdJackpot) holdJackpot = (uint8_t)(k - K_MINI + 1);
        }
    }
    bool major = holdJackpot == J_MAJOR + 1;
    if (count == CELLS) {
        holdPay += meter(J_GRAND);
        holdJackpot = J_GRAND + 1;
        stats.jackpots++;
        pot[1] = 0;
    }
    if (major) pot[0] = 0;          // after the pay: the meter starts again
    holding = false;
    purse += holdPay;
    lastWin += holdPay;
    if (lastWin > stats.biggestWin) stats.biggestWin = lastWin;
    if (purse > stats.bestPurse) stats.bestPurse = purse;
}
