#include "Hardware.h"

// GPIOB CFGHR (pins 8-15) is write-only on the CH32X035: reading it back does
// not return what was written. The vendor GPIO driver therefore keeps a RAM
// shadow and rebuilds the whole register from it on every pinMode(), and
// CHGfx writes through the same shadow. PB10 must be configured the same way,
// or a read-modify-write here would scramble the buttons, LED, SD_CS and
// LCD_RST nibbles, and the next pinMode() or CHGfx frame would put PB10 back
// to whatever the shadow held, silencing the piezo.
extern "C" volatile uint32_t CFGHR_tmpB;

namespace chgame { namespace detail {
static const void *owner_ = nullptr;
static uint16_t lastHz_ = 0;
static void configurePB10(uint32_t nibble) {
    uint32_t v = (CFGHR_tmpB & ~(15u << 8)) | (nibble << 8);
    CFGHR_tmpB = v;
    GPIOB->CFGHR = v;
}
bool claim(const void *owner) {
    if (owner_ && owner_ != owner) return false;
    owner_ = owner;
    return true;
}
bool owns(const void *owner) { return owner_ == owner; }
void initPinTimer() {
    RCC->APB2PCENR |= RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB | RCC_APB2Periph_TIM1;
    // Only TIM1 remap bits and PB10's configuration nibble are changed.
    AFIO->PCFR1 = (AFIO->PCFR1 & ~(7u << 15)) | (1u << 15);
    GPIOB->BCR = 1u << 10;
    configurePB10(11u);     // Alternate-function push-pull, max drive.
    TIM1->CTLR1 = 0;
    TIM1->CTLR2 = 0;
    TIM1->SMCFGR = 0;
    TIM1->DMAINTENR = 0;
    TIM1->CCER = 0;
    TIM1->CHCTLR1 = 0x6800; // CH2 PWM1 + preload; CH1 disconnected.
    TIM1->CHCTLR2 = 0;
    TIM1->PSC = 47;         // The supported CHGame configuration is 48 MHz.
    TIM1->RPTCR = 0;
    TIM1->ATRLR = 999;
    TIM1->CH2CVR = 0;
    TIM1->CNT = 0;
    TIM1->BDTR = 0x8000;    // MOE: essential on the advanced timer.
    TIM1->CCER = 0x10;      // Only CH2 enabled; no complementary outputs.
    TIM1->SWEVGR = 1;
    TIM1->INTFR = 0;
    lastHz_ = 0;
}
void hardwareSilence() {
    TIM1->CH2CVR = 0;
    TIM1->SWEVGR = 1;       // Commit zero duty before stopping.
    TIM1->CTLR1 = 0;
    TIM1->INTFR = 0;
    lastHz_ = 0;
}
void hardwareTone(uint16_t hz) {
    if (hz == lastHz_) return;
    if (!hz) { hardwareSilence(); return; }
    // Round period, ARR is period minus one. Retuning is immediate, avoiding a
    // stale prescaler or waiting for a long old period to complete.
    uint32_t period = (1000000u + hz / 2u) / hz;
    if (period > 65536u) period = 65536u;
    if (period < 2u) period = 2u;
    TIM1->CTLR1 = 0;
    TIM1->PSC = 47;
    TIM1->RPTCR = 0;
    TIM1->ATRLR = period - 1;
    TIM1->CH2CVR = period / 2;
    TIM1->SWEVGR = 1;
    TIM1->INTFR = 0;
    TIM1->CTLR1 = 0x81;
    lastHz_ = hz;
}
void releaseHardware(const void *owner) {
    if (!owns(owner)) return;
    hardwareSilence();
    TIM1->CCER = 0;
    TIM1->BDTR = 0;
    GPIOB->BCR = 1u << 10;
    configurePB10(3u);      // General-purpose output, driven low.
    owner_ = nullptr;
}
} }
