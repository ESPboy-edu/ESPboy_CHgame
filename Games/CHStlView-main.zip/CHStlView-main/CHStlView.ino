/*
 * CHStlView - a wireframe STL viewer for the CHGame board (CH32X035 @ 48 MHz,
 *             20 KB SRAM, ST7735 128x128, microSD on the shared SPI1).
 *
 * Pick a .STL file on the card and it spins in 3D as a depth-cued wireframe.
 * Nothing about the mesh is kept in RAM: every frame streams the file from
 * the card and draws each triangle as it goes past (src/StlRender.h has the
 * why and the maths). Small models spin at tens of fps. Big ones would be
 * a slideshow, so while you turn them the viewer shows their bounding box
 * and a cloud of points sampled when the file was opened, drawn from RAM,
 * and streams the full model again once they come to rest.
 *
 * ---------------------------------------------------------------------------
 * CONTROLS
 * ---------------------------------------------------------------------------
 *   File list   UP / DOWN      move (hold to repeat)
 *               LEFT / RIGHT   page up / down
 *               A              open a model or folder
 *               B              up one folder
 *               START          re-read the card
 *
 *   Viewer      D-pad          rotate (stops the spin)
 *               A / B (hold)   zoom in / out
 *               A + B          reset the view
 *               SELECT         X-RAY (every edge) / FRONT (facing edges only)
 *               START          spin on / off
 *               START (hold)   back to the file list
 *
 * Any button brings up the HUD (name, triangles, size, mode, fps and an XYZ
 * gizmo) for 3 seconds.
 *
 * ---------------------------------------------------------------------------
 * FILES
 * ---------------------------------------------------------------------------
 * Binary STL, any size, in any folder. The SD library only sees 8.3 names,
 * so "my_bracket.stl" is listed as "MY_BRA~1.STL" - rename to 8 characters
 * to keep them readable. ASCII STL is detected and refused; re-export as
 * binary. A fragmented file is fine up to MAX_RUNS pieces.
 *
 * Build with Tools > Optimize > "Faster (-O2)", like the other sketches.
 */
#include "src/CHGame.h"
#include "src/SD/SD.h"
#include "src/StlRender.h"

/* ------------------------------------------------------------------------ */
/* Tuning                                                                    */
/* ------------------------------------------------------------------------ */
#define SPIN_DEG_PER_S     40      /* auto spin                               */
#define TURN_DEG_PER_S     120     /* D-pad rotation                          */
#define ZOOM_MS_PER_2X     1000    /* A/B: time to double / halve the zoom    */
#define PITCH_DEFAULT_DEG  25      /* start looking a little from above       */
#define YAW_DEFAULT_DEG    30
#define HUD_MS             3000
#define START_HOLD_MS      500

/* Card reads come in pieces so a long render can check the buttons and show
 * progress in between. Every piece costs one CMD18 (~0.6 ms of card latency),
 * so full renders use big ones: 128 blocks is 64 KB, ~1300 triangles. */
#define FULL_PIECE_BLOCKS  128

/* A model whose full frame takes longer than SLOW_MS is "slow": while it is
 * being turned the viewer shows a draft instead - its bounding box and
 * DRAFT_POINTS points sampled while the file was scanned, drawn from RAM at
 * full frame rate - and streams the real thing when it comes to rest.
 *
 * Why not draw every Nth piece of the file instead? Tried: files are stored
 * in whatever order the exporter walked the surface, so the pieces that get
 * drawn are clumps (whole faces, rings of a tube) rather than a sketch of
 * the shape, and each piece still costs ~0.6 ms of card latency. */
#define SLOW_MS            100     /* ~10 fps                                 */
#define PROGRESS_MS        150     /* slow full renders: show them building   */
#define DRAFT_POINTS       256     /* 768 bytes, shared with the file list    */

#define MAX_RUNS           16      /* file fragments we can follow            */
#define MAX_ENTRIES        40      /* file list length (800 bytes)            */

/* A file list entry. Declared up here, before any function: the Arduino
 * builder inserts its generated prototypes above the first function, and
 * entryCmp()'s would otherwise name a type that does not exist yet. */
struct Entry {
    uint32_t size;
    char     name[13];                 /* 8.3 + NUL */
    bool     isDir;
};

/* ------------------------------------------------------------------------ */
/* Palette                                                                   */
/* ------------------------------------------------------------------------ */
/* 0-6 are UI colours; 7-15 are the wire ramp from far (dim) to near
 * (bright), which StlRender's max-blend relies on. tools/preview.py has the
 * same numbers for the PC preview. */
enum : uint8_t { C_BG, C_TEXT, C_DIM, C_ACCENT, C_AXIS_X, C_AXIS_Y, C_AXIS_Z };
#define C_SEL (STL_SHADE0 + 3)      /* list highlight */

static void setupPalette(void)
{
    uint16_t pal[16];
    pal[C_BG]     = gfx_rgb(6, 8, 20);
    pal[C_TEXT]   = gfx_rgb(240, 240, 240);
    pal[C_DIM]    = gfx_rgb(130, 140, 160);
    pal[C_ACCENT] = gfx_rgb(255, 190, 40);
    pal[C_AXIS_X] = gfx_rgb(235, 70, 70);
    pal[C_AXIS_Y] = gfx_rgb(80, 210, 90);
    pal[C_AXIS_Z] = gfx_rgb(80, 130, 255);
    for (int i = 0; i < STL_SHADES; i++)
        pal[STL_SHADE0 + i] = gfx_rgb((uint8_t)(20 + 200 * i * i / 64),
                                      (uint8_t)(55 + 25 * i),
                                      (uint8_t)(85 + 170 * i / 8));
    gfx_setPalette(pal, 16);
}

/* ------------------------------------------------------------------------ */
/* State                                                                     */
/* ------------------------------------------------------------------------ */
CHGame chGame;

enum Screen : uint8_t { SCR_LIST, SCR_VIEW };
static Screen screen = SCR_LIST;
static bool   sdOk   = false;

/* The file list and the draft points are never needed at the same time,
 * and RAM is the scarcest thing on this chip, so they share. Leaving the
 * viewer re-reads the folder. */
static union {
    Entry  entries[MAX_ENTRIES];
    int8_t points[DRAFT_POINTS][3];
} arena;
static Entry *const entries = arena.entries;
static uint16_t pointCount;

/* File list */
static uint8_t entryCount;
static bool    entriesTruncated;
static int     sel, top;
static char    curPath[64] = "/";
static bool    listDirty = true;

/* The open model */
static char     modelName[13];
static uint32_t fileBlocks;
static uint32_t runLba[MAX_RUNS], runBlocks[MAX_RUNS];
static uint8_t  runCount;
static StlModel model;
static StlView  view;
static uint32_t zoomQ12;               /* finer than view.zoomQ8, for smooth zoom */
static bool     spin;

/* Render scheduling */
static uint32_t fullMs;                /* estimated full-frame time           */
static bool     needFull;             /* a full render is owed               */
static bool     hudShown;              /* HUD state of the last frame         */
static uint32_t hudUntil, hintUntil;
static int16_t  shownX0, shownY0, shownX1, shownY1;   /* model pixels on glass */

/* Stats, averaged over a second */
static uint32_t statStart, statFrames, statRenderUs, statLcdUs, statEdges, statPixels;
static uint32_t shownFps;
static bool     lastWasDraft;
static bool     frameMoving;           /* the frame being drawn is one of a run */

/* Button timing */
static uint32_t startDownAt;
static bool     startHoldFired;
static uint32_t repeatAt;

/* ------------------------------------------------------------------------ */
/* Small formatting helpers (no printf: it costs flash and RAM)              */
/* ------------------------------------------------------------------------ */
static char *putU32(char *p, uint32_t v)
{
    char tmp[10];
    uint8_t n = 0;
    do { tmp[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n) *p++ = tmp[--n];
    *p = 0;
    return p;
}

static char *putStr(char *p, const char *s)
{
    while (*s) *p++ = *s++;
    *p = 0;
    return p;
}

/* 12800 -> "12800", 225154 -> "225k", 1500000 -> "1500k" */
static char *putCount(char *p, uint32_t v)
{
    if (v < 100000) return putU32(p, v);
    p = putU32(p, (v + 500) / 1000);
    return putStr(p, "k");
}

/* Thousandths -> "49.9" below 100, "123" above. */
static char *putMilli(char *p, uint32_t m)
{
    if (m >= 100000) return putU32(p, (m + 500) / 1000);
    const uint32_t t = (m + 50) / 100;
    p = putU32(p, t / 10);
    *p++ = '.';
    *p++ = (char)('0' + t % 10);
    *p = 0;
    return p;
}

static void textRight(int xr, int y, const char *s, uint8_t c)
{
    gfx_text(xr - gfx_textWidth(s), y, s, c);
}

/* ------------------------------------------------------------------------ */
/* Full-screen messages                                                      */
/* ------------------------------------------------------------------------ */
static void message(const char *l1, const char *l2, const char *l3)
{
    gfx_wait();
    gfx_clear(C_BG);
    gfx_text(4, 44, l1, C_ACCENT);
    if (l2) gfx_text(4, 58, l2, C_TEXT);
    if (l3) gfx_text(4, 76, l3, C_DIM);
    gfx_flush();
}

/* CHGame::justPressed(mask) is "none of mask held before, some now". This is
 * "any button in mask went down", even while others are held. */
static bool anyJustPressed(uint8_t mask)
{
    for (uint8_t b = 1; b; b <<= 1)
        if ((mask & b) && chGame.justPressed(b)) return true;
    return false;
}

static void waitRelease(void)
{
    do { chGame.pollButtons(); delay(10); } while (chGame.anyPressed(0xFF));
    chGame.pollButtons();
}

static void waitAnyButton(void)
{
    do { chGame.pollButtons(); delay(10); } while (!anyJustPressed(0xFF));
    waitRelease();
}

/* ------------------------------------------------------------------------ */
/* Streaming the file off the card                                           */
/* ------------------------------------------------------------------------ */
static struct {
    StlFeed     feed;
    uint32_t    off;                   /* file offset of the next block       */
    StlRecordFn fn;
} stream;

/* readBlocksPipelined() calls this while the NEXT block is already arriving
 * by DMA, so the drawing below costs no time as long as it keeps up with the
 * card (~170 us per block at 24 MHz). */
static void onBlock(const uint8_t *blk, void *)
{
    stlFeedBytes(stream.feed, stream.off, blk, 512, stream.fn);
    stream.off += 512;
}

/* File blocks [b, b + n), across however many fragments they span. */
static bool readFileBlocks(uint32_t b, uint32_t n)
{
    uint8_t *buf0 = gfx_chunkScratch();
    uint8_t *buf1 = buf0 + GFX_CHUNK_BYTES;
    uint32_t base = 0;
    for (uint8_t r = 0; r < runCount && n; r++) {
        const uint32_t len = runBlocks[r];
        if (b < base + len) {
            const uint32_t skip = b - base;
            uint32_t take = len - skip;
            if (take > n) take = n;
            stream.off = b << 9;
            if (!SD.rawCard().readBlocksPipelined(runLba[r] + skip, (uint16_t)take,
                                                  buf0, buf1, onBlock, nullptr))
                return false;
            b += take;
            n -= take;
        }
        base += len;
    }
    return n == 0;
}

enum : int8_t { STREAM_OK = 0, STREAM_IO = -1, STREAM_ABORT = -2 };

/* The whole file through fn, FULL_PIECE_BLOCKS at a time. `between` runs
 * after each piece, with the card idle and the bus free; returning false
 * aborts. */
static int8_t streamFile(StlRecordFn fn, bool (*between)(uint32_t done, uint32_t total))
{
    /* Card data lands in CHGfx's flush chunk buffers, and fn draws into the
     * framebuffer: both need the previous async flush to be finished. */
    gfx_wait();
    stlFeedBegin(stream.feed, model.tris);
    stream.fn = fn;
    for (uint32_t b = 0; b < fileBlocks; b += FULL_PIECE_BLOCKS) {
        const uint32_t n = fileBlocks - b < FULL_PIECE_BLOCKS ? fileBlocks - b : FULL_PIECE_BLOCKS;
        if (!readFileBlocks(b, n)) return STREAM_IO;
        if (between && !between(b + n, fileBlocks)) return STREAM_ABORT;
    }
    return STREAM_OK;
}

/* ------------------------------------------------------------------------ */
/* Opening a model                                                           */
/* ------------------------------------------------------------------------ */
static uint32_t rd32le(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void progressBar(int y, uint32_t done, uint32_t total, uint8_t c)
{
    const int w = (int)((uint64_t)120 * done / (total ? total : 1));
    gfx_rect(3, y, 122, 6, C_DIM);
    gfx_fillRect(4, y + 1, w, 4, c);
}

static uint32_t scanShownAt;
static bool scanProgress(uint32_t done, uint32_t total)
{
    const uint32_t now = millis();
    if (now - scanShownAt >= 100 || done == total) {
        scanShownAt = now;
        progressBar(70, done, total, C_ACCENT);
        gfx_flushRect(0, 70, GFX_W, 6);
    }
    return true;
}

static void resetView(void)
{
    view.yaw    = (uint16_t)((uint32_t)YAW_DEFAULT_DEG * 65536 / 360);
    view.pitch  = (uint16_t)((uint32_t)PITCH_DEFAULT_DEG * 65536 / 360);
    zoomQ12     = 256u << 4;
    view.zoomQ8 = 256;
    view.cx     = GFX_W / 2;
    view.cy     = GFX_H / 2;
}

static bool slowModel(void) { return fullMs > SLOW_MS; }

static bool openModel(const char *path, const char *name)
{
    gfx_wait();
    File f = SD.open(path);
    if (!f) { message("Can't open", name, "any button"); return false; }

    const uint32_t size = f.size();
    uint8_t hdr[STL_HEADER_BYTES];
    const bool gotHeader = f.read(hdr, sizeof hdr) == (int)sizeof hdr;
    runCount = gotHeader ? f.blockRuns(runLba, runBlocks, MAX_RUNS) : 0;
    f.close();

    if (!gotHeader) { message("Not an STL", name, "file too short"); return false; }

    /* Binary if the count in the header accounts for the file. Some
     * exporters start a binary header with "solid" too, so the ASCII test
     * only applies when the count does not fit. */
    const uint32_t tris = rd32le(hdr + 80);
    const uint64_t expect = STL_HEADER_BYTES + (uint64_t)tris * STL_RECORD_BYTES;
    if (expect > size) {
        if (memcmp(hdr, "solid", 5) == 0)
            message("ASCII STL", "not supported yet:", "re-export as binary");
        else
            message("Not a binary STL", name, "size doesn't match");
        return false;
    }
    if (tris == 0) { message("Empty STL", name, "0 triangles"); return false; }
    if (!runCount) { message("File too", "fragmented:", "copy to a fresh card"); return false; }

    fileBlocks = (uint32_t)((expect + 511) >> 9);

    /* ---- pass 1: bounds, closed-mesh test, draft points ----------------- */
    /* The screen below row SAMPLE_ROW is never flushed during the scan, so
     * that part of the framebuffer holds the sampled points' raw floats
     * (12 bytes each) until stlScanEnd() packs them into the arena. */
    const int SAMPLE_ROW = GFX_H - (DRAFT_POINTS * 12) / GFX_FB_STRIDE;
    gfx_clear(C_BG);
    char line[24], *p = putCount(line, tris);
    putStr(p, " triangles");
    gfx_text(4, 30, line, C_DIM);
    gfx_text(4, 44, "Scanning", C_DIM);
    gfx_text(4, 56, name, C_TEXT);
    gfx_flush();

    model.tris = tris;                 /* streamFile() sizes the feed from it */
    scanShownAt = millis();
    const uint32_t t0 = millis();
    stlScanBegin(tris, (uint32_t *)(gfx_fb + SAMPLE_ROW * GFX_FB_STRIDE), DRAFT_POINTS);
    if (streamFile(stlScanRecord, scanProgress) != STREAM_OK) {
        message("SD read error", name, "any button");
        return false;
    }
    const uint32_t scanMs = millis() - t0;
    /* From here on the file list is gone: the arena holds the points. */
    if (!stlScanEnd(model, arena.points, &pointCount)) {
        message("Nothing to draw", name, "all NaN/inf?");
        return false;
    }

    strncpy(modelName, name, sizeof modelName - 1);
    modelName[sizeof modelName - 1] = 0;

    /* A full frame costs about what the scan did (both are card-bound),
     * plus the panel transfer. Refined from every full frame from here on. */
    fullMs = scanMs + 8;

    resetView();
    view.mode  = STL_XRAY;
    view.ortho = false;
    view.dedup = model.closed;
    /* Small models open spinning. A big one opens still, so its first,
     * full render is what you see; turn it and it drops to the draft. */
    spin = !slowModel();

    if (Serial) {
        Serial.print(F("open "));      Serial.print(path);
        Serial.print(F("  tris "));    Serial.print(model.tris);
        Serial.print(F("  bad "));     Serial.print(model.badTris);
        Serial.print(F("  closed "));  Serial.print(model.closed);
        Serial.print(F("  runs "));    Serial.print(runCount);
        Serial.print(F("  blocks "));  Serial.print(fileBlocks);
        Serial.print(F("  scan ms ")); Serial.println(scanMs);
    }
    return true;
}

/* ------------------------------------------------------------------------ */
/* Viewer: drawing                                                           */
/* ------------------------------------------------------------------------ */

/* XYZ gizmo: the model's axes under the current rotation, far one first. */
static void drawGizmo(int cx, int cy, int len)
{
    int32_t R[3][3];
    stlRotation(R);
    static const uint8_t col[3] = { C_AXIS_X, C_AXIS_Y, C_AXIS_Z };
    uint8_t order[3] = { 0, 1, 2 };
    for (int i = 0; i < 2; i++)                  /* sort by depth, far first */
        for (int j = 0; j < 2 - i; j++)
            if (R[2][order[j]] < R[2][order[j + 1]]) {
                const uint8_t t = order[j]; order[j] = order[j + 1]; order[j + 1] = t;
            }
    for (int i = 0; i < 3; i++) {
        const int a = order[i];
        stlLine(cx, cy, cx + ((R[0][a] * len) >> 14), cy + ((R[1][a] * len) >> 14), col[a]);
    }
}

static void drawHud(void)
{
    char line[24], *p;

    /* Top: name and triangles; below them the size of the box. */
    gfx_fillRect(0, 0, GFX_W, 18, C_BG);
    gfx_text(1, 1, modelName, C_TEXT);
    p = putCount(line, model.tris);
    putStr(p, "t");
    textRight(GFX_W - 1, 1, line, C_DIM);

    p = putMilli(line, model.sizeMilli[0]); *p++ = 'x';
    p = putMilli(p, model.sizeMilli[1]);    *p++ = 'x';
    putMilli(p, model.sizeMilli[2]);
    gfx_text(1, 10, line, C_DIM);
    if (!model.closed) textRight(GFX_W - 1, 10, "open", C_ACCENT);

    /* Bottom: mode, zoom and fps, or the controls hint just after opening. */
    gfx_fillRect(0, GFX_H - 9, GFX_W, 9, C_BG);
    if ((int32_t)(hintUntil - millis()) > 0) {
        gfx_text(1, GFX_H - 8, "START:spin hold:list", C_DIM);
    } else {
        gfx_text(1, GFX_H - 8, lastWasDraft ? "DRAFT" : view.mode == STL_FRONT ? "FRONT" : "X-RAY",
                 C_ACCENT);

        p = putU32(line, view.zoomQ8 * 10 / 256 / 10); *p++ = '.';
        p = putU32(p, view.zoomQ8 * 10 / 256 % 10);
        putStr(p, "x");
        gfx_text(46, GFX_H - 8, line, C_DIM);

        /* Moving: frames per second. At rest, the time the full render
         * on screen took says more. */
        if (frameMoving && shownFps >= 3) { p = putU32(line, shownFps); putStr(p, "fps"); }
        else                              { p = putU32(line, fullMs);   putStr(p, "ms");  }
        textRight(GFX_W - 1, GFX_H - 8, line, C_TEXT);
    }
    drawGizmo(GFX_W - 12, GFX_H - 22, 9);
}

/* Slow full render: between pieces, give up if a button went down (the
 * loop will start over with the new view) and every PROGRESS_MS put what is
 * drawn so far on the glass, so a big model visibly builds up. */
static uint32_t progressAt;
static bool renderProgress(uint32_t done, uint32_t total)
{
    if (chGame.anyPressed(0xFF)) return false;
    const uint32_t now = millis();
    if (now - progressAt < PROGRESS_MS) return true;
    progressAt = now;

    StlFrameInfo fi;
    stlFramePeek(fi);
    /* The bar goes where the bottom HUD line will be drawn over it. */
    progressBar(GFX_H - 7, done, total, C_ACCENT);
    int16_t x0 = shownX0 < fi.x0 ? shownX0 : fi.x0, y0 = shownY0 < fi.y0 ? shownY0 : fi.y0;
    int16_t x1 = shownX1 > fi.x1 ? shownX1 : fi.x1, y1 = shownY1 > fi.y1 ? shownY1 : fi.y1;
    if (x1 >= x0) gfx_flushRect(x0, y0, x1 - x0 + 1, y1 - y0 + 1);
    gfx_flushRect(0, GFX_H - 7, GFX_W, 6);
    shownX0 = x0; shownY0 = y0; shownX1 = x1; shownY1 = y1;
    return true;
}

/* Draw one frame. Returns false if a full render was cut short by input. */
static bool renderFrame(bool draft, bool hud)
{
    const uint32_t tLcd = micros();
    gfx_wait();                         /* previous frame off the bus */
    const uint32_t t0 = micros();
    statLcdUs += t0 - tLcd;

    gfx_clear(C_BG);
    stlFrameBegin(model, view);
    int8_t r = STREAM_OK;
    if (draft) {
        stlDrawDraft(model, arena.points, pointCount);
    } else {
        progressAt = millis();
        r = streamFile(stlDrawRecord, slowModel() ? renderProgress : nullptr);
    }
    StlFrameInfo fi;
    stlFrameEnd(fi);
    const uint32_t us = micros() - t0;

    if (r == STREAM_IO) {
        message("SD read error", modelName, "any button");
        waitAnyButton();
        screen = SCR_LIST;
        listDirty = true;
        return true;
    }
    if (r == STREAM_ABORT) return false;

    /* Learn how long a full frame really takes (+ a typical flush): that
     * decides between streaming and the draft while moving. */
    if (!draft) fullMs = us / 1000 + 4;
    lastWasDraft = draft;

    if (hud) drawHud();

    /* Flush what changed: the whole screen while the HUD is up or has just
     * gone, otherwise the model's box now and where it was last frame. */
    if (hud || hudShown) {
        gfx_flushAsync();
    } else {
        int16_t x0 = shownX0 < fi.x0 ? shownX0 : fi.x0, y0 = shownY0 < fi.y0 ? shownY0 : fi.y0;
        int16_t x1 = shownX1 > fi.x1 ? shownX1 : fi.x1, y1 = shownY1 > fi.y1 ? shownY1 : fi.y1;
        if (x1 >= x0) gfx_flushRectAsync(x0, y0, x1 - x0 + 1, y1 - y0 + 1);
    }
    shownX0 = fi.x0; shownY0 = fi.y0; shownX1 = fi.x1; shownY1 = fi.y1;
    hudShown = hud;

    statFrames++;
    statRenderUs += us;
    statEdges    += fi.edges;
    statPixels   += fi.pixels;
    return true;
}

/* ------------------------------------------------------------------------ */
/* Viewer: input and scheduling                                              */
/* ------------------------------------------------------------------------ */
static void enterViewer(void)
{
    waitRelease();                      /* the A that opened the model is not a zoom */
    screen = SCR_VIEW;
    const uint32_t now = millis();
    hudUntil = hintUntil = now + HUD_MS;
    hudShown = true;                    /* first frame repaints everything */
    shownX0 = 0; shownY0 = 0; shownX1 = GFX_W - 1; shownY1 = GFX_H - 1;
    needFull = true;
    shownFps = 0;
    statStart = now;
    statFrames = statRenderUs = statLcdUs = statEdges = statPixels = 0;
    startDownAt = 0;
    startHoldFired = false;
}

static void reportStats(uint32_t now)
{
    if (now - statStart < 1000) return;
    const uint32_t dt = now - statStart;
    shownFps = (statFrames * 1000 + dt / 2) / dt;
    if (Serial && statFrames) {
        Serial.print(view.mode == STL_FRONT ? F("FRONT") : F("X-RAY"));
        Serial.print(lastWasDraft ? F(" draft") : F(" full"));
        Serial.print(F("  fps "));      Serial.print(shownFps);
        Serial.print(F("  render "));   Serial.print(statRenderUs / statFrames);
        Serial.print(F("us  lcd "));    Serial.print(statLcdUs / statFrames);
        Serial.print(F("us  edges "));  Serial.print(statEdges / statFrames);
        Serial.print(F("  pixels "));   Serial.println(statPixels / statFrames);
    }
    statStart = now;
    statFrames = statRenderUs = statLcdUs = statEdges = statPixels = 0;
}

static void viewerLoop(void)
{
    static uint32_t last = millis();
    const uint32_t now = millis();
    uint32_t dt = now - last;
    last = now;
    if (dt > 100) dt = 100;             /* after a slow frame, don't lurch */

    chGame.pollButtons();
    if (chGame.anyPressed(0xFF)) hudUntil = now + HUD_MS;
    bool moving = false;

    /* START: tap toggles the spin, hold goes back to the list. */
    if (chGame.justPressed(START_BUTTON)) { startDownAt = now; startHoldFired = false; }
    if (startDownAt && chGame.pressed(START_BUTTON) && !startHoldFired &&
        now - startDownAt >= START_HOLD_MS) {
        startHoldFired = true;
        gfx_wait();
        screen = SCR_LIST;
        listDirty = true;
        return;
    }
    if (chGame.justReleased(START_BUTTON)) {
        if (!startHoldFired && startDownAt) { spin = !spin; needFull = true; }
        startDownAt = 0;
    }

    if (chGame.justPressed(SELECT_BUTTON)) {
        view.mode = (uint8_t)((view.mode + 1) % STL_MODES);
        needFull = true;
    }

    /* D-pad: rotate. */
    const int32_t turn = (int32_t)((uint32_t)TURN_DEG_PER_S * 65536u / 360u * dt / 1000u);
    const bool l = chGame.pressed(LEFT_BUTTON), r = chGame.pressed(RIGHT_BUTTON);
    const bool u = chGame.pressed(UP_BUTTON),   d = chGame.pressed(DOWN_BUTTON);
    if (l || r || u || d) {
        spin = false;
        moving = true;
        if (l) view.yaw   = (uint16_t)(view.yaw - turn);
        if (r) view.yaw   = (uint16_t)(view.yaw + turn);
        if (u) view.pitch = (uint16_t)(view.pitch + turn);
        if (d) view.pitch = (uint16_t)(view.pitch - turn);
    }

    /* A/B: zoom, both: reset. */
    const bool a = chGame.pressed(A_BUTTON), b = chGame.pressed(B_BUTTON);
    if (a && b) {
        if (chGame.justPressed(A_BUTTON) || chGame.justPressed(B_BUTTON)) {
            resetView();
            needFull = true;
        }
    } else if (a || b) {
        /* zoom *= 2^(dt / ZOOM_MS_PER_2X), linearised per step: ln 2 = 710/1024.
         * Divide before the multiply: zoomQ12 * dt * 710 would pass 2^32. */
        const uint32_t step = (zoomQ12 * dt / ZOOM_MS_PER_2X * 710u) >> 10;
        if (a) zoomQ12 += step ? step : 1;
        else   zoomQ12 -= step ? step : 1;
        if (zoomQ12 < (uint32_t)STL_ZOOM_MIN << 4) zoomQ12 = (uint32_t)STL_ZOOM_MIN << 4;
        if (zoomQ12 > (uint32_t)STL_ZOOM_MAX << 4) zoomQ12 = (uint32_t)STL_ZOOM_MAX << 4;
        view.zoomQ8 = (uint16_t)(zoomQ12 >> 4);
        moving = true;
    }

    if (spin) {
        view.yaw = (uint16_t)(view.yaw + (uint32_t)SPIN_DEG_PER_S * 65536u / 360u * dt / 1000u);
        moving = true;
    }

    /* The HUD stays up on a slow model at rest: taking it down would mean
     * re-rendering the whole thing just to erase some text. */
    const bool hud = (int32_t)(hudUntil - now) > 0 || (slowModel() && !moving);
    if (hud != hudShown) needFull = true;

    frameMoving = moving;
    if (moving) {
        const bool draft = slowModel();
        if (renderFrame(draft, hud)) needFull = draft;
    } else if (needFull) {
        if (renderFrame(false, hud)) needFull = false;
    }
    /* Otherwise nothing changed: leave the glass alone. */
    reportStats(millis());
}

/* ------------------------------------------------------------------------ */
/* File list                                                                 */
/* ------------------------------------------------------------------------ */
#define LIST_TOP   12
#define ROW_H      10
#define VISIBLE    10

static bool isStl(const char *n)
{
    const char *d = strrchr(n, '.');
    return d && (d[1] | 32) == 's' && (d[2] | 32) == 't' && (d[3] | 32) == 'l' && d[4] == 0;
}

static int entryCmp(const Entry &a, const Entry &b)
{
    if (a.isDir != b.isDir) return a.isDir ? -1 : 1;
    return strcmp(a.name, b.name);     /* 8.3 names are upper case already */
}

static void scanDir(void)
{
    entryCount = 0;
    entriesTruncated = false;
    sel = top = 0;
    gfx_wait();
    File dir = SD.open(curPath);
    if (dir) {
        dir.rewindDirectory();
        for (;;) {
            File e = dir.openNextFile();
            if (!e) break;
            const char *n = e.name();
            const bool isDir = e.isDirectory();
            /* Folders, and .STL files. Skip Windows' "System Volume
             * Information", which shows up as SYSTEM~1. */
            if ((isDir && strncmp(n, "SYSTEM~", 7) != 0) || (!isDir && isStl(n))) {
                if (entryCount < MAX_ENTRIES) {
                    Entry &en = entries[entryCount++];
                    strncpy(en.name, n, sizeof en.name - 1);
                    en.name[sizeof en.name - 1] = 0;
                    en.isDir = isDir;
                    en.size = isDir ? 0 : e.size();
                } else {
                    entriesTruncated = true;
                }
            }
            e.close();
        }
        dir.close();
    }
    for (int i = 1; i < entryCount; i++) {      /* insertion sort */
        const Entry key = entries[i];
        int j = i - 1;
        while (j >= 0 && entryCmp(entries[j], key) > 0) { entries[j + 1] = entries[j]; j--; }
        entries[j + 1] = key;
    }
    listDirty = true;
}

static bool mountCard(void)
{
    message("Reading card...", nullptr, nullptr);
    gfx_wait();
    sdOk = SD.begin(PIN_SD_CS);
    strcpy(curPath, "/");
    if (sdOk) scanDir();
    listDirty = true;
    if (Serial) Serial.println(sdOk ? F("SD mounted") : F("SD mount failed"));
    return sdOk;
}

static void drawList(void)
{
    gfx_wait();
    gfx_clear(C_BG);
    gfx_fillRect(0, 0, GFX_W, 10, C_DIM);
    gfx_text(2, 1, "STL VIEWER", C_BG);
    /* The path, keeping its deepest end if it is long. */
    const char *path = curPath;
    const size_t fit = 9;
    if (strlen(path) > fit) path += strlen(path) - fit;
    textRight(GFX_W - 2, 1, path, C_BG);

    if (!sdOk) {
        gfx_text(4, 44, "No SD card", C_ACCENT);
        gfx_text(4, 58, "FAT16/32, then", C_TEXT);
        gfx_text(4, 70, "START to retry", C_TEXT);
    } else if (entryCount == 0) {
        gfx_text(4, 44, "No .STL files", C_ACCENT);
        gfx_text(4, 58, "in this folder", C_TEXT);
        gfx_text(4, 76, curPath[1] ? "B: back" : "START: re-read", C_DIM);
    } else {
        for (int i = 0; i < VISIBLE && top + i < entryCount; i++) {
            const Entry &e = entries[top + i];
            const int y = LIST_TOP + i * ROW_H;
            const bool hi = top + i == sel;
            if (hi) gfx_fillRect(0, y - 1, GFX_W - 3, ROW_H, C_SEL);
            gfx_text(2, y, e.name, e.isDir ? C_ACCENT : C_TEXT);
            char n[12];
            if (e.isDir) {
                putStr(n, "/");
            } else {
                /* Triangles, from the size: exact for a binary STL. */
                const uint32_t t = e.size > STL_HEADER_BYTES ? (e.size - STL_HEADER_BYTES) / STL_RECORD_BYTES : 0;
                putCount(n, t);
            }
            textRight(GFX_W - 5, y, n, hi ? C_TEXT : C_DIM);
        }
        if (entryCount > VISIBLE) {             /* scrollbar */
            const int h = VISIBLE * ROW_H;
            int th = h * VISIBLE / entryCount;
            if (th < 6) th = 6;
            const int y = LIST_TOP - 1 + (h - th) * top / (entryCount - VISIBLE);
            gfx_fillRect(GFX_W - 2, LIST_TOP - 1, 2, h, C_DIM);
            gfx_fillRect(GFX_W - 2, y, 2, th, C_TEXT);
        }
    }
    gfx_hline(0, GFX_H - 11, GFX_W, C_DIM);
    gfx_text(2, GFX_H - 9, entriesTruncated ? "A:open B:up (40 max)" : "A:open  B:up", C_DIM);
    gfx_flush();
    listDirty = false;
}

static void moveSel(int delta)
{
    if (!entryCount) return;
    sel += delta;
    if (sel < 0) sel = 0;
    if (sel >= entryCount) sel = entryCount - 1;
    if (sel < top) top = sel;
    if (sel >= top + VISIBLE) top = sel - VISIBLE + 1;
    listDirty = true;
}

static void listLoop(void)
{
    const uint32_t now = millis();
    chGame.pollButtons();

    if (chGame.justPressed(START_BUTTON)) { mountCard(); return; }
    if (!sdOk) { if (listDirty) drawList(); return; }

    /* Auto-repeat: first repeat after 350 ms, then every 80 ms. */
    int delta = 0;
    const uint8_t dirs = UP_BUTTON | DOWN_BUTTON | LEFT_BUTTON | RIGHT_BUTTON;
    if (chGame.justPressed(dirs)) repeatAt = now + 350;
    const bool rep = chGame.anyPressed(dirs) && (int32_t)(now - repeatAt) >= 0;
    if (rep) repeatAt = now + 80;
    if (chGame.justPressed(UP_BUTTON)    || (rep && chGame.pressed(UP_BUTTON)))    delta = -1;
    if (chGame.justPressed(DOWN_BUTTON)  || (rep && chGame.pressed(DOWN_BUTTON)))  delta = 1;
    if (chGame.justPressed(LEFT_BUTTON)  || (rep && chGame.pressed(LEFT_BUTTON)))  delta = -VISIBLE;
    if (chGame.justPressed(RIGHT_BUTTON) || (rep && chGame.pressed(RIGHT_BUTTON))) delta = VISIBLE;
    if (delta) moveSel(delta);

    if (chGame.justPressed(B_BUTTON) && curPath[1]) {
        char *s = strrchr(curPath, '/');
        if (s == curPath) curPath[1] = 0; else *s = 0;
        scanDir();
    }

    if (chGame.justPressed(A_BUTTON) && entryCount) {
        const Entry &e = entries[sel];
        char path[80];
        const size_t l = strlen(curPath);
        if (l + strlen(e.name) + 2 <= sizeof path) {
            strcpy(path, curPath);
            if (path[l - 1] != '/') strcat(path, "/");
            strcat(path, e.name);
            if (e.isDir) {
                if (strlen(path) < sizeof curPath) { strcpy(curPath, path); scanDir(); }
            } else {
                /* Copy the name out first: a successful open overwrites the
                 * list (and so `e`) with the draft points. */
                char name[sizeof e.name];
                strcpy(name, e.name);
                const int keepSel = sel, keepTop = top;
                if (openModel(path, name)) {
                    enterViewer();
                } else {
                    waitAnyButton();
                }
                sel = keepSel; top = keepTop;
                listDirty = true;
            }
        }
    }

    if (listDirty && screen == SCR_LIST) drawList();
}

/* ------------------------------------------------------------------------ */
/* setup / loop                                                              */
/* ------------------------------------------------------------------------ */
void setup()
{
    /* 24 MHz SPI, 12 bpp: 25% less panel traffic than 16 bpp, and the
     * palette has only 16 colours anyway. */
    Gfx.begin(GFX_DIV2, GFX_12BPP);
    setupPalette();
    chGame.boot();

    /* Give a host a moment to open the serial port for the boot report. */
    Serial.waitForPC(1500);
    mountCard();
}

void loop()
{
    if (screen == SCR_VIEW) {
        viewerLoop();
        if (screen == SCR_LIST) {
            /* Back from the viewer. The draft points overwrote the listing
             * (they share the arena), so read the folder again and put the
             * highlight back where it was. */
            const int keepSel = sel, keepTop = top;
            waitRelease();
            scanDir();
            if (keepSel < entryCount) { sel = keepSel; top = keepTop; }
            drawList();
        }
    } else {
        listLoop();
    }
}
