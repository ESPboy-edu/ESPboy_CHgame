/* Host stand-in for the Arduino core: a virtual clock, scripted buttons and
 * a Serial that prints to stdout. Only what CHStlView uses. */
#pragma once
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LOW          0
#define HIGH         1
#define OUTPUT       1
#define INPUT_PULLUP 2

enum {
    PIN_BTN_A = 1, PIN_BTN_B, PIN_BTN_UP, PIN_BTN_DOWN, PIN_BTN_LEFT, PIN_BTN_RIGHT,
    PIN_BTN_START, PIN_BTN_SELECT, PIN_SD_CS, PIN_LCD_RST
};

uint32_t millis(void);
uint32_t micros(void);
void delay(uint32_t ms);
int digitalRead(int pin);
static inline void pinMode(int, int) {}
static inline void digitalWrite(int, int) {}

/* Advance the virtual clock (and take any snapshots that fall due). */
void simAdvanceUs(uint64_t us);

#define F(s) (s)

struct SerialMock {
    explicit operator bool() const { return true; }
    void print(const char *s) { fputs(s, stdout); }
    void print(char c) { putchar(c); }
    template <class T> void print(T v) { printf("%lld", (long long)v); }
    void println() { putchar('\n'); }
    template <class T> void println(T v) { print(v); putchar('\n'); fflush(stdout); }
    void waitForPC(int) {}
};
extern SerialMock Serial;
