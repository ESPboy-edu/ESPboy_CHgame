# CHGameSound (vendored)

An unmodified copy of the `src/` folder of **CHGameSound 0.1.0**, the sound
library for the CHGame handheld: hardware tones, Playtune music, a four-voice
synthesizer and MOD playback on the CH32X035's piezo output (PB10).

It lives here because the library is not published on its own yet, and a
sketch's `src/` folder is compiled as part of the sketch, so the game builds
with nothing but CHGfx installed. The game includes it by relative path:

```cpp
#include "src/CHGameSound/CHGameSound.h"
```

Do not also include `<CHGameSound.h>` with angle brackets. If the library is
installed in your sketchbook, that pulls in the installed copy as well and the
two collide.

The game uses only the `Output::Lead` hardware tone path. The MOD player,
robot voice and standalone `CHGameTone` are compiled but unused, and the
linker discards them.

MIT licensed. See [LICENSE](LICENSE) in this folder. The rest of the
repository is GPL-3.0.
