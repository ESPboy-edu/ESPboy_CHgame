#!/usr/bin/env python3
"""Convert a Standard MIDI File to a four-channel Playtune score.

Voices are allocated by explicit rules so the result stays musical on four
monophonic channels. Each --voice option binds one score channel to a source
(a MIDI track or MIDI channel) and a policy: "high" takes the highest sounding
note, "low" the lowest. Several score channels can share one source; they take
the notes in the order listed. Percussion (MIDI channel 9) is dropped unless a
voice names it, in which case its drum numbers pass through as note numbers.
Standard library only.

Examples:
  python tools/midi2score.py song.mid                 # print tracks and channels
  python tools/midi2score.py song.mid song.h --voice 0=t1:high --voice 1=t1:high \\
      --voice 2=t2:low --voice 3=t2:high --loop --min-note 48
"""
import argparse
import collections
from pathlib import Path
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from score_tool import encode, validate, write_score  # noqa: E402


def read_vlq(data, position):
    value = 0
    while True:
        byte = data[position]
        position += 1
        value = (value << 7) | (byte & 127)
        if byte < 128:
            return value, position


class Midi:
    """Notes are (start_tick, end_tick, track, channel, note, velocity)."""

    def __init__(self, data):
        if data[:4] != b'MThd':
            raise ValueError('Not a Standard MIDI File')
        self.format, count, self.division = struct.unpack('>HHH', data[8:14])
        if self.division & 0x8000:
            raise ValueError('SMPTE time division is not supported')
        self.tempos = []  # (tick, microseconds per quarter)
        self.names = {}
        self.programs = {}
        self.notes = []
        position = 14
        for track in range(count):
            if data[position:position + 4] != b'MTrk':
                raise ValueError(f'Track {track} chunk missing')
            length = struct.unpack('>I', data[position + 4:position + 8])[0]
            self.read_track(data, position + 8, position + 8 + length, track)
            position += 8 + length
        self.tempos.sort()
        if not self.tempos or self.tempos[0][0] > 0:
            self.tempos.insert(0, (0, 500000))
        self.notes.sort()

    def read_track(self, data, position, end, track):
        tick = 0
        status = 0
        open_notes = {}
        while position < end:
            delta, position = read_vlq(data, position)
            tick += delta
            byte = data[position]
            if byte == 0xFF:
                kind = data[position + 1]
                length, position = read_vlq(data, position + 2)
                payload = data[position:position + length]
                position += length
                if kind == 0x51:
                    self.tempos.append((tick, int.from_bytes(payload, 'big')))
                elif kind == 3 and payload.strip():
                    self.names[track] = payload.decode('latin1', 'replace').strip()
                continue
            if byte in (0xF0, 0xF7):
                length, position = read_vlq(data, position + 1)
                position += length
                continue
            if byte >= 0x80:
                status = byte
                position += 1
            kind, channel = status & 0xF0, status & 15
            if kind in (0xC0, 0xD0):
                if kind == 0xC0:
                    self.programs.setdefault((track, channel), data[position])
                position += 1
                continue
            first, second = data[position], data[position + 1]
            position += 2
            if kind == 0x90 and second:
                key = (channel, first)
                if key in open_notes:
                    self.close(open_notes.pop(key), tick)
                open_notes[key] = [tick, track, channel, first, second]
            elif kind == 0x80 or (kind == 0x90 and not second):
                key = (channel, first)
                if key in open_notes:
                    self.close(open_notes.pop(key), tick)
        for note in open_notes.values():
            self.close(note, tick)

    def close(self, note, end_tick):
        start, track, channel, pitch, velocity = note
        if end_tick > start:
            self.notes.append((start, end_tick, track, channel, pitch, velocity))

    def tick_to_ms(self):
        """Return a function mapping ticks to integer milliseconds using the tempo map."""
        segments = []
        elapsed = 0.0
        for i, (tick, tempo) in enumerate(self.tempos):
            segments.append((tick, elapsed, tempo))
            next_tick = self.tempos[i + 1][0] if i + 1 < len(self.tempos) else None
            if next_tick is not None:
                elapsed += (next_tick - tick) * tempo / (1000.0 * self.division)

        def convert(tick):
            start, base, tempo = segments[0]
            for segment in segments:
                if segment[0] <= tick:
                    start, base, tempo = segment
            return int(round(base + (tick - start) * tempo / (1000.0 * self.division)))
        return convert

    def summary(self):
        lines = [f'format {self.format}, division {self.division} ticks/quarter, '
                 f'{len(self.tempos)} tempo events, {len(self.notes)} notes']
        counts = collections.Counter((n[2], n[3]) for n in self.notes)
        lows = {}
        highs = {}
        for n in self.notes:
            key = (n[2], n[3])
            lows[key] = min(lows.get(key, 127), n[4])
            highs[key] = max(highs.get(key, 0), n[4])
        for (track, channel), count in sorted(counts.items()):
            program = self.programs.get((track, channel), '-')
            name = self.names.get(track, '')
            drum = ' (percussion)' if channel == 9 else ''
            lines.append(f'  track {track} (t{track}) channel {channel} (c{channel}): {count} notes, '
                         f'range {lows[(track, channel)]}..{highs[(track, channel)]}, program {program}{drum} {name}')
        return '\n'.join(lines)


def parse_voice(text):
    """CH=SOURCE:POLICY where SOURCE is tN or cN, optionally joined with + (e.g. t1+t5)."""
    try:
        channel, rest = text.split('=')
        source, policy = rest.split(':') if ':' in rest else (rest, 'high')
        channel = int(channel)
        parts = tuple(sorted((part[0], int(part[1:])) for part in source.split('+')))
        if not 0 <= channel <= 3 or policy not in ('high', 'low') or any(kind not in 'tc' for kind, _ in parts):
            raise ValueError
        return channel, parts, policy
    except ValueError:
        raise ValueError(f'Bad --voice {text!r}; expected CH=tN:high|low or CH=cN:high|low (sources may be joined with +)')


def allocate(midi, voices, transpose, min_note, max_note, gap, start_ms, end_ms):
    """Return score events and end time. Voices are (score channel, source, policy)."""
    convert = midi.tick_to_ms()
    sources = collections.OrderedDict()
    for channel, source, policy in voices:
        sources.setdefault(source, []).append((channel, policy))
    notes = []
    for start, end, track, channel, pitch, velocity in midi.notes:
        source = next((s for s in sources if ('t', track) in s or ('c', channel) in s), None)
        if source is None:
            continue
        if channel != 9:
            pitch += transpose
            while pitch < min_note:
                pitch += 12
            while pitch > max_note:
                pitch -= 12
        if not 0 <= pitch <= 127:
            continue
        a, b = convert(start) - start_ms, convert(end) - start_ms
        if end_ms and a >= end_ms - start_ms:
            continue
        if b <= 0:
            continue
        a = max(0, a)
        if end_ms:
            b = min(b, end_ms - start_ms)
        if b > a:
            notes.append((a, b, source, pitch, len(notes)))
    times = sorted({t for n in notes for t in (n[0], n[1])})
    if not times:
        raise ValueError('No notes selected; check --voice sources')
    events = []
    playing = {}  # score channel -> note id
    ends = {}  # note id -> end ms
    by_source = {s: [] for s in sources}
    for note in notes:
        by_source[note[2]].append(note)
    index = {s: 0 for s in sources}
    active = {s: [] for s in sources}
    for now in times:
        for source in sources:
            active[source] = [n for n in active[source] if n[1] > now]
            queue = by_source[source]
            while index[source] < len(queue) and queue[index[source]][0] <= now:
                note = queue[index[source]]
                if note[1] > now:
                    active[source].append(note)
                index[source] += 1
            remaining = list(active[source])
            for channel, policy in sources[source]:
                choice = None
                if remaining:
                    choice = max(remaining, key=lambda n: (n[3], n[4])) if policy == 'high' \
                        else min(remaining, key=lambda n: (n[3], -n[4]))
                    remaining.remove(choice)
                current = playing.get(channel)
                if choice is None:
                    if current is not None:
                        events.append((now, channel, None))
                        playing.pop(channel)
                elif current != choice[4]:
                    if current is not None and gap and ends[current] >= now:
                        events.append((now, channel, None))
                    events.append((now, channel, choice[3]))
                    playing[channel] = choice[4]
                    ends[choice[4]] = choice[1]
    end = times[-1]
    for channel in list(playing):
        events.append((end, channel, None))
    return shorten(events, gap), end


def shorten(events, gap):
    """Give repeated notes on a channel a short silence so they retrigger audibly."""
    events.sort(key=lambda e: (e[0], e[2] is not None))
    if not gap:
        return events
    result = []
    last_on = {}
    for i, (ms, channel, note) in enumerate(events):
        if note is not None:
            previous = last_on.get(channel)
            if previous is not None:
                on_index, on_ms = previous
                if ms - on_ms > gap * 2:
                    # Insert/advance the note-off so the next attack is separated.
                    off_ms = ms - gap
                    result = [e for e in result if not (e[0] >= off_ms and e[1] == channel and e[2] is None)]
                    result.append((off_ms, channel, None))
            last_on[channel] = (i, ms)
            result.append((ms, channel, note))
        else:
            if not any(e[1] == channel and e[2] is None and e[0] == ms for e in result[-8:]):
                result.append((ms, channel, None))
    result.sort(key=lambda e: (e[0], e[2] is not None))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('input')
    parser.add_argument('output', nargs='?', help='.h (C array) or .bin score; omit to print information')
    parser.add_argument('--voice', action='append', default=[], help='CH=tN|cN:high|low (repeatable)')
    parser.add_argument('--name', default='score')
    parser.add_argument('--loop', action='store_true', help='end with E0 (restart) instead of F0')
    parser.add_argument('--transpose', type=int, default=0, help='semitones added to every pitched note')
    parser.add_argument('--min-note', type=int, default=0, help='fold notes below this MIDI note up by octaves')
    parser.add_argument('--max-note', type=int, default=127, help='fold notes above this MIDI note down by octaves')
    parser.add_argument('--gap', type=int, default=10, help='ms of silence before a repeated attack (0 disables)')
    parser.add_argument('--start-ms', type=int, default=0)
    parser.add_argument('--end-ms', type=int, default=0)
    args = parser.parse_args()
    try:
        midi = Midi(Path(args.input).read_bytes())
        if not args.output:
            print(midi.summary())
            return
        voices = [parse_voice(v) for v in args.voice]
        if not voices:
            pitched = sorted({('c', n[3]) for n in midi.notes if n[3] != 9})
            if not pitched:
                raise ValueError('No pitched notes')
            everything = tuple(pitched)
            voices = [(0, everything, 'high'), (1, everything, 'high'), (2, everything, 'high'), (3, everything, 'low')]
            print('No --voice given: using all pitched notes on four channels (three high, one low)')
        if len({v[0] for v in voices}) != len(voices):
            raise ValueError('Each score channel may appear once in --voice')
        events, end = allocate(midi, voices, args.transpose, args.min_note, args.max_note,
                               args.gap, args.start_ms, args.end_ms)
        document = {'events': [{'ms': ms, 'channel': ch, 'note': note} for ms, ch, note in events], 'end_ms': end}
        data = encode(document, args.loop)
        write_score(args.output, data, args.name)
        result = validate(data)
        print(f'{args.output}: {result["bytes"]} bytes, {result["duration_ms"]} ms, '
              f'{result["note_events"]} note events, channels {result["channels"]}')
    except (ValueError, OSError, IndexError, struct.error) as error:
        parser.exit(1, f'Error: {error}\n')


if __name__ == '__main__':
    main()
