/*
 * Common.h - screen layout and the random number generator.
 *
 * THE LAYOUT, AND WHAT CHANGED FROM THE ARDUBOY VERSION
 * ----------------------------------------------------
 * The Arduboy was 128x64 and the well was 5 wide by 10 tall in 6 px
 * cells, tucked against the right of the screen with the score floating
 * in the empty left half.
 *
 * The CHGame panel is 128x128 - the same width, twice the height. That
 * doubling goes straight into the well: 15 rows instead of 10, in 8 px
 * cells instead of 6, so the playfield is 40x120 rather than 30x60. Four
 * times the area, and the cells are big enough to carry a bevel and a
 * black separator, which is what makes a colour block read as an object
 * instead of a rectangle.
 *
 * Centring the well leaves two 42 px columns, one either side. Seven
 * characters of the 5x7 font fit exactly in 42 px, which is what sizes
 * the word popups - "Wicked!" is seven characters and lands flush.
 *
 *      0        42        86       127
 *      +---------+---------+---------+
 *      |  BEST   |  frame  |  SCORE  |
 *      |         |#########|         |
 *      | words   |# well  #| points  |
 *      | float   |#  15   #| float   |
 *      | up here |# rows  #| up here |
 *      |         |#########|         |
 *      +---------+---------+---------+
 */
#pragma once

#include <CHGfx.h>

/* ------------------------------------------------------------------ */
/* Playfield geometry                                                  */
/* ------------------------------------------------------------------ */
#define BOARD_W   5
#define BOARD_H   15
#define CELL      8

#define PF_W      (BOARD_W * CELL)          /*  40 */
#define PF_H      (BOARD_H * CELL)          /* 120 */
#define PF_X      44                        /* interior left edge      */
#define PF_Y      4                         /* interior top edge       */
#define FRAME_T   2                         /* surround thickness      */

#define FRAME_X   (PF_X - FRAME_T)          /*  42 */
#define FRAME_Y   (PF_Y - FRAME_T)          /*   2 */
#define FRAME_W   (PF_W + FRAME_T * 2)      /*  44 */
#define FRAME_H   (PF_H + FRAME_T * 2)      /* 124 */

/* The two side columns. 42 px each = exactly seven 5x7 characters. */
#define COL_L_X   0
#define COL_L_W   FRAME_X                   /*  42 */
#define COL_R_X   (FRAME_X + FRAME_W)       /*  86 */
#define COL_R_W   (GFX_W - COL_R_X)         /*  42 */

#define CELL_X(col) (PF_X + (col) * CELL)
#define CELL_Y(row) (PF_Y + (row) * CELL)

/* ------------------------------------------------------------------ */
/* Random                                                              */
/* ------------------------------------------------------------------ */
/*
 * xorshift32. The Arduino random() here is a full rand_r plus a modulo
 * reduction, and the particle emitters call it a few hundred times in
 * the frame a row clears - which is exactly the frame that has the least
 * headroom left. This is four instructions and no worse for confetti.
 */
static uint32_t rngState = 0x2545F491u;

static inline uint32_t rnd32(void)
{
    uint32_t x = rngState;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return rngState = x;
}

static inline uint8_t rnd8(void)            { return (uint8_t)(rnd32() >> 24); }

/* [0, n) */
static inline int rndN(int n)               { return (int)((rnd32() >> 8) % (uint32_t)n); }

/* [lo, hi) */
static inline int rndR(int lo, int hi)      { return lo + rndN(hi - lo); }
