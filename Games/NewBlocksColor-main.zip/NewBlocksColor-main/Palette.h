/*
 * Palette.h - the sixteen slots the framebuffer can hold, and the slow
 *             hue drift that walks all of them around the colour wheel.
 *
 * CHGfx keeps a 4 bpp framebuffer, so everything drawn with the normal
 * library calls is one of sixteen palette indices. That is not the
 * limitation it sounds like, because we never call gfx_setPalette() and
 * never call gfx_flush(): the composite pass in Plasma.h reads `pal[]`
 * itself, at full RGB565, and rebuilds it from scratch every frame.
 *
 * So the sixteen slots are sixteen *roles*, not sixteen fixed colours.
 * Advance `baseHue` by a fraction of a degree per frame and every block,
 * spark, frame edge and glyph on screen rotates through the spectrum
 * together, in lockstep, for free. That is the whole trick.
 *
 * INDEX 0 IS SPECIAL. It is not a colour, it is a hole: the composite
 * pass shows the plasma wherever the framebuffer nibble is zero. Never
 * draw with it, only clear to it.
 *
 * WHY FIVE BLOCK HUES AND NOT SIX
 * -------------------------------
 * Every block carries a specular glint, and a glint that is a shared
 * near-white reads as a smudge of somebody else's colour sitting on the
 * corner of the block. A glint that is a lighter tone of the block's own
 * hue reads as light falling on a coloured solid.
 *
 * That means each hue needs a twin, and ten of the sixteen slots go to
 * five hue/tint pairs. The layout below is what is left over, and it is
 * exact - there are no spare slots. Six hues would need twelve, and the
 * things that got cut to find those two slots (an opaque black, a white,
 * a frame colour, a text colour) are all load-bearing.
 *
 * The twin is the same hue at s=80 rather than a brighter value: the
 * fill is already at v=255, so the only direction left is toward white.
 *
 * The five hues sit 51 units apart, which is still far enough that two
 * stacked blocks never read as the same colour.
 */
#pragma once

#include <CHGfx.h>

enum : uint8_t {
    C_CLEAR = 0,    /* stencil hole - the plasma shows through here     */
    C_INK   = 1,    /* opaque black: gutters, outlines, banners         */
    C_BLK0  = 2,    /* 2..6,  five rotating block hues                  */
    C_LIT0  = 7,    /* 7..11, the same five lightened - glints, sparks  */
    C_WHITE = 12,
    C_FRAME = 13,   /* playfield surround, complementary to the blocks  */
    C_TEXT  = 14,
    C_GHOST = 15    /* dim tint: grid dots, smear trails, dying sparks  */
};

#define BLOCK_HUES 5
#define HUE_STEP   (256 / BLOCK_HUES)          /* 51 */

/* The lightened twin of a block colour index. */
#define C_LIT(blk) ((uint8_t)((blk) + BLOCK_HUES))

extern uint16_t pal[16];

/*
 * DISPLAY TEXT BORROWS THE BLOCK SLOTS
 * ------------------------------------
 * The title and the game over word want a rainbow across their letters:
 * each character one step further round the wheel than the one before,
 * the whole run drifting with baseHue exactly as the blocks do. Five
 * block hues 51 apart are too coarse a step for that, and there are no
 * spare slots. But when those words are on screen there are no blocks:
 * the title has an empty screen behind it and the stack has been
 * demolished before the banner opens. So while `textGradient` is set,
 * the ten block/tint slots (2..11) become a ten-step hue ramp from
 * baseHue, TEXT_HUE_STEP apart, at full saturation. Letter i is drawn in
 * slot 2 + i. The only thing that shares those slots at the time is the
 * last of the game over confetti, which simply lands in ramp colours.
 */
#define TEXT_HUE_STEP 24
static uint8_t textGradient;

/*
 * HSV -> RGB565, integer only. The 1/43 is 6/256 rearranged so the
 * sextant and the position inside it come out of one divide that the
 * compiler turns into a multiply-high. Called ~270 times a frame (16
 * palette slots plus the 256-entry plasma ramp) and still well under 1%
 * of the frame, so there is no reason to make it a table.
 */
static inline uint16_t hsv565(uint8_t h, uint8_t s, uint8_t v)
{
    uint8_t region = (uint8_t)(h / 43);
    uint8_t rem    = (uint8_t)((h - region * 43) * 6);

    uint8_t p = (uint8_t)((v * (255 - s)) >> 8);
    uint8_t q = (uint8_t)((v * (255 - ((s * rem) >> 8))) >> 8);
    uint8_t t = (uint8_t)((v * (255 - ((s * (255 - rem)) >> 8))) >> 8);

    uint8_t r, g, b;
    switch (region) {
        case 0:  r = v; g = t; b = p; break;
        case 1:  r = q; g = v; b = p; break;
        case 2:  r = p; g = v; b = t; break;
        case 3:  r = p; g = q; b = v; break;
        case 4:  r = t; g = p; b = v; break;
        default: r = v; g = p; b = q; break;
    }
    return gfx_rgb(r, g, b);
}

/* The wheel position of block hue `i` right now. The plasma uses this to
 * tint itself to match whichever piece is falling. */
static inline uint8_t blockHueAngle(uint8_t baseHue, uint8_t i)
{
    return (uint8_t)(baseHue + i * HUE_STEP);
}

/*
 * Rebuild all sixteen slots for this frame.
 *
 * `baseHue` walks slowly; `pulse` is a 0..255 breathing value that only
 * touches brightness, so the frame edge throbs without changing colour
 * out from under the blocks it surrounds.
 */
static inline void paletteUpdate(uint8_t baseHue, uint8_t plasmaHue, uint8_t pulse)
{
    pal[C_CLEAR] = 0x0000;
    pal[C_INK]   = 0x0000;

    if (textGradient) {
        for (uint8_t i = 0; i < 2 * BLOCK_HUES; i++)
            pal[C_BLK0 + i] = hsv565((uint8_t)(baseHue + i * TEXT_HUE_STEP), 255, 255);
    } else {
        for (uint8_t i = 0; i < BLOCK_HUES; i++) {
            const uint8_t h = blockHueAngle(baseHue, i);
            pal[C_BLK0 + i] = hsv565(h, 255, 255);   /* the fill            */
            pal[C_LIT0 + i] = hsv565(h,  80, 255);   /* its lightened twin  */
        }
    }

    pal[C_WHITE] = 0xFFFF;

    /*
     * The frame and the score are keyed to the PLASMA hue, not to
     * baseHue, and that is not a detail. The plasma now tints itself to
     * whichever piece is falling, so a frame set opposite baseHue drifts
     * into agreement with the background every time the falling piece
     * happens to sit near baseHue + 128 - and a neon frame the same
     * colour as what is behind it stops being a frame. Keyed opposite
     * the plasma instead, both stay in contrast with the background no
     * matter where the background has wandered to.
     */
    pal[C_FRAME] = hsv565((uint8_t)(plasmaHue + 128), 255, (uint8_t)(180 + (pulse >> 2)));
    pal[C_TEXT]  = hsv565((uint8_t)(plasmaHue + 160), 150, 255);

    /* The grid dots and smear trails live inside the well, where the
     * plasma is down to an eighth, so they are legible against anything
     * and can keep drifting on their own. */
    pal[C_GHOST] = hsv565(baseHue, 210, 110);
}
