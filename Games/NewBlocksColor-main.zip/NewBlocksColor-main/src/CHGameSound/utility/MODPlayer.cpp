#include "MODPlayer.h"
#include <string.h>

namespace chgame { namespace detail {
namespace {
uint16_t be16(const uint8_t *p) { return uint16_t(p[0])*256+p[1]; }
const uint32_t fineScale[16]={65536,66011,66489,66971,67456,67945,68437,68933,61858,62306,62757,63212,63670,64132,64596,65064};
const uint16_t semitoneScale[16]={4096,4340,4598,4871,5161,5468,5793,6137,6502,6889,7298,7732,8192,8679,9195,9742};
const int8_t sine[32]={0,25,49,71,90,106,117,125,127,125,117,106,90,71,49,25,0,-25,-49,-71,-90,-106,-117,-125,-127,-125,-117,-106,-90,-71,-49,-25};
uint16_t clampPeriod(int period) { return uint16_t(period<28 ? 28 : period>4095 ? 4095 : period); }
}
bool MODPlayer::supported(uint8_t fx,uint8_t p) {
    if (fx==7) return false; // Tremolo not implemented; fail rather than guess.
    if (fx!=14) return true;
    switch (p>>4) {
    case 0: case 1: case 2: case 5: case 6: case 8: case 9: case 10: case 11: case 12: case 13: case 14: return true;
    default: return false;
    }
}
bool MODPlayer::load(const uint8_t *data,size_t bytes,bool loop) {
    playing_=false; error_=MODError::None;
    if (!data || bytes<1084) return fail(MODError::Truncated);
    if (memcmp(data+1080,"M.K.",4) && memcmp(data+1080,"M!K!",4) && memcmp(data+1080,"4CHN",4)) return fail(MODError::Signature);
    uint8_t length=data[950];
    if (!length || length>128) return fail(MODError::Order);
    uint8_t patterns=0;
    // All 128 entries contribute to pattern storage in the classic MOD layout.
    for (unsigned i=0;i<128;++i) {
        if (data[952+i]>127) return fail(MODError::Order);
        if (data[952+i]+1>patterns) patterns=data[952+i]+1;
    }
    size_t sampleOffset=1084+size_t(patterns)*1024;
    if (sampleOffset>bytes) return fail(MODError::Truncated);
    // Inspect every pattern before starting: unsupported effects cannot turn
    // into surprise wrong playback, and sample/note indices cannot escape bounds.
    for (size_t p=1084;p<sampleOffset;p+=4) {
        uint8_t instrument=(data[p]&0xf0)|(data[p+2]>>4);
        uint16_t period=uint16_t(data[p]&15)*256+data[p+1];
        if (instrument>31) return fail(MODError::Sample);
        if (period && period<28) return fail(MODError::Note);
        uint8_t fx=data[p+2]&15, value=data[p+3];
        if (!supported(fx,value)) return fail(MODError::UnsupportedEffect);
        if (fx==13 && ((value&15)>9 || value>>4>6 || (value>>4)*10+(value&15)>63)) return fail(MODError::Order);
    }
    for (unsigned i=0;i<31;++i) {
        const uint8_t *h=data+20+i*30;
        Instrument &s=instruments_[i];
        s.length=uint32_t(be16(h+22))*2;
        s.loopStart=uint32_t(be16(h+26))*2;
        s.loopLength=uint32_t(be16(h+28))*2;
        s.volume=h[25];
        if (h[24]>15 || s.volume>64) return fail(MODError::Sample);
        s.fine=h[24]<8 ? h[24] : int8_t(h[24])-16;
        if (s.loopLength<=2) { s.loopStart=0; s.loopLength=0; }
        if (s.loopLength && (s.loopStart>s.length || s.loopLength>s.length-s.loopStart)) return fail(MODError::Sample);
        if (s.length>bytes-sampleOffset) return fail(MODError::Truncated);
        s.offset=uint32_t(sampleOffset); sampleOffset+=s.length;
    }
    data_=data; length_=length; patterns_=patterns; loop_=loop;
    order_=row_=tick_=delay_=0; speed_=6; bpm_=125; tickClock_=0;
    jump_=break_=loopRow_=-1; gain_=256;
    for (auto &c:channels_) c=Channel();
    playing_=true;
    readRow();
    return true;
}
void MODPlayer::pitch(Channel &c,uint16_t period) {
    if (!period) { c.step=0; return; }
    // PAL Amiga sample clock / period, with signed 1/8-semitone finetune.
    c.step=uint32_t((uint64_t(3546895)*fineScale[uint8_t(c.fine)&15])/(uint32_t(period)*32000));
}
void MODPlayer::trigger(Channel &c,uint16_t period,uint32_t offset) {
    c.period=period; c.position=offset; c.fraction=0;
    c.playingSample=c.instrument;
    c.active=c.playingSample && instruments_[c.playingSample-1].length>offset;
    c.vibratoPhase=0;
    pitch(c,period);
}
void MODPlayer::slideVolume(Channel &c,uint8_t value) {
    int v=int(c.volume)+(value>>4 ? value>>4 : -int(value&15));
    c.volume=uint8_t(v<0?0:v>64?64:v);
}
void MODPlayer::portamento(Channel &c) {
    if (!c.target || !c.period) return;
    if (c.period<c.target) c.period=uint16_t(c.period+c.porta>c.target ? c.target : c.period+c.porta);
    else if (c.period>c.target) c.period=uint16_t(int(c.period)-c.porta<int(c.target) ? c.target : c.period-c.porta);
    pitch(c,c.period);
}
void MODPlayer::vibrato(Channel &c) {
    int delta=int(sine[c.vibratoPhase>>3])*c.vibratoDepth/64;
    pitch(c,clampPeriod(int(c.period)+delta));
    c.vibratoPhase+=c.vibratoSpeed*4;
}
void MODPlayer::readRow() {
    const uint8_t *row=data_+1084+size_t(data_[952+order_])*1024+row_*16;
    for (unsigned i=0;i<4;++i) {
        Channel &c=channels_[i]; const uint8_t *cell=row+i*4;
        uint8_t instrument=(cell[0]&0xf0)|(cell[2]>>4);
        uint16_t period=uint16_t(cell[0]&15)*256+cell[1];
        c.effect=cell[2]&15; c.param=cell[3]; c.delayedPeriod=0;
        uint8_t fx=c.effect,p=c.param,x=p&15;
        if (instrument) {
            c.instrument=instrument; c.volume=instruments_[instrument-1].volume;
            c.fine=instruments_[instrument-1].fine;
        }
        if (fx==9 && p) c.offset=p;
        if (fx==3 && p) c.porta=p;
        if (fx==4) { if (p>>4) c.vibratoSpeed=p>>4; if (x) c.vibratoDepth=x; }
        if (fx==14 && p>>4==5) c.fine=x<8?x:int8_t(x)-16;
        if (period) {
            if (fx==3 || fx==5) c.target=period;
            else if (fx==14 && p>>4==13 && x) c.delayedPeriod=period;
            else trigger(c,period,fx==9 ? uint32_t(c.offset)*256 : 0);
        }
        pitch(c,c.period); // End modulation from the preceding row.
        switch (fx) {
        case 11: jump_=p; break;
        case 12: c.volume=p>64?64:p; break;
        case 13: break_=(p>>4)*10+x; break;
        case 15:
            if (!p) { playing_=false; return; }
            if (p<32) speed_=p; else bpm_=p;
            break;
        case 14:
            switch (p>>4) {
            case 1: c.period=clampPeriod(int(c.period)-x); pitch(c,c.period); break;
            case 2: c.period=clampPeriod(int(c.period)+x); pitch(c,c.period); break;
            case 6:
                if (!x) c.loopRow=row_;
                else {
                    if (!c.loopCount) { c.loopCount=x; loopRow_=c.loopRow; }
                    else if (--c.loopCount) loopRow_=c.loopRow;
                }
                break;
            case 10: slideVolume(c,x<<4); break;
            case 11: slideVolume(c,x); break;
            case 12: if (!x) c.volume=0; break;
            case 14: delay_=x; break;
            default: break; // E0 filter and E8 panning have no mono implementation.
            }
            break;
        default: break;
        }
    }
}
void MODPlayer::nextTick() {
    if (++tick_>=speed_) {
        tick_=0;
        if (delay_) { --delay_; return; }
        if (jump_>=0 || break_>=0) {
            order_=uint8_t(jump_>=0 ? jump_ : order_+1);
            row_=uint8_t(break_>=0 ? break_ : 0);
        } else if (loopRow_>=0) row_=uint8_t(loopRow_);
        else if (++row_>=64) { row_=0; ++order_; }
        jump_=break_=loopRow_=-1;
        if (order_>=length_) {
            if (!loop_) { playing_=false; return; }
            order_=0; row_=0;
        }
        readRow();
        return;
    }
    for (auto &c:channels_) {
        uint8_t p=c.param,x=p&15;
        switch (c.effect) {
        case 0:
            if (p && c.period) {
                uint8_t semitone=tick_%3==1 ? p>>4 : tick_%3==2 ? x : 0;
                pitch(c,uint16_t(uint32_t(c.period)*4096/semitoneScale[semitone]));
            }
            break;
        case 1: c.period=clampPeriod(int(c.period)-p); pitch(c,c.period); break;
        case 2: c.period=clampPeriod(int(c.period)+p); pitch(c,c.period); break;
        case 3: portamento(c); break;
        case 4: vibrato(c); break;
        case 5: portamento(c); slideVolume(c,p); break;
        case 6: vibrato(c); slideVolume(c,p); break;
        case 10: slideVolume(c,p); break;
        case 14:
            if (p>>4==9 && x && tick_%x==0 && c.period) trigger(c,c.period);
            if (p>>4==12 && tick_==x) c.volume=0;
            if (p>>4==13 && tick_==x && c.delayedPeriod) trigger(c,c.delayedPeriod);
            break;
        default: break;
        }
    }
}
uint8_t MODPlayer::activeChannels() const {
    uint8_t n=0; for (const auto &c:channels_) if (c.active && c.volume) ++n; return n;
}
int16_t MODPlayer::sample() {
    if (!playing_) return 0;
    int32_t sum=0;
    for (auto &c:channels_) {
        if (!c.active) continue;
        const Instrument &s=instruments_[c.playingSample-1];
        uint32_t end=s.loopLength ? s.loopStart+s.loopLength : s.length;
        if (c.position>=end) {
            if (s.loopLength) c.position=s.loopStart+(c.position-s.loopStart)%s.loopLength;
            else { c.active=false; continue; }
        }
        uint32_t next=c.position+1;
        if (next>=end) next=s.loopLength ? s.loopStart : c.position;
        int32_t a=int8_t(data_[s.offset+c.position]),b=int8_t(data_[s.offset+next]);
        int32_t value=a+(b-a)*int32_t(c.fraction)/65536;
        sum+=value*c.volume; // Four voices at volume 64 fill signed 16-bit range.
        uint32_t advance=uint32_t(c.fraction)+c.step;
        c.position+=advance>>16; c.fraction=uint16_t(advance);
    }
    tickClock_+=uint32_t(bpm_)*2;
    if (tickClock_>=160000) { tickClock_-=160000; nextTick(); }
    sum=sum*gain_/256;
    if (sum>32767) sum=32767; if (sum<-32768) sum=-32768;
    return int16_t(sum);
}
} }
