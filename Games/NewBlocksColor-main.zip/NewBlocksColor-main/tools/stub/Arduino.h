/* Desktop stand-in for the Arduino core header that Music.h includes. */
#pragma once
#include <stdint.h>
#include <stddef.h>
#ifndef PROGMEM
#define PROGMEM
#endif
