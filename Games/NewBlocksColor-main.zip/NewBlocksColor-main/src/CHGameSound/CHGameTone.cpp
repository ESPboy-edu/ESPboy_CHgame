#include <Arduino.h>
#include "CHGameTone.h"
#include "utility/Hardware.h"
using namespace chgame::detail;
bool CHGameTone::begin() {
    Critical lock;
    if (SystemCoreClock != 48000000u || !claim(this)) return false;
    initPinTimer();
    sounding_ = false;
    return true;
}
void CHGameTone::end() { Critical lock; releaseHardware(this); sounding_ = false; }
void CHGameTone::tone(uint16_t hz, uint32_t durationMs) {
    Critical lock;
    if (!owns(this)) return;
    hardwareTone(hz);
    sounding_ = hz != 0;
    started_ = millis();
    duration_ = durationMs;
}
void CHGameTone::noTone() { tone(0); }
void CHGameTone::update() {
    if (sounding_ && duration_ && uint32_t(millis() - started_) >= duration_) noTone();
}
