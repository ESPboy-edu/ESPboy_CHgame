/*
 * preview_sound.cpp - hear the game's music and effects on a desktop.
 *
 * Runs the very same CHGameSound engine the board runs, fed the sketch's
 * own Music.h and Sfx.h, and writes what the Lead output would put on the
 * piezo as a mono 32 kHz WAV: one square wave, retuned every millisecond,
 * effects taking over from the music by the same rank rules as Sound.h.
 * It is an ideal rendering - no piezo resonance, no enclosure - but the
 * timing, the ducking and the pitches are exactly the device's.
 *
 * Build from the sketch folder with any C++14 compiler (g++, clang++, or
 * `zig c++`):
 *
 *   g++ -std=c++14 -O2 -Itools/stub -I. \
 *       src/CHGameSound/utility/Engine.cpp tools/preview_sound.cpp -o tools/preview_sound
 *
 *   tools/preview_sound demo demo.wav        a scripted half-minute of play
 *   tools/preview_sound catalog catalog.wav  every effect on its own, in order
 */
#include "src/CHGameSound/CHGameSound.h"
#include "Music.h"
#include "Sfx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <vector>

using namespace chgame;
using namespace chgame::detail;

/* ---- Sound.h's rank rules, on a bare engine ------------------------------- */
enum : uint8_t { SP_CLICK, SP_BLIP, SP_PIECE, SP_DROP, SP_PHRASE };
static Engine engine;
static uint8_t rank;
static Step buf[24];

static void start(const Step *steps, size_t n, uint8_t r)
{
    if (!(r >= rank || !engine.effectPlaying())) return;
    rank = r;
    engine.playEffect(steps, n, false);
}
template <size_t N> static void start(const Step (&s)[N], uint8_t r) { start(s, N, r); }
template <size_t N> static void startScaled(const Step (&s)[N], uint16_t scale, uint8_t r)
{
    if (!(r >= rank || !engine.effectPlaying())) return;
    engine.stopEffect();
    for (size_t i = 0; i < N && i < 24; i++) { buf[i] = s[i]; buf[i].hz = uint16_t((uint32_t(s[i].hz) * scale) >> 8); }
    rank = r;
    engine.playEffect(buf, N < 24 ? N : 24, false);
}

static uint16_t settleHz(int row) { return uint16_t(587 + (14 - row) * 30); }
static void tone(uint16_t hz, uint16_t ms, uint8_t r)
{
    if (!(r >= rank || !engine.effectPlaying())) return;
    engine.stopEffect();
    buf[0] = { hz, 0, ms, Preset::Beep, 255 };
    rank = r;
    engine.playEffect(buf, 1, false);
}
static void drop(int row)
{
    if (!(SP_DROP >= rank || !engine.effectPlaying())) return;
    engine.stopEffect();
    const size_t n = sizeof SFX_DROP / sizeof SFX_DROP[0];
    for (size_t i = 0; i < n; i++) buf[i] = SFX_DROP[i];
    buf[n] = { settleHz(row), 0, 45, Preset::Beep, 255 };
    rank = SP_DROP;
    engine.playEffect(buf, n + 1, false);
}

/* ---- A timeline ------------------------------------------------------------ */
enum Action { MUSIC, STOP, MOVE, TICK, SETTLE, LAND, DROP, CLEAR, TITLE, GO, OVER, SHATTER, BANNER, END };
struct Event { uint32_t ms; Action action; int arg; };
static std::vector<Event> timeline;
static void at(uint32_t ms, Action a, int arg = 0) { timeline.push_back({ ms, a, arg }); }

/* A piece falling for `rows` rows, moved twice, ending however the caller
 * says. Returns the end time. */
static uint32_t piece(uint32_t t, int rows, Action ending, int row, bool hardDrop = false)
{
    const uint32_t step = 240;
    at(t + 90, MOVE); at(t + 210, MOVE);
    for (int i = 0; i < rows; i++) at(t + step * (i + 1), TICK);
    t += step * rows + 60;
    if (hardDrop) at(t, DROP, row);
    at(t + (hardDrop ? 1 : 0), ending, row);
    return t + 320;
}

static void demo()
{
    uint32_t t = 0;
    at(300, MUSIC);                  /* the title's music... */
    at(4400, STOP); at(4400, TITLE); /* ...until a button is pressed */
    at(5050, GO);
    t = 5400;
    t = piece(t, 5, LAND, 14);
    t = piece(t, 4, SETTLE, 13);
    t = piece(t, 3, LAND, 14, true);
    t = piece(t, 5, SETTLE, 12);
    t = piece(t, 2, SETTLE, 11, true);
    /* A row goes. */
    t = piece(t, 4, LAND, 14);
    at(t - 300, CLEAR);
    t += 1400;
    t = piece(t, 4, SETTLE, 10);
    t = piece(t, 1, SETTLE, 5, true);
    t = piece(t, 3, SETTLE, 3);
    /* Topping out: the run down, a beat, fifteen rows of crackle, the rumble. */
    at(t, SETTLE, 0); at(t + 1, OVER);
    t += 360;
    for (int row = 14; row >= 0; row--) at(t + (14 - row) * 37, SHATTER, row);
    t += 15 * 37 + 100;
    at(t + 100, BANNER);
    at(t + 1500, END);
}

static void catalog()
{
    uint32_t t = 200;
    Action order[] = { MOVE, TICK, SETTLE, SETTLE, LAND, DROP, DROP, CLEAR, TITLE, GO, OVER, SHATTER, SHATTER, SHATTER, BANNER };
    int args[]     = { 0,    0,    14,     2,      0,    13,   2,    0,     0,     0,  0,    14,      7,       0,       0 };
    for (size_t i = 0; i < sizeof order / sizeof order[0]; i++) { at(t, order[i], args[i]); t += 800; }
    at(t + 400, END);
}

int main(int argc, char **argv)
{
    if (argc < 3) { fprintf(stderr, "usage: preview_sound demo|catalog out.wav\n"); return 2; }
    if (!strcmp(argv[1], "demo")) demo(); else catalog();
    engine.reset(Output::Lead);

    FILE *out = fopen(argv[2], "wb");
    if (!out) { perror(argv[2]); return 1; }
    std::vector<int16_t> pcm;
    uint32_t phase = 0; uint16_t oldHz = 0;
    size_t next = 0;
    for (uint32_t ms = 0; ; ms++) {
        bool done = false;
        while (next < timeline.size() && timeline[next].ms <= ms) {
            const Event &e = timeline[next++];
            switch (e.action) {
            case MUSIC:   engine.playScore(music, sizeof music); break;
            case STOP:    engine.stopScore(); break;
            case MOVE:    start(SFX_MOVE, SP_BLIP); break;
            case TICK:    start(SFX_TICK, SP_CLICK); break;
            case SETTLE:  tone(settleHz(e.arg), 45, SP_PIECE); break;
            case LAND:    start(SFX_LAND, SP_PIECE); break;
            case DROP:    drop(e.arg); break;
            case CLEAR:   start(SFX_CLEAR, SP_PHRASE); break;
            case TITLE:   start(SFX_TITLE, SP_PHRASE); break;
            case GO:      start(SFX_GO, SP_PHRASE); break;
            case OVER:    engine.stopScore(); start(SFX_OVER, SP_PHRASE); break;
            case SHATTER: startScaled(SFX_SHATTER, SFX_SHATTER_ROW[e.arg], SP_DROP); break;
            case BANNER:  start(SFX_BANNER, SP_PHRASE); break;
            case END:     done = true; break;
            }
        }
        if (done) break;
        /* One millisecond of the Lead output: the timer's square wave at
         * whatever the engine says, restarted on a pitch change as the
         * hardware does. */
        uint16_t hz = engine.loudFrequency();
        if (hz != oldHz) { phase = 0; oldHz = hz; }
        for (unsigned i = 0; i < Engine::SampleRate / 1000; i++) {
            phase += uint32_t((uint64_t(hz) << 32) / Engine::SampleRate);
            pcm.push_back(hz ? ((phase >> 31) ? -20000 : 20000) : 0);
        }
        engine.tick();
        if (engine.error() != ScoreError::None) { fprintf(stderr, "score error %u\n", unsigned(engine.error())); return 1; }
    }

    auto u16 = [&](uint32_t n) { fputc(n & 255, out); fputc((n >> 8) & 255, out); };
    auto u32 = [&](uint32_t n) { u16(n & 0xffff); u16(n >> 16); };
    uint32_t bytes = uint32_t(pcm.size() * 2);
    fwrite("RIFF", 1, 4, out); u32(36 + bytes); fwrite("WAVEfmt ", 1, 8, out);
    u32(16); u16(1); u16(1); u32(Engine::SampleRate); u32(Engine::SampleRate * 2); u16(2); u16(16);
    fwrite("data", 1, 4, out); u32(bytes);
    for (int16_t s : pcm) u16(uint16_t(s));
    fclose(out);
    printf("%s: %.1f s\n", argv[2], pcm.size() / double(Engine::SampleRate));
    return 0;
}
