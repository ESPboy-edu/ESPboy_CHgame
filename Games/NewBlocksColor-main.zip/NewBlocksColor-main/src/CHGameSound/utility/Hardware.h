#pragma once
#include <stdint.h>
#if !defined(CH32X035)
#error "CHGameSound requires the CHGame CH32X035 board package. Select Board: CHGame."
#endif
#include <ch32x035.h>

namespace chgame { namespace detail {
// CSR 0x800 is WCH's user-accessible interrupt control alias. Restore the exact
// previous state, including when called from an ISR or an outer critical section.
class Critical {
    uint32_t saved_;
public:
    Critical() { asm volatile("csrrc %0, 0x800, %1" : "=r"(saved_) : "r"(0x88u) : "memory"); }
    ~Critical() { asm volatile("csrw 0x800, %0" :: "r"(saved_) : "memory"); }
};
bool claim(const void *owner);
bool owns(const void *owner);
void releaseHardware(const void *owner);
void initPinTimer();
void hardwareTone(uint16_t hz);
void hardwareSilence();
} }
