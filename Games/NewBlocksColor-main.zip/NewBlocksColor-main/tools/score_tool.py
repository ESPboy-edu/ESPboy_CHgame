#!/usr/bin/env python3
"""Validate Playtune or encode timestamped JSON events. Standard library only."""
import argparse
import json
from pathlib import Path
import re


def read_score(path):
    path = Path(path)
    if path.suffix.lower() in ('.bin', '.pt'):
        return path.read_bytes()
    text = re.sub(r'/\*.*?\*/|//[^\n]*', '', path.read_text(), flags=re.S)
    arrays = re.findall(r'\{([^{}]*)\}', text)
    if len(arrays) != 1:
        raise ValueError('Header must contain exactly one byte array; use a raw .bin otherwise')
    values = []
    for token in arrays[0].split(','):
        token = token.strip()
        if not token:
            continue
        if not re.fullmatch(r'(?:0[xX][0-9a-fA-F]+|[0-9]+)', token):
            raise ValueError(f'Expected numeric byte, got {token!r}')
        values.append(int(token, 16 if token.lower().startswith('0x') else 10))
    return bytes(values)


def validate(data):
    position = elapsed = events = burst = max_burst = 0
    channels = set()
    initial_burst = None
    while position < len(data):
        offset = position
        op = data[position]
        position += 1
        burst += 1
        max_burst = max(max_burst, burst)
        if burst > 64:
            raise ValueError(f'Offset {offset}: exceeds 64-command interrupt budget')
        if op < 128:
            if position == len(data):
                raise ValueError(f'Offset {offset}: truncated wait')
            wait = op * 256 + data[position]
            position += 1
            elapsed += wait
            if wait:
                if initial_burst is None:
                    initial_burst = burst
                burst = 0
        elif op & 0xF0 in (0x80, 0x90):
            ch = op & 15
            if ch >= 4:
                raise ValueError(f'Offset {offset}: channel {ch} is outside 0..3')
            channels.add(ch)
            events += 1
            if op & 0xF0 == 0x90:
                if position == len(data):
                    raise ValueError(f'Offset {offset}: missing note')
                if data[position] > 127:
                    raise ValueError(f'Offset {position}: MIDI note outside 0..127')
                position += 1
        elif op in (0xE0, 0xF0):
            if position != len(data):
                raise ValueError(f'Offset {position}: unreachable bytes after terminator')
            if op == 0xE0:
                if not elapsed:
                    raise ValueError('Loop has no positive wait')
                if burst + initial_burst > 64:
                    raise ValueError('Commands across loop boundary exceed interrupt budget')
            return dict(bytes=len(data), duration_ms=elapsed, channels=sorted(channels),
                        note_events=events, loops=op == 0xE0, max_command_burst=max_burst)
        else:
            raise ValueError(f'Offset {offset}: unsupported opcode 0x{op:02x}')
    raise ValueError('Score has no F0/E0 terminator')


def encode(document, loop=False):
    events = document['events']
    output = bytearray()
    now = 0

    def wait_until(at):
        nonlocal now
        if type(at) is not int or at < now:
            raise ValueError('Event times must be ascending, nonnegative integer milliseconds')
        wait = at - now
        while wait:
            chunk = min(wait, 32767)
            output.extend((chunk >> 8, chunk & 255))
            wait -= chunk
        now = at

    used = set()
    for event in events:
        wait_until(event['ms'])
        ch = event['channel']
        if type(ch) is not int or not 0 <= ch <= 3:
            raise ValueError('channel must be 0..3')
        used.add(ch)
        note = event.get('note')
        if note is None:
            output.append(0x80 | ch)
        else:
            if type(note) is not int or not 0 <= note <= 127:
                raise ValueError('note must be 0..127 or null for note off')
            output.extend((0x90 | ch, note))
    wait_until(document.get('end_ms', now))
    # Explicit note-offs avoid tied notes accidentally carrying over an E0 loop.
    for ch in sorted(used):
        output.append(0x80 | ch)
    output.append(0xE0 if loop else 0xF0)
    validate(output)
    return bytes(output)


def write_score(path, data, name='score'):
    path = Path(path)
    if path.suffix.lower() in ('.bin', '.pt'):
        path.write_bytes(data)
    else:
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', name):
            raise ValueError('Invalid C array name')
        rows = ['  ' + ', '.join(f'0x{v:02x}' for v in data[i:i+16]) + ','
                for i in range(0, len(data), 16)]
        path.write_text('#pragma once\n#include <Arduino.h>\nconst uint8_t ' + name +
                        '[] PROGMEM = {\n' + '\n'.join(rows) + '\n};\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    check = sub.add_parser('check')
    check.add_argument('input')
    pack = sub.add_parser('encode')
    pack.add_argument('input')
    pack.add_argument('output')
    pack.add_argument('--loop', action='store_true')
    pack.add_argument('--name', default='score')
    convert = sub.add_parser('convert', help='Convert a numeric C byte array to/from raw binary')
    convert.add_argument('input')
    convert.add_argument('output')
    convert.add_argument('--name', default='score')
    args = parser.parse_args()
    try:
        if args.command == 'encode':
            data = encode(json.loads(Path(args.input).read_text()), args.loop)
        else:
            data = read_score(args.input)
        result = validate(data)
        if args.command != 'check':
            write_score(args.output, data, args.name)
        print(json.dumps(result, indent=2))
    except (ValueError, KeyError, TypeError, OSError) as error:
        parser.exit(1, f'Error: {error}\n')


if __name__ == '__main__':
    main()
