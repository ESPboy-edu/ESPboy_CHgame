#pragma once
#include <stddef.h>
#include <stdint.h>

namespace chgame {
enum class MODError : uint8_t { None, Truncated, Signature, Order, Sample, Note, UnsupportedEffect };
namespace detail {
// Memory-backed 4-channel/31-sample ProTracker MOD player. No heap/file I/O.
// All mutable access must be serialized with audio rendering by the caller.
class MODPlayer {
public:
    bool load(const uint8_t *data,size_t bytes,bool loop=false);
    void stop() { playing_=false; }
    bool playing() const { return playing_; }
    MODError error() const { return error_; }
    int16_t sample();
    uint8_t order() const { return order_; }
    uint8_t row() const { return row_; }
    uint8_t speed() const { return speed_; }
    uint8_t bpm() const { return bpm_; }
    uint8_t activeChannels() const;
    void gain(uint16_t q8) { gain_=q8>1024 ? 1024 : q8; }
private:
    struct Instrument {
        uint32_t offset=0, length=0, loopStart=0, loopLength=0;
        uint8_t volume=0;
        int8_t fine=0;
    } instruments_[31];
    struct Channel {
        uint32_t position=0, step=0;
        uint16_t fraction=0, period=0, target=0, delayedPeriod=0;
        uint8_t instrument=0, playingSample=0, volume=0, effect=0, param=0;
        uint8_t porta=0, vibratoSpeed=0, vibratoDepth=0, vibratoPhase=0, offset=0;
        uint8_t loopRow=0, loopCount=0;
        int8_t fine=0;
        bool active=false;
    } channels_[4];
    const uint8_t *data_=nullptr;
    uint8_t length_=0, patterns_=0, order_=0, row_=0, tick_=0, speed_=6, bpm_=125;
    int16_t jump_=-1, break_=-1, loopRow_=-1;
    uint8_t delay_=0;
    uint32_t tickClock_=0;
    uint16_t gain_=256;
    bool playing_=false, loop_=false;
    MODError error_=MODError::None;
    bool fail(MODError e) { playing_=false; error_=e; return false; }
    void readRow();
    void nextTick();
    void trigger(Channel &c,uint16_t period,uint32_t offset=0);
    static void pitch(Channel &c,uint16_t period);
    static void slideVolume(Channel &c,uint8_t value);
    static void portamento(Channel &c);
    static void vibrato(Channel &c);
    static bool supported(uint8_t fx,uint8_t param);
};
} }
