#pragma once
#include <stdint.h>
#include <stddef.h>

namespace chgame {
using PCMSource = int16_t (*)(void *context); // One signed mono sample at 32 kHz.
enum class Output : uint8_t { Arpeggio, Lead, Synth };
enum class Wave : uint8_t { Square, Pulse, Triangle, Saw, Noise, Sine, FM };
enum class Mix : uint8_t { Adaptive, Headroom, Drive };
enum class ScoreError : uint8_t { None, Truncated, InvalidCommand, InvalidNote, InvalidChannel, CommandBudget };
enum class Preset : uint8_t { Beep, Pluck, Bell, Bass, Laser, Noise, Robot, Soft };

struct Patch {
    Wave wave = Wave::Square;
    uint8_t volume = 255;
    uint8_t duty = 128;              // Pulse width, 1..254 (Synth only).
    uint16_t attackMs = 2;
    uint16_t decayMs = 0;
    uint8_t sustain = 255;
    uint16_t releaseMs = 5;
    uint8_t vibratoHz = 0;
    uint8_t vibratoDepth = 0;        // Depth in Hz, not cents.
    uint8_t fmRatio = 2;             // Integer modulator/carrier ratio, 1..8.
    uint8_t fmDepth = 64;            // Phase modulation depth, 0..255.
};
Patch preset(Preset which);

// Eight bytes per step. hz == 0 is a rest; endHz == 0 holds the starting pitch.
// durationMs must be nonzero. Arrays must remain alive while playing.
struct Step {
    uint16_t hz;
    uint16_t endHz;
    uint16_t durationMs;
    Preset sound;
    uint8_t volume;
};
static_assert(sizeof(Step)==8, "Effect steps must remain eight bytes");
}
