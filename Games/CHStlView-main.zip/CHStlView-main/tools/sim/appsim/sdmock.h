/* Host stand-in for CHStlView's SD library: a folder on the PC is the
 * card. Every file larger than 16 blocks is deliberately split into
 * several runs at scattered block addresses, so the viewer's fragment
 * handling is exercised on every open; a read that runs past the end of a
 * run is reported as a bug. Reads cost the virtual clock ~0.6 ms per
 * command plus ~0.17 ms per block, as measured on the device. */
#pragma once
#include <Arduino.h>
#include <memory>
#include <string>
#include <vector>

struct SimNode;

class File {
public:
    File() {}
    explicit File(std::shared_ptr<SimNode> n) : node(n) {}
    explicit operator bool() const { return (bool)node; }
    uint32_t size();
    int read(void *buf, uint16_t n);
    void close() { node.reset(); pos = 0; dirIndex = 0; }
    char *name();
    bool isDirectory();
    File openNextFile();
    void rewindDirectory() { dirIndex = 0; }
    uint8_t blockRuns(uint32_t *lba, uint32_t *blocks, uint8_t maxRuns);
private:
    std::shared_ptr<SimNode> node;
    uint32_t pos = 0;
    size_t dirIndex = 0;
};

class Sd2Card {
public:
    typedef void (*BlockFn)(const uint8_t *block, void *user);
    uint8_t readBlocksPipelined(uint32_t block, uint16_t count, uint8_t *buf0, uint8_t *buf1,
                                BlockFn fn, void *user);
};

class SDClass {
public:
    bool begin(uint8_t csPin);
    File open(const char *path);
    Sd2Card &rawCard() { return card; }
private:
    Sd2Card card;
};
extern SDClass SD;

/* Simulator side. */
void simSetCardRoot(const char *dir);
