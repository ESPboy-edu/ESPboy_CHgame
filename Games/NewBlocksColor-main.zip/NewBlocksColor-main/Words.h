/*
 * Words.h - the praise and the commiserations, unchanged from the
 *           Arduboy original.
 *
 * The PROGMEM / strcpy_P / pgm_read_word dance is gone. That existed
 * because the AVR is a Harvard machine where a pointer to flash and a
 * pointer to RAM are different kinds of thing and the compiler cannot
 * tell them apart. The CH32X035 is a RISC-V with one flat address space,
 * so a string literal already lives in flash, `const char *` already
 * points at it, and every byte of the copy-into-a-buffer machinery was
 * pure AVR tax. Same words, same order, no buffer.
 *
 * The leading spaces in the original were manual centring against a
 * fixed cursor position. They are gone too - the popup is centred by
 * measuring it, which also means longer words no longer overhang.
 */
#pragma once

static const char *const goodWords[] = {
    "Nice",   "Good",   "Cool",   "Sweet",  "Great",  "Rad",
    "Sick",   "Wicked", "Ace",    "Deluxe", "Neat",   "Gnarly",
    "Huge",   "Big",    "Strong", "Solid",  "Prime",  "Grand",
    "Swell",  "Tight",  "Snazzy", "Super",  "Smooth", "Fire",
    "Groovy", "Hot"
};
#define NUM_GOOD_WORDS ((int)(sizeof(goodWords) / sizeof(goodWords[0])))

static const char *const badWords[] = {
    "BAD LUCK", "WRECKED", "FOOBIES", "OUCH",   "OH NO", "BAD TIMES",
    "WASTED",   "DESTROYED", "DAMMIT", "NUTS",  "GAME OVER"
};
#define NUM_BAD_WORDS ((int)(sizeof(badWords) / sizeof(badWords[0])))
